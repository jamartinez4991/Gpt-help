# Registre de la place libre et des points d'accroche — Model:Cycles OS 1.13

Généré par `tools/registry.py` à partir des tweaks de ce dossier (notes/52) : ne pas éditer à la main. `python3 tools/registry.py` le régénère, `--check` vérifie qu'il est à jour, `--git <branche>` y ajoute à l'écran les mods d'autres branches, `--cycles <OS officiel>` vérifie le relevé des masques sur l'image.

Adresses : VA de l'OS 1.13 (la section 3 commence en `0x40000400`). Un mod qui veut de la place prend un masque marqué *libre* au §1 (`sprites.redirect_write`, voir `tools/AGENTS.md`), régénère ce fichier et le commet avec son tweak. `tools/check_overlaps.py` refuse deux mods installables ensemble aux mêmes octets ; ce registre refuse une écriture dans un masque dont le sprite n'est pas redirigé.

## En bref

- 301 tweaks, 32 455 écritures.
- Masques de sprites libérables : 164 (35 960 o), dont 52 pris (18 000 o) et **112 libres (17 960 o)**.
- Crochets sur l'OS : 149 adresses détournées, dont 83 à l'identique par des mods de familles différentes.
- Pointeurs réécrits : 67 adresses. Écritures dans des octets 0xFF hors masques : 14 zones.
- Charges utiles ajoutées après l'OS : 279 tweaks ; place restante au §3.
- Declared claims (notes/65): 21 holders; the saved data in §6, the key combinations in §8, the descriptors, formatters, pictures, p-lock rows and MIDI in §9, the views in §10.

## 1. Masques de sprites libérés

Les masques d'un groupe sont identiques octet pour octet et chacun n'est désigné que par la constante 32 bits de son constructeur (notes/14 §5, notes/32 §11, notes/52). Faire pointer cette constante sur la copie gardée libère le masque : le rendu ne change pas et l'OS, chargé en SDRAM, n'y lit plus rien. Règles : un mod qui écrit dans un masque le redirige dans le même tweak (ou dans un tweak qu'il demande) ; personne n'écrit dans une copie gardée ; deux mods ne partagent un masque que s'ils ne s'installent jamais ensemble, ou l'un par-dessus l'autre.

### 47×47 : 21 masques de 376 o (copie gardée `0x40172220`) : 21 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4016b6f8` | `0x400b133e` | pris (plein) | chord-keys (376 o) |
| `0x4016b9e8` | `0x400b131c` | pris (374/376 o) | chord-keys (374 o) |
| `0x40171f30` | `0x400b05a0` | pris (plein) | chord-keys (376 o) |
| `0x40172608` | `0x400b0544` | pris (362/376 o) | chord-keys (362 o) |
| `0x40179730` | `0x400af64a` | pris (373/376 o) | chord-keys (373 o) |
| `0x40182b38` | `0x400adfda` | pris (plein) | chord-keys (376 o) |
| `0x40182e28` | `0x400adfba` | pris (plein) | chord-keys (376 o) |
| `0x40183118` | `0x400adf9e` | pris (374/376 o) | chord-keys (374 o), sample-preview (292 o), sample-preview-st (292 o) |
| `0x40185018` | `0x400adba8` | pris (372/376 o) | chord-keys (372 o), sample-preview (300 o), sample-preview-st (300 o) |
| `0x40185968` | `0x400ada00` | pris (372/376 o) | chord-keys (372 o), sample-preview (332 o), sample-preview-st (332 o) |
| `0x40185c58` | `0x400ad9e0` | pris (374/376 o) | chord-keys (374 o), sample-preview (312 o), sample-preview-st (312 o) |
| `0x40189930` | `0x400ad328` | pris (354/376 o) | arp (354 o) |
| `0x4018a220` | `0x400ad202` | pris (359/376 o) | arp (359 o) |
| `0x4018cd48` | `0x400acdb2` | pris (plein) | chord-keys (376 o) |
| `0x4018d1b8` | `0x400acd76` | pris (372/376 o) | chord-keys (372 o) |
| `0x4018d4a8` | `0x400acd56` | pris (210/376 o) | chord-keys (210 o) |
| `0x4018dba8` | `0x400accfe` | pris (114/376 o) | trigless-dim (114 o) |
| `0x4018f4b4` | `0x400ac8d0` | pris (360/376 o) | level-pan-values (360 o) |
| `0x4018fc74` | `0x400ac81c` | pris (364/376 o) | level-pan-values (364 o) |
| `0x401904b4` | `0x400ac784` | pris (370/376 o) | multiline-browser (370 o) |
| `0x40192734` | `0x400ac2b2` | pris (318/376 o) | trigless-dim (318 o) |

### 48×22 : 42 masques de 192 o (copie gardée `0x4014b364`) : 5 pris, 37 libres (7 104 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x40152d38` | `0x400b9726` | pris (178/192 o) | trig-cond-order (178 o) |
| `0x401592bc` | `0x400b7404` | libre | |
| `0x4015943c` | `0x400b73e4` | libre | |
| `0x4015f38c` | `0x400b504a` | libre | |
| `0x40165fec` | `0x400b28b4` | libre | |
| `0x40168a84` | `0x400b1bc0` | libre | |
| `0x40168da4` | `0x400b1b32` | libre | |
| `0x4016bcd8` | `0x400b12fe` | libre | |
| `0x4016dab8` | `0x400b0f78` | libre | |
| `0x4016fae8` | `0x400b0b20` | libre | |
| `0x40170c48` | `0x400b08da` | libre | |
| `0x40171a48` | `0x400b06ec` | libre | |
| `0x40172a68` | `0x400b0508` | libre | |
| `0x40172be8` | `0x400b04ec` | libre | |
| `0x401736c8` | `0x400b036c` | libre | |
| `0x40177f28` | `0x400af962` | libre | |
| `0x40178708` | `0x400af812` | libre | |
| `0x40178fc0` | `0x400af6e2` | libre | |
| `0x401792b0` | `0x400af6a6` | libre | |
| `0x40179430` | `0x400af686` | libre | |
| `0x401795b0` | `0x400af66a` | libre | |
| `0x40179b18` | `0x400af60e` | libre | |
| `0x4017c97c` | `0x400aee4e` | libre | |
| `0x401829b8` | `0x400adff6` | libre | |
| `0x40183408` | `0x400adf7e` | libre | |
| `0x40184808` | `0x400adc40` | libre | |
| `0x40184af8` | `0x400adc04` | libre | |
| `0x40184c78` | `0x400adbe4` | libre | |
| `0x40187528` | `0x400ad742` | libre | |
| `0x401876a8` | `0x400ad726` | libre | |
| `0x40188f98` | `0x400ad3a0` | libre | |
| `0x4018a608` | `0x400ad1c6` | libre | |
| `0x4018b9c8` | `0x400ad048` | pris (164/192 o) | control-all-config (164 o) |
| `0x4018bb48` | `0x400ad028` | pris (78/192 o) | control-all-config (78 o) |
| `0x4018cbc8` | `0x400acdce` | pris (138/192 o) | control-all-config (138 o) |
| `0x4018d038` | `0x400acd92` | pris (114/192 o) | control-all-config (114 o) |
| `0x4018d798` | `0x400acd3a` | libre | |
| `0x4018f80c` | `0x400ac894` | libre | |
| `0x40190184` | `0x400ac7e0` | libre | |
| `0x40190334` | `0x400ac7a4` | libre | |
| `0x4019089c` | `0x400ac748` | libre | |
| `0x40192a24` | `0x400ac292` | libre | |

### 35×35 : 19 masques de 280 o (copie gardée `0x4014a660`) : 15 pris, 4 libres (1 120 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4014ab5c` | `0x400bb120` | pris (152/280 o) | track-filter (152 o) |
| `0x4014b85c` | `0x400bae4e` | pris (148/280 o) | track-filter (148 o) |
| `0x4014d74c` | `0x400bac28` | pris (164/280 o) | track-filter (164 o) |
| `0x401542f8` | `0x400b91d8` | pris (162/280 o) | track-filter (162 o) |
| `0x401548b4` | `0x400b903a` | pris (206/280 o) | track-filter (206 o) |
| `0x4015b8f8` | `0x400b668c` | pris (260/280 o) | track-filter (260 o) |
| `0x4015f50c` | `0x400b5028` | pris (260/280 o) | track-filter (260 o) |
| `0x401601fc` | `0x400b4b4a` | pris (260/280 o) | track-filter (260 o) |
| `0x40160864` | `0x400b48ac` | pris (260/280 o) | track-filter (260 o) |
| `0x40160b6c` | `0x400b4870` | pris (216/280 o) | track-filter (216 o) |
| `0x40160e6c` | `0x400b482e` | pris (256/280 o) | track-filter (256 o) |
| `0x401625bc` | `0x400b3e2a` | pris (136/280 o) | track-filter (136 o) |
| `0x40163fb8` | `0x400b34c8` | pris (147/280 o) | track-filter (147 o) |
| `0x4016616c` | `0x400b2898` | pris (164/280 o) | track-filter (164 o) |
| `0x40166760` | `0x400b272e` | pris (208/280 o) | track-filter (208 o) |
| `0x40167c50` | `0x400b211e` | libre | |
| `0x401696a0` | `0x400b1540` | libre | |
| `0x401699a8` | `0x400b1500` | libre | |
| `0x4016aa28` | `0x400b1480` | libre | |

### 34×34 : 14 masques de 272 o (copie gardée `0x4016bfc8`) : 8 pris, 6 libres (1 632 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4016f8c8` | `0x400b0b3c` | pris (plein) | lfo-plus (272 o) |
| `0x40173848` | `0x400b0350` | pris (plein) | lfo-plus (272 o) |
| `0x401780a8` | `0x400af946` | pris (plein) | lfo-plus (272 o) |
| `0x401784e8` | `0x400af832` | pris (262/272 o) | lfo-plus (262 o) |
| `0x401835b8` | `0x400adedc` | pris (270/272 o) | lfo-plus (270 o) |
| `0x40184df8` | `0x400adbc8` | pris (248/272 o) | lfo-plus (248 o) |
| `0x40185308` | `0x400adb8c` | pris (248/272 o) | lfo-plus (248 o) |
| `0x40185f48` | `0x400ad9c4` | libre | |
| `0x40186238` | `0x400ad988` | libre | |
| `0x40189618` | `0x400ad364` | libre | |
| `0x4018af88` | `0x400ad18a` | libre | |
| `0x4018b1a8` | `0x400ad16e` | libre | |
| `0x4018ff64` | `0x400ac7fc` | libre | |
| `0x40192ba4` | `0x400ac276` | pris (132/272 o) | midi-live-both (132 o) |

### 27×27 : 24 masques de 108 o (copie gardée `0x4014a550`) : 0 pris, 24 libres (2 592 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4014a890` | `0x400bb1fc` | libre | |
| `0x4014aa34` | `0x400bb178` | libre | |
| `0x4014af84` | `0x400bb044` | libre | |
| `0x4014b05c` | `0x400bb028` | libre | |
| `0x4014b5b4` | `0x400baf2e` | libre | |
| `0x4014b784` | `0x400bae6e` | libre | |
| `0x4014e608` | `0x400ba8f2` | libre | |
| `0x40152f88` | `0x400b96ce` | libre | |
| `0x40159a04` | `0x400b71ea` | libre | |
| `0x40159adc` | `0x400b71ce` | libre | |
| `0x4015b820` | `0x400b66a8` | libre | |
| `0x4015bf24` | `0x400b6476` | libre | |
| `0x4015c9a4` | `0x400b6232` | libre | |
| `0x4015fb6c` | `0x400b4e5a` | libre | |
| `0x40160a94` | `0x400b488c` | libre | |
| `0x401617a8` | `0x400b4386` | libre | |
| `0x40161880` | `0x400b4366` | libre | |
| `0x401629dc` | `0x400b3d96` | libre | |
| `0x40163a60` | `0x400b362e` | libre | |
| `0x40167900` | `0x400b21ac` | libre | |
| `0x40167aa8` | `0x400b216c` | libre | |
| `0x40168440` | `0x400b1d7c` | libre | |
| `0x401688b4` | `0x400b1c5e` | libre | |
| `0x401698d0` | `0x400b1522` | libre | |

### 31×22 : 18 masques de 124 o (copie gardée `0x4016e980`) : 0 pris, 18 libres (2 232 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4016f7d0` | `0x400b0b5c` | libre | |
| `0x4016fd60` | `0x400b0ae4` | libre | |
| `0x40172510` | `0x400b0564` | libre | |
| `0x40178888` | `0x400af7f6` | libre | |
| `0x40179a20` | `0x400af62e` | libre | |
| `0x4017a4d4` | `0x400af43c` | libre | |
| `0x401837d8` | `0x400adeba` | libre | |
| `0x401871a0` | `0x400ad77e` | libre | |
| `0x40189838` | `0x400ad344` | libre | |
| `0x4018a510` | `0x400ad1e6` | libre | |
| `0x4018bcc8` | `0x400ad00c` | libre | |
| `0x4018f98c` | `0x400ac874` | libre | |
| `0x4018fa84` | `0x400ac858` | libre | |
| `0x4018fb7c` | `0x400ac838` | libre | |
| `0x401907a4` | `0x400ac768` | libre | |
| `0x40190a1c` | `0x400ac72c` | libre | |
| `0x40194ad4` | `0x400abeaa` | libre | |
| `0x40195a7c` | `0x400abc76` | libre | |

### 26×26 : 14 masques de 104 o (copie gardée `0x4014b4e4`) : 0 pris, 14 libres (1 456 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x401573cc` | `0x400b83da` | libre | |
| `0x40160d9c` | `0x400b4850` | libre | |
| `0x40162ab4` | `0x400b3d76` | libre | |
| `0x401630e4` | `0x400b3b2e` | libre | |
| `0x401638c0` | `0x400b366a` | libre | |
| `0x40163990` | `0x400b364a` | libre | |
| `0x40163b38` | `0x400b360e` | libre | |
| `0x40166690` | `0x400b274c` | libre | |
| `0x401679d8` | `0x400b218a` | libre | |
| `0x40167b80` | `0x400b2144` | libre | |
| `0x40168c4c` | `0x400b1b80` | libre | |
| `0x40168fb4` | `0x400b1a72` | libre | |
| `0x40179c98` | `0x400af5f2` | libre | |
| `0x40186168` | `0x400ad9a4` | libre | |

### 46×31 : 7 masques de 184 o (copie gardée `0x4016be58`) : 0 pris, 7 libres (1 288 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x40170ad8` | `0x400b08f6` | libre | |
| `0x40171bc8` | `0x400b06d0` | libre | |
| `0x401728f8` | `0x400b0528` | libre | |
| `0x40179140` | `0x400af6c2` | libre | |
| `0x40184988` | `0x400adc20` | libre | |
| `0x40185648` | `0x400ada58` | libre | |
| `0x401857f8` | `0x400ada1c` | libre | |

### 41×41 : 1 masques de 328 o (copie gardée `0x40187298`) : 0 pris, 1 libres (328 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4018d918` | `0x400acd1a` | libre | |

### 52×22 : 1 masques de 208 o (copie gardée `0x4014bfe4`) : 0 pris, 1 libres (208 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4016ea78` | `0x400b0d50` | libre | |

### Masques 0xFF redirigés vers `0x40154ae4` (notes/14 §5)

Trois masques entièrement à 0xFF, les plus grands ; plusieurs mods s'y partagent la place (`check_overlaps.py` garantit qu'ils n'écrivent pas les mêmes octets, ou à l'identique).

| masque | taille | constante | état | mods (octets écrits) |
|---|---|---|---|---|
| `0x4015c044` | 720 o | `0x400b6434` | pris (550/720 o) | 6ch-usbup (384 o), acid (208 o), macro (208 o), macro-acid (208 o), model-tg (208 o), model-tg-st (208 o), syntakt-* (32/32, 208 o), syntakt-*-acid (31/31, 208 o), syntakt-*-macro (31/31, 208 o), syntakt-*-macro-acid (31/31, 208 o), trig-hold (166 o) |
| `0x4016cae8` | 1024 o | `0x400b1106` | pris (1016/1024 o) | acid (104 o), acid-tg (96 o), arp (824 o), chordtables (80 o), cpu (80 o), crush (80 o), digidelay (80 o), eq (80 o), macro (104 o), macro-acid (112 o), macro-acid-tg (104 o), macro-tg (96 o), perform (80 o), pots (80 o), refchord (80 o), refmachine (112 o), refmachine2 (112 o), resample (80 o), reso (80 o), ring (80 o), sampler (112 o), sdvintage-7th (40 o), sdvintage-exact (40 o), sdvintage-snare (973 o), smpfilter (80 o), solid (112 o), syntakt-* (32/32, 80 o), syntakt-*-acid (31/31, 188 o), syntakt-*-macro (31/31, 188 o), syntakt-*-macro-acid (31/31, 188 o), syntakt-tg-* (33/33, 172–188 o), syntakt-tg-*-acid (31/31, 180 o), syntakt-tg-*-macro (31/31, 180 o), syntakt-tg-*-macro-acid (31/31, 180 o), syntakt-vintage (40 o), transpose (80 o) |
| `0x4018a788` | 1024 o | `0x400ad1aa` | pris (1016/1024 o) | arp (1016 o), sdvintage-snare (638 o) |

## 2. Autres écritures dans des octets 0xFF (caves)

Octets à 0xFF dans l'OS d'origine, hors des masques ci-dessus (tables à trous, fins de blocs). `build.py` refuse d'y écrire si l'image d'origine pointe dedans, sauf référence vérifiée à la main (`device.json`, `cave_refs_ok`).

| adresse | octets | mods |
|---|---|---|
| `0x4010df48` | 8 | model-tg, model-tg-st |
| `0x40147f22` | 2 | browser-scroll, model-tg, model-tg-st |
| `0x40147f25` | 126 | browser-scroll, model-tg, model-tg-st |
| `0x40147fa4` | 52 | browser-scroll, model-tg, model-tg-st |
| `0x40148328` | 104 | latching-mute, model-tg, model-tg-st |
| `0x401485f0` | 16 | browser-scroll, model-tg, model-tg-st |
| `0x40148662` | 348 | latching-mute, model-tg, model-tg-st |
| `0x401487e0` | 4 | latching-mute, model-tg, model-tg-st |
| `0x401487ec` | 2 | latching-mute, model-tg, model-tg-st |
| `0x401489fa` | 2 | model-tg, model-tg-st, trig-preview |
| `0x401489fd` | 246 | model-tg, model-tg-st, trig-preview |
| `0x40148af4` | 76 | model-tg, model-tg-st, trig-preview |
| `0x40148b41` | 15 | model-tg, model-tg-st, trig-preview |
| `0x40148b51` | 49 | model-tg, model-tg-st, trig-preview |

## 3. Charges utiles ajoutées après l'OS

Code trop gros pour un masque, ajouté à la fin de l'image (`at`) et copié au démarrage en mémoire (`dest`) ; les charges d'un même firmware s'enchaînent dans l'ordre `order` (notes/17, 31), ce que `check_overlaps.py` vérifie pour chaque ensemble installable. L'image ne peut pas dépasser `0x40200000`.

| mod | order | dans l'image (`at`) | octets | fin | en mémoire (`dest`) | octets | demande |
|---|---|---|---|---|---|---|---|
| sdvintage-exact | 21 | `0x401aa140` | 205 200 | `0x401dc2d0` | `0x43000000` | 205 200 |  |
| sdvintage-7th | 22 | `0x401aa140` | 218 208 | `0x401df5a0` | `0x43000000` | 218 208 |  |
| syntakt-vintage | 23 | `0x401aa140` | 218 560 | `0x401df700` | `0x43000000` | 218 560 |  |
| syntakt-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-bits-acid | 24 | `0x401aa140` | 150 405 | `0x401cecc5` | `0x43000000` | 492 288 |  |
| syntakt-bits-macro | 24 | `0x401aa140` | 235 079 | `0x401e3787` | `0x43000000` | 476 128 |  |
| syntakt-bits-macro-acid | 24 | `0x401aa140` | 240 307 | `0x401e4bf3` | `0x43000000` | 492 288 |  |
| syntakt-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-bits-swarm-acid | 24 | `0x401aa140` | 156 654 | `0x401d052e` | `0x43000000` | 492 288 |  |
| syntakt-bits-swarm-macro | 24 | `0x401aa140` | 241 317 | `0x401e4fe5` | `0x43000000` | 476 128 |  |
| syntakt-bits-swarm-macro-acid | 24 | `0x401aa140` | 246 528 | `0x401e6440` | `0x43000000` | 492 288 |  |
| syntakt-cp | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-cp-acid | 24 | `0x401aa140` | 145 749 | `0x401cda95` | `0x43000000` | 492 288 |  |
| syntakt-cp-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-cp-bits-acid | 24 | `0x401aa140` | 150 663 | `0x401cedc7` | `0x43000000` | 492 288 |  |
| syntakt-cp-bits-macro | 24 | `0x401aa140` | 235 334 | `0x401e3886` | `0x43000000` | 476 128 |  |
| syntakt-cp-bits-macro-acid | 24 | `0x401aa140` | 240 550 | `0x401e4ce6` | `0x43000000` | 492 288 |  |
| syntakt-cp-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-cp-bits-swarm-acid | 24 | `0x401aa140` | 156 876 | `0x401d060c` | `0x43000000` | 492 288 |  |
| syntakt-cp-bits-swarm-macro | 24 | `0x401aa140` | 241 537 | `0x401e50c1` | `0x43000000` | 476 128 |  |
| syntakt-cp-bits-swarm-macro-acid | 24 | `0x401aa140` | 246 772 | `0x401e6534` | `0x43000000` | 492 288 |  |
| syntakt-cp-macro | 24 | `0x401aa140` | 230 421 | `0x401e2555` | `0x43000000` | 476 128 |  |
| syntakt-cp-macro-acid | 24 | `0x401aa140` | 235 651 | `0x401e39c3` | `0x43000000` | 492 288 |  |
| syntakt-cp-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-cp-swarm-acid | 24 | `0x401aa140` | 156 623 | `0x401d050f` | `0x43000000` | 492 288 |  |
| syntakt-cp-swarm-macro | 24 | `0x401aa140` | 241 302 | `0x401e4fd6` | `0x43000000` | 476 128 |  |
| syntakt-cp-swarm-macro-acid | 24 | `0x401aa140` | 246 513 | `0x401e6431` | `0x43000000` | 492 288 |  |
| syntakt-cp-toy | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-cp-toy-acid | 24 | `0x401aa140` | 146 013 | `0x401cdb9d` | `0x43000000` | 492 288 |  |
| syntakt-cp-toy-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-cp-toy-bits-acid | 24 | `0x401aa140` | 150 868 | `0x401cee94` | `0x43000000` | 492 288 |  |
| syntakt-cp-toy-bits-macro | 24 | `0x401aa140` | 235 537 | `0x401e3951` | `0x43000000` | 476 128 |  |
| syntakt-cp-toy-bits-macro-acid | 24 | `0x401aa140` | 240 765 | `0x401e4dbd` | `0x43000000` | 492 288 |  |
| syntakt-cp-toy-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-cp-toy-bits-swarm-acid | 24 | `0x401aa140` | 157 081 | `0x401d06d9` | `0x43000000` | 492 288 |  |
| syntakt-cp-toy-bits-swarm-macro | 24 | `0x401aa140` | 241 747 | `0x401e5193` | `0x43000000` | 476 128 |  |
| syntakt-cp-toy-bits-swarm-macro-acid | 24 | `0x401aa140` | 246 973 | `0x401e65fd` | `0x43000000` | 492 288 |  |
| syntakt-cp-toy-macro | 24 | `0x401aa140` | 230 683 | `0x401e265b` | `0x43000000` | 476 128 |  |
| syntakt-cp-toy-macro-acid | 24 | `0x401aa140` | 235 906 | `0x401e3ac2` | `0x43000000` | 492 288 |  |
| syntakt-cp-toy-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-cp-toy-swarm-acid | 24 | `0x401aa140` | 156 850 | `0x401d05f2` | `0x43000000` | 492 288 |  |
| syntakt-cp-toy-swarm-macro | 24 | `0x401aa140` | 241 514 | `0x401e50aa` | `0x43000000` | 476 128 |  |
| syntakt-cp-toy-swarm-macro-acid | 24 | `0x401aa140` | 246 743 | `0x401e6517` | `0x43000000` | 492 288 |  |
| syntakt-sd | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-sd-acid | 24 | `0x401aa140` | 145 754 | `0x401cda9a` | `0x43000000` | 492 288 |  |
| syntakt-sd-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-sd-bits-acid | 24 | `0x401aa140` | 150 690 | `0x401cede2` | `0x43000000` | 492 288 |  |
| syntakt-sd-bits-macro | 24 | `0x401aa140` | 235 369 | `0x401e38a9` | `0x43000000` | 476 128 |  |
| syntakt-sd-bits-macro-acid | 24 | `0x401aa140` | 240 572 | `0x401e4cfc` | `0x43000000` | 492 288 |  |
| syntakt-sd-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-bits-swarm-acid | 24 | `0x401aa140` | 156 902 | `0x401d0626` | `0x43000000` | 492 288 |  |
| syntakt-sd-bits-swarm-macro | 24 | `0x401aa140` | 241 576 | `0x401e50e8` | `0x43000000` | 476 128 |  |
| syntakt-sd-bits-swarm-macro-acid | 24 | `0x401aa140` | 246 796 | `0x401e654c` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-sd-cp-acid | 24 | `0x401aa140` | 146 012 | `0x401cdb9c` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-sd-cp-bits-acid | 24 | `0x401aa140` | 150 880 | `0x401ceea0` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-bits-macro | 24 | `0x401aa140` | 235 563 | `0x401e396b` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-bits-macro-acid | 24 | `0x401aa140` | 240 775 | `0x401e4dc7` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-cp-bits-swarm-acid | 24 | `0x401aa140` | 157 090 | `0x401d06e2` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-bits-swarm-macro | 24 | `0x401aa140` | 241 760 | `0x401e51a0` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-bits-swarm-macro-acid | 24 | `0x401aa140` | 246 970 | `0x401e65fa` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-macro | 24 | `0x401aa140` | 230 693 | `0x401e2665` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-macro-acid | 24 | `0x401aa140` | 235 904 | `0x401e3ac0` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-cp-swarm-acid | 24 | `0x401aa140` | 156 856 | `0x401d05f8` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-swarm-macro | 24 | `0x401aa140` | 241 523 | `0x401e50b3` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-swarm-macro-acid | 24 | `0x401aa140` | 246 742 | `0x401e6516` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-toy | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-sd-cp-toy-acid | 24 | `0x401aa140` | 146 224 | `0x401cdc70` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-toy-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-sd-cp-toy-bits-acid | 24 | `0x401aa140` | 151 089 | `0x401cef71` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-toy-bits-macro | 24 | `0x401aa140` | 235 764 | `0x401e3a34` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-toy-bits-macro-acid | 24 | `0x401aa140` | 240 976 | `0x401e4e90` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-toy-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-cp-toy-bits-swarm-acid | 24 | `0x401aa140` | 157 290 | `0x401d07aa` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-toy-bits-swarm-macro | 24 | `0x401aa140` | 241 962 | `0x401e526a` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-toy-bits-swarm-macro-acid | 24 | `0x401aa140` | 247 168 | `0x401e66c0` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-toy-macro | 24 | `0x401aa140` | 230 901 | `0x401e2735` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-toy-macro-acid | 24 | `0x401aa140` | 236 126 | `0x401e3b9e` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-toy-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-cp-toy-swarm-acid | 24 | `0x401aa140` | 157 061 | `0x401d06c5` | `0x43000000` | 492 288 |  |
| syntakt-sd-cp-toy-swarm-macro | 24 | `0x401aa140` | 241 743 | `0x401e518f` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-toy-swarm-macro-acid | 24 | `0x401aa140` | 246 945 | `0x401e65e1` | `0x43000000` | 492 288 |  |
| syntakt-sd-macro | 24 | `0x401aa140` | 230 427 | `0x401e255b` | `0x43000000` | 476 128 |  |
| syntakt-sd-macro-acid | 24 | `0x401aa140` | 235 657 | `0x401e39c9` | `0x43000000` | 492 288 |  |
| syntakt-sd-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-swarm-acid | 24 | `0x401aa140` | 156 627 | `0x401d0513` | `0x43000000` | 492 288 |  |
| syntakt-sd-swarm-macro | 24 | `0x401aa140` | 241 311 | `0x401e4fdf` | `0x43000000` | 476 128 |  |
| syntakt-sd-swarm-macro-acid | 24 | `0x401aa140` | 246 516 | `0x401e6434` | `0x43000000` | 492 288 |  |
| syntakt-sd-toy | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-sd-toy-acid | 24 | `0x401aa140` | 146 016 | `0x401cdba0` | `0x43000000` | 492 288 |  |
| syntakt-sd-toy-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-sd-toy-bits-acid | 24 | `0x401aa140` | 150 897 | `0x401ceeb1` | `0x43000000` | 492 288 |  |
| syntakt-sd-toy-bits-macro | 24 | `0x401aa140` | 235 561 | `0x401e3969` | `0x43000000` | 476 128 |  |
| syntakt-sd-toy-bits-macro-acid | 24 | `0x401aa140` | 240 797 | `0x401e4ddd` | `0x43000000` | 492 288 |  |
| syntakt-sd-toy-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-toy-bits-swarm-acid | 24 | `0x401aa140` | 157 112 | `0x401d06f8` | `0x43000000` | 492 288 |  |
| syntakt-sd-toy-bits-swarm-macro | 24 | `0x401aa140` | 241 776 | `0x401e51b0` | `0x43000000` | 476 128 |  |
| syntakt-sd-toy-bits-swarm-macro-acid | 24 | `0x401aa140` | 246 991 | `0x401e660f` | `0x43000000` | 492 288 |  |
| syntakt-sd-toy-macro | 24 | `0x401aa140` | 230 694 | `0x401e2666` | `0x43000000` | 476 128 |  |
| syntakt-sd-toy-macro-acid | 24 | `0x401aa140` | 235 904 | `0x401e3ac0` | `0x43000000` | 492 288 |  |
| syntakt-sd-toy-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-toy-swarm-acid | 24 | `0x401aa140` | 156 858 | `0x401d05fa` | `0x43000000` | 492 288 |  |
| syntakt-sd-toy-swarm-macro | 24 | `0x401aa140` | 241 527 | `0x401e50b7` | `0x43000000` | 476 128 |  |
| syntakt-sd-toy-swarm-macro-acid | 24 | `0x401aa140` | 246 748 | `0x401e651c` | `0x43000000` | 492 288 |  |
| syntakt-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-swarm-acid | 24 | `0x401aa140` | 156 342 | `0x401d03f6` | `0x43000000` | 492 288 |  |
| syntakt-swarm-macro | 24 | `0x401aa140` | 241 016 | `0x401e4eb8` | `0x43000000` | 476 128 |  |
| syntakt-swarm-macro-acid | 24 | `0x401aa140` | 246 245 | `0x401e6325` | `0x43000000` | 492 288 |  |
| syntakt-toy | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-toy-acid | 24 | `0x401aa140` | 145 736 | `0x401cda88` | `0x43000000` | 492 288 |  |
| syntakt-toy-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-toy-bits-acid | 24 | `0x401aa140` | 150 668 | `0x401cedcc` | `0x43000000` | 492 288 |  |
| syntakt-toy-bits-macro | 24 | `0x401aa140` | 235 334 | `0x401e3886` | `0x43000000` | 476 128 |  |
| syntakt-toy-bits-macro-acid | 24 | `0x401aa140` | 240 557 | `0x401e4ced` | `0x43000000` | 492 288 |  |
| syntakt-toy-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-toy-bits-swarm-acid | 24 | `0x401aa140` | 156 873 | `0x401d0609` | `0x43000000` | 492 288 |  |
| syntakt-toy-bits-swarm-macro | 24 | `0x401aa140` | 241 539 | `0x401e50c3` | `0x43000000` | 476 128 |  |
| syntakt-toy-bits-swarm-macro-acid | 24 | `0x401aa140` | 246 760 | `0x401e6528` | `0x43000000` | 492 288 |  |
| syntakt-toy-macro | 24 | `0x401aa140` | 230 410 | `0x401e254a` | `0x43000000` | 476 128 |  |
| syntakt-toy-macro-acid | 24 | `0x401aa140` | 235 642 | `0x401e39ba` | `0x43000000` | 492 288 |  |
| syntakt-toy-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-toy-swarm-acid | 24 | `0x401aa140` | 156 616 | `0x401d0508` | `0x43000000` | 492 288 |  |
| syntakt-toy-swarm-macro | 24 | `0x401aa140` | 241 285 | `0x401e4fc5` | `0x43000000` | 476 128 |  |
| syntakt-toy-swarm-macro-acid | 24 | `0x401aa140` | 246 504 | `0x401e6428` | `0x43000000` | 492 288 |  |
| macro | 25 | `0x401aa140` | 105 152 | `0x401c3c00` | `0x43000000` | 324 576 |  |
| macro-acid | 25 | `0x401aa140` | 111 760 | `0x401c55d0` | `0x43000000` | 492 288 |  |
| acid | 26 | `0x401aa140` | 11 380 | `0x401acdb4` | `0x43000000` | 221 928 |  |
| sampler | 27 | `0x401aa140` | 50 484 | `0x401b6674` | `0x43000000` | 283 924 |  |
| refmachine | 28 | `0x401aa140` | 6 992 | `0x401abc90` | `0x43000000` | 221 376 |  |
| refmachine2 | 29 | `0x401aa140` | 11 620 | `0x401acea4` | `0x43000000` | 221 428 |  |
| model-tg | 30 | `0x401aa140` | 87 936 | `0x401bf8c0` | `0x401aa140` | 87 936 |  |
| model-tg-st | 30 | `0x401aa140` | 87 936 | `0x401bf8c0` | `0x401aa140` | 87 936 |  |
| syntakt-tg-bits | 31 | `0x401bf8c0` | 234 548 | `0x401f8cf4` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-bits-acid | 31 | `0x401bf8c0` | 150 663 | `0x401e4547` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-bits-macro | 31 | `0x401bf8c0` | 235 350 | `0x401f9016` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-bits-macro-acid | 31 | `0x401bf8c0` | 240 576 | `0x401fa480` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-bits-swarm | 31 | `0x401bf8c0` | 241 508 | `0x401fa824` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-bits-swarm-acid | 31 | `0x401bf8c0` | 156 909 | `0x401e5dad` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-bits-swarm-macro | 31 | `0x401bf8c0` | 241 585 | `0x401fa871` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-bits-swarm-macro-acid | 31 | `0x401bf8c0` | 246 808 | `0x401fbcd8` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp | 31 | `0x401bf8c0` | 227 772 | `0x401f727c` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-cp-acid | 31 | `0x401bf8c0` | 146 009 | `0x401e3319` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-bits | 31 | `0x401bf8c0` | 235 184 | `0x401f8f70` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-cp-bits-acid | 31 | `0x401bf8c0` | 150 922 | `0x401e464a` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-bits-macro | 31 | `0x401bf8c0` | 235 621 | `0x401f9125` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-bits-macro-acid | 31 | `0x401bf8c0` | 240 828 | `0x401fa57c` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-bits-swarm | 31 | `0x401bf8c0` | 242 020 | `0x401faa24` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-cp-bits-swarm-acid | 31 | `0x401bf8c0` | 157 123 | `0x401e5e83` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-bits-swarm-macro | 31 | `0x401bf8c0` | 241 816 | `0x401fa958` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-bits-swarm-macro-acid | 31 | `0x401bf8c0` | 247 030 | `0x401fbdb6` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-macro | 31 | `0x401bf8c0` | 230 702 | `0x401f7dee` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-macro-acid | 31 | `0x401bf8c0` | 235 925 | `0x401f9255` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-swarm | 31 | `0x401bf8c0` | 241 508 | `0x401fa824` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-cp-swarm-acid | 31 | `0x401bf8c0` | 156 868 | `0x401e5d84` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-swarm-macro | 31 | `0x401bf8c0` | 241 564 | `0x401fa85c` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-swarm-macro-acid | 31 | `0x401bf8c0` | 246 785 | `0x401fbcc1` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-toy | 31 | `0x401bf8c0` | 228 348 | `0x401f74bc` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-cp-toy-acid | 31 | `0x401bf8c0` | 146 264 | `0x401e3418` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-toy-bits | 31 | `0x401bf8c0` | 235 688 | `0x401f9168` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-cp-toy-bits-acid | 31 | `0x401bf8c0` | 151 135 | `0x401e471f` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-toy-bits-macro | 31 | `0x401bf8c0` | 235 824 | `0x401f91f0` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-toy-bits-macro-acid | 31 | `0x401bf8c0` | 241 038 | `0x401fa64e` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-toy-bits-swarm | 31 | `0x401bf8c0` | 242 512 | `0x401fac10` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-cp-toy-bits-swarm-acid | 31 | `0x401bf8c0` | 157 322 | `0x401e5f4a` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-toy-bits-swarm-macro | 31 | `0x401bf8c0` | 242 018 | `0x401faa22` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-toy-bits-swarm-macro-acid | 31 | `0x401bf8c0` | 247 226 | `0x401fbe7a` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-toy-macro | 31 | `0x401bf8c0` | 230 956 | `0x401f7eec` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-toy-macro-acid | 31 | `0x401bf8c0` | 236 176 | `0x401f9350` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-toy-swarm | 31 | `0x401bf8c0` | 241 980 | `0x401fa9fc` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-cp-toy-swarm-acid | 31 | `0x401bf8c0` | 157 093 | `0x401e5e65` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-cp-toy-swarm-macro | 31 | `0x401bf8c0` | 241 779 | `0x401fa933` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-toy-swarm-macro-acid | 31 | `0x401bf8c0` | 246 994 | `0x401fbd92` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd | 31 | `0x401bf8c0` | 227 772 | `0x401f727c` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-sd-acid | 31 | `0x401bf8c0` | 146 011 | `0x401e331b` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-bits | 31 | `0x401bf8c0` | 235 196 | `0x401f8f7c` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-sd-bits-acid | 31 | `0x401bf8c0` | 150 947 | `0x401e4663` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-bits-macro | 31 | `0x401bf8c0` | 235 644 | `0x401f913c` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-bits-macro-acid | 31 | `0x401bf8c0` | 240 853 | `0x401fa595` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-bits-swarm | 31 | `0x401bf8c0` | 242 040 | `0x401faa38` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-bits-swarm-acid | 31 | `0x401bf8c0` | 157 159 | `0x401e5ea7` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-bits-swarm-macro | 31 | `0x401bf8c0` | 241 846 | `0x401fa976` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-bits-swarm-macro-acid | 31 | `0x401bf8c0` | 247 058 | `0x401fbdd2` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp | 31 | `0x401bf8c0` | 228 360 | `0x401f74c8` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-sd-cp-acid | 31 | `0x401bf8c0` | 146 268 | `0x401e341c` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-bits | 31 | `0x401bf8c0` | 235 712 | `0x401f9180` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-sd-cp-bits-acid | 31 | `0x401bf8c0` | 151 152 | `0x401e4730` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-bits-macro | 31 | `0x401bf8c0` | 235 834 | `0x401f91fa` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-bits-macro-acid | 31 | `0x401bf8c0` | 241 053 | `0x401fa65d` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-bits-swarm | 31 | `0x401bf8c0` | 242 532 | `0x401fac24` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-cp-bits-swarm-acid | 31 | `0x401bf8c0` | 157 339 | `0x401e5f5b` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-bits-swarm-macro | 31 | `0x401bf8c0` | 242 034 | `0x401faa32` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-bits-swarm-macro-acid | 31 | `0x401bf8c0` | 247 242 | `0x401fbe8a` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-macro | 31 | `0x401bf8c0` | 230 970 | `0x401f7efa` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-macro-acid | 31 | `0x401bf8c0` | 236 182 | `0x401f9356` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-swarm | 31 | `0x401bf8c0` | 242 000 | `0x401faa10` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-cp-swarm-acid | 31 | `0x401bf8c0` | 157 098 | `0x401e5e6a` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-swarm-macro | 31 | `0x401bf8c0` | 241 787 | `0x401fa93b` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-swarm-macro-acid | 31 | `0x401bf8c0` | 247 004 | `0x401fbd9c` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-toy | 31 | `0x401bf8c0` | 228 856 | `0x401f76b8` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-sd-cp-toy-acid | 31 | `0x401bf8c0` | 146 481 | `0x401e34f1` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits | 31 | `0x401bf8c0` | 236 200 | `0x401f9368` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-acid | 31 | `0x401bf8c0` | 151 341 | `0x401e47ed` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-macro | 31 | `0x401bf8c0` | 236 040 | `0x401f92c8` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-macro-acid | 31 | `0x401bf8c0` | 241 259 | `0x401fa72b` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-swarm | 31 | `0x401bf8c0` | 243 024 | `0x401fae10` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-swarm-acid | 31 | `0x401bf8c0` | 157 538 | `0x401e6022` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-swarm-macro | 31 | `0x401bf8c0` | 242 230 | `0x401faaf6` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-swarm-macro-acid | 31 | `0x401bf8c0` | 247 441 | `0x401fbf51` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-toy-macro | 31 | `0x401bf8c0` | 231 167 | `0x401f7fbf` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-toy-macro-acid | 31 | `0x401bf8c0` | 236 390 | `0x401f9426` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-toy-swarm | 31 | `0x401bf8c0` | 242 492 | `0x401fabfc` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-cp-toy-swarm-acid | 31 | `0x401bf8c0` | 157 302 | `0x401e5f36` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-cp-toy-swarm-macro | 31 | `0x401bf8c0` | 242 004 | `0x401faa14` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-toy-swarm-macro-acid | 31 | `0x401bf8c0` | 247 211 | `0x401fbe6b` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-macro | 31 | `0x401bf8c0` | 230 703 | `0x401f7def` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-macro-acid | 31 | `0x401bf8c0` | 235 922 | `0x401f9252` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-swarm | 31 | `0x401bf8c0` | 241 504 | `0x401fa820` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-swarm-acid | 31 | `0x401bf8c0` | 156 871 | `0x401e5d87` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-swarm-macro | 31 | `0x401bf8c0` | 241 580 | `0x401fa86c` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-swarm-macro-acid | 31 | `0x401bf8c0` | 246 789 | `0x401fbcc5` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-toy | 31 | `0x401bf8c0` | 228 348 | `0x401f74bc` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-sd-toy-acid | 31 | `0x401bf8c0` | 146 266 | `0x401e341a` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-toy-bits | 31 | `0x401bf8c0` | 235 708 | `0x401f917c` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-sd-toy-bits-acid | 31 | `0x401bf8c0` | 151 161 | `0x401e4739` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-toy-bits-macro | 31 | `0x401bf8c0` | 235 852 | `0x401f920c` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-toy-bits-macro-acid | 31 | `0x401bf8c0` | 241 076 | `0x401fa674` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-toy-bits-swarm | 31 | `0x401bf8c0` | 242 532 | `0x401fac24` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-toy-bits-swarm-acid | 31 | `0x401bf8c0` | 157 361 | `0x401e5f71` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-toy-bits-swarm-macro | 31 | `0x401bf8c0` | 242 041 | `0x401faa39` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-toy-bits-swarm-macro-acid | 31 | `0x401bf8c0` | 247 261 | `0x401fbe9d` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-toy-macro | 31 | `0x401bf8c0` | 230 962 | `0x401f7ef2` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-toy-macro-acid | 31 | `0x401bf8c0` | 236 173 | `0x401f934d` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-toy-swarm | 31 | `0x401bf8c0` | 241 988 | `0x401faa04` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-toy-swarm-acid | 31 | `0x401bf8c0` | 157 096 | `0x401e5e68` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-sd-toy-swarm-macro | 31 | `0x401bf8c0` | 241 794 | `0x401fa942` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-toy-swarm-macro-acid | 31 | `0x401bf8c0` | 247 008 | `0x401fbda0` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-swarm | 31 | `0x401bf8c0` | 240 884 | `0x401fa5b4` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-swarm-acid | 31 | `0x401bf8c0` | 156 604 | `0x401e5c7c` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-swarm-macro | 31 | `0x401bf8c0` | 241 291 | `0x401fa74b` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-swarm-macro-acid | 31 | `0x401bf8c0` | 246 510 | `0x401fbbae` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-toy | 31 | `0x401bf8c0` | 227 760 | `0x401f7270` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-toy-acid | 31 | `0x401bf8c0` | 145 997 | `0x401e330d` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-toy-bits | 31 | `0x401bf8c0` | 235 180 | `0x401f8f6c` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-toy-bits-acid | 31 | `0x401bf8c0` | 150 928 | `0x401e4650` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-toy-bits-macro | 31 | `0x401bf8c0` | 235 618 | `0x401f9122` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-toy-bits-macro-acid | 31 | `0x401bf8c0` | 240 830 | `0x401fa57e` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-toy-bits-swarm | 31 | `0x401bf8c0` | 242 012 | `0x401faa1c` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-toy-bits-swarm-acid | 31 | `0x401bf8c0` | 157 128 | `0x401e5e88` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-toy-bits-swarm-macro | 31 | `0x401bf8c0` | 241 810 | `0x401fa952` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-toy-bits-swarm-macro-acid | 31 | `0x401bf8c0` | 247 037 | `0x401fbdbd` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-toy-macro | 31 | `0x401bf8c0` | 230 680 | `0x401f7dd8` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-toy-macro-acid | 31 | `0x401bf8c0` | 235 909 | `0x401f9245` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-toy-swarm | 31 | `0x401bf8c0` | 241 492 | `0x401fa814` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-toy-swarm-acid | 31 | `0x401bf8c0` | 156 869 | `0x401e5d85` | `0x46700000` | 492 288 | model-tg-st |
| syntakt-tg-toy-swarm-macro | 31 | `0x401bf8c0` | 241 551 | `0x401fa84f` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-toy-swarm-macro-acid | 31 | `0x401bf8c0` | 246 774 | `0x401fbcb6` | `0x46700000` | 492 288 | model-tg-st |
| macro-acid-tg | 32 | `0x401bf8c0` | 112 092 | `0x401dae9c` | `0x46700000` | 492 288 | model-tg-st |
| macro-tg | 32 | `0x401bf8c0` | 105 564 | `0x401d951c` | `0x46700000` | 324 576 | model-tg-st |
| refchord | 34 | `0x401aa140` | 2 256 | `0x401aaa10` | `0x43000000` | 221 192 |  |
| acid-tg | 35 | `0x401bf8c0` | 11 792 | `0x401c26d0` | `0x46700000` | 221 928 | model-tg-st |
| chordtables | 36 | `0x401aa140` | 4 756 | `0x401ab3d4` | `0x43000000` | 222 584 |  |
| digidelay | 39 | `0x401aa140` | 3 884 | `0x401ab06c` | `0x43000000` | 1 269 784 |  |
| pots | 70 | `0x401aa140` | 7 632 | `0x401abf10` | `0x43000000` | 352 504 |  |
| solid | 71 | `0x401aa140` | 20 512 | `0x401af160` | `0x43000000` | 224 404 |  |
| smpfilter | 72 | `0x401aa140` | 26 848 | `0x401b0a20` | `0x43000000` | 221 628 |  |
| crush | 73 | `0x401aa140` | 9 340 | `0x401ac5bc` | `0x43000000` | 221 256 |  |
| ring | 74 | `0x401aa140` | 12 360 | `0x401ad188` | `0x43000000` | 221 236 |  |
| reso | 75 | `0x401aa140` | 14 728 | `0x401adac8` | `0x43000000` | 364 608 |  |
| eq | 76 | `0x401aa140` | 21 396 | `0x401af4d4` | `0x43000000` | 221 952 |  |
| cpu | 78 | `0x401aa140` | 2 756 | `0x401aac04` | `0x43000000` | 221 184 |  |
| resample | 79 | `0x401aa140` | 17 164 | `0x401ae44c` | `0x43000000` | 221 184 |  |
| transpose | 81 | `0x401aa140` | 4 504 | `0x401ab2d8` | `0x43000000` | 221 184 |  |
| perform | 82 | `0x401aa140` | 11 104 | `0x401acca0` | `0x43000000` | 221 184 |  |
| syntakt-meter | 90 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-tg-meter | 91 | `0x401bf8c0` | 243 472 | `0x401fafd0` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-profile | 92 | `0x401bf8c0` | 243 904 | `0x401fb180` | `0x46700000` | 269 056 | model-tg-st |

Fin la plus haute : `0x401fbf51`, soit 16 559 o avant la limite (une charge posée sur une autre, comme les moteurs du Syntakt sur Model-TG, est déjà comptée à sa place dans la chaîne).

## 4. Points d'accroche (crochets) sur l'OS

Instructions de l'OS remplacées par un détour (`jsr`, `jmp`, `bsr.l`, `bra.l`) vers le code d'un mod, ou vers une autre fonction de l'OS. Deux mods installables ensemble ne peuvent détourner la même adresse qu'avec les mêmes octets (`check_overlaps.py`) ; sinon ils se déclarent `conflicts`. Les combinaisons de moteurs du Syntakt visent des décalages différents dans leur charge utile : une ligne par adresse et par zone visée, avec le nombre de cibles (moteurs résumés en familles : présents/total). Le rôle de chaque crochet est dans la note du mod.

| adresse | origine (hex) | détour | vers | mods | notes |
|---|---|---|---|---|---|
| `0x400004b2` | `4feffff048d700f0` | jmp | masque `0x4016cae8` +0x0 | acid, chordtables, cpu, crush, digidelay, eq, macro, macro-acid, perform, pots, refchord, refmachine, refmachine2, resample, reso, ring, sampler, sdvintage-7th, sdvintage-exact, smpfilter, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-vintage, transpose | notes/17, notes/18, notes/36, notes/60, notes/63, notes/65, notes/66, notes/68, notes/69, notes/71, notes/72, notes/73, notes/74, notes/75, notes/76, notes/78, notes/79, notes/80, notes/81 |
| `0x4000154a` | `4eb940044df8` | jsr | masque `0x40192ba4` +0x70 `midi_gate` | midi-live-both | notes/53 |
| `0x4000156a` | `4eb940044df8` | jsr | masque `0x40192ba4` +0x70 `midi_gate` | midi-live-both | notes/53 |
| `0x40001590` | `4eb940044df8` | jsr | masque `0x40192ba4` +0x70 `midi_gate` | midi-live-both | notes/53 |
| `0x400027e8` | `203c0030008072302540…` | jmp | OS `0x4019b136` | 6ch-multiout |  |
| `0x400027e8` | `203c0030008072302540…` | jmp | masque `0x4015c044` +0xd2 | 6ch-usbup | notes/36 |
| `0x400029e4` | `e7882239404a05e8d280…` | jmp | OS `0x4019b244` | 6ch-multiout |  |
| `0x400029e4` | `e7882239404a05e8d280…` | jmp | masque `0x4015c044` +0x1e0 | 6ch-usbup | notes/36 |
| `0x40002a06` | `206f002422414281d1c5…` | jmp | OS `0x4019b1e0` | 6ch-multiout |  |
| `0x40002a06` | `206f002422414281d1c5…` | jmp | masque `0x4015c044` +0x17c | 6ch-usbup | notes/36 |
| `0x40002a42` | `721320402004e3ace788…` | jmp | OS `0x4019b182` | 6ch-multiout |  |
| `0x40002a42` | `721320402004e3ace788…` | jmp | masque `0x4015c044` +0x11e | 6ch-usbup | notes/36 |
| `0x40005f36` | `b2ac00286730` | jmp | masque `0x4018dba8` +0x0 | trigless-dim | notes/45 |
| `0x40006086` | `4ef94008e77e` | jmp | masque `0x4018dba8` +0x20 | trigless-dim | notes/45 |
| `0x40006a76` | `4eb940076ca2` | jsr | charge utile (mémoire) +0x1104 | transpose | notes/80 |
| `0x400075f0` | `4eb940076be4` | jsr | charge utile (mémoire), 5 cibles selon la combinaison | chordtables, refchord, refmachine2, sampler, solid | notes/60, notes/63, notes/66, notes/71 |
| `0x400081f2` | `4eb940090f48` | jsr | masque `0x4018f4b4` +0x0 | level-pan-values | notes/44 |
| `0x4000c140` | `4e56ffe0202e000c` | jmp | masque `0x401780a8` +0x0 `lfo_dest` | lfo-plus | notes/56 |
| `0x4000eb12` | `4e56fff82f0b` | jmp | charge utile (mémoire) +0x9ac | perform | notes/81 |
| `0x4000f36a` | `4feffff448d7001c` | jmp | charge utile (mémoire) +0x8f4 | perform | notes/81 |
| `0x400100ba` | `4eb94005b2ae` | jsr | charge utile (mémoire) +0x966 | perform | notes/81 |
| `0x400107a4` | `4eb94005d080` | jsr | charge utile (mémoire) +0x980 | perform | notes/81 |
| `0x40010c7a` | `4e56ffc448d73c7c` | jmp | charge utile (mémoire) +0x9c0 | perform | notes/81 |
| `0x4001190c` | `4e56ffc448d73c7c` | jmp | charge utile (mémoire) +0x9d4 | perform | notes/81 |
| `0x40011a7e` | `4e56ffb4122e0013` | jmp | charge utile (mémoire) +0x9e8 | perform | notes/81 |
| `0x4001413e` | `205242a72f0a` | jmp | charge utile (image) +0x10eb6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400169f0` | `4feffff448d7040c` | jmp | charge utile (image) +0x4fb6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x40019e7a` | `4feffff07005` | jsr | charge utile (mémoire) +0x4ce6 | sampler | notes/60 |
| `0x4001a164` | `4eb940016da6` | jsr | charge utile (mémoire) +0x9bc | transpose | notes/80 |
| `0x4001a1c4` | `4eb940016086` | jsr | masque `0x4018a788` +0x16 | arp | notes/32 |
| `0x4001aa4e` | `4fefffe048d70cfc` | jmp | masque `0x4018f4b4` +0xc | level-pan-values | notes/44 |
| `0x4001ab14` | `2f032f02d880` | jsr | charge utile (mémoire) +0x4d6a | sampler | notes/60 |
| `0x4001ab52` | `2f022800d887` | jsr | charge utile (mémoire) +0x4d76 | sampler | notes/60 |
| `0x4001ac4a` | `4feffff47201` | jmp | charge utile (mémoire), 2 cibles selon la combinaison | refmachine2, sampler | notes/60, notes/63 |
| `0x4001ac7a` | `2f022f034e92` | jmp | masque `0x4018bb48` +0x0 `cac_loop4` | control-all-config | notes/58 |
| `0x4001b22a` | `4e56ffc048d73cfc` | jmp | masque `0x4018f4b4` +0x78 | level-pan-values | notes/44 |
| `0x4001b68c` | `e0804a806c04` | jmp | charge utile (mémoire) +0x33190 | refmachine, refmachine2, sampler, solid | notes/60, notes/63, notes/65, notes/71 |
| `0x4001b884` | `4eb9400107d8` | jsr | charge utile (mémoire) +0xc14 | transpose | notes/80 |
| `0x4001c19c` | `4eb9400107d8` | jsr | charge utile (mémoire) +0xc14 | transpose | notes/80 |
| `0x4001c274` | `4eb9400cf9a8` | jmp | charge utile (mémoire), 2 cibles selon la combinaison | refmachine2, sampler | notes/60, notes/63 |
| `0x4001c3dc` | `4eb940025798` | jsr | masque `0x40173848` +0xa8 `lfo_ctor` | lfo-plus | notes/56 |
| `0x4001ca1e` | `2f034e93588f` | jsr | charge utile (mémoire), 9 cibles selon la combinaison | crush, eq, refchord, refmachine2, reso, ring, sampler, smpfilter, transpose | notes/60, notes/63, notes/66, notes/72, notes/73, notes/74, notes/75, notes/76, notes/80 |
| `0x4001cb3e` | `4eb94002d138` | jsr | masque `0x40179730` +0x0 `ck_ui_menu_ctor` | chord-keys | notes/42 |
| `0x4001cc86` | `2a004a8257c0` | jsr | charge utile (mémoire), 2 cibles selon la combinaison | refmachine2, sampler | notes/60, notes/63 |
| `0x4001d05e` | `4feffff07205` | jsr | charge utile (mémoire) +0x4c76 | sampler | notes/60 |
| `0x4001d0fc` | `4feffff47005` | jsr | charge utile (mémoire) +0x4d4a | sampler | notes/60 |
| `0x4001d25e` | `4eb940016086` | jsr | masque `0x4018a788` +0x1a | arp | notes/32 |
| `0x4001d5a2` | `20522f032f02` | jmp | masque `0x4018b9c8` +0x5c `cac_loop2` | control-all-config | notes/58 |
| `0x4001d6f8` | `20522668007c` | jmp | masque `0x4018b9c8` +0x38 `cac_loop1` | control-all-config | notes/58 |
| `0x4001d91c` | `2045e78ced88` | jsr | masque `0x40152d38` +0x4a `tco_dots` | trig-cond-order | notes/70 |
| `0x4001e4ca` | `4eb94000b22a` | jsr | masque `0x40183118` +0x13c `ck_shape_name` | chord-keys | notes/42 |
| `0x4001e8da` | `202f0020226a0068` | jsr | charge utile (mémoire), 29 cibles selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/54, notes/60, notes/63, notes/65, notes/71 |
| `0x4001ead8` | `24302c004a88` | jsr | charge utile (mémoire), 5 cibles selon la combinaison | crush, eq, reso, ring, smpfilter | notes/72, notes/73, notes/74, notes/75, notes/76 |
| `0x4001ebd2` | `205248780020` | jmp | masque `0x4018b9c8` +0x80 `cac_loop3` | control-all-config | notes/58 |
| `0x4001f886` | `487800024e94` | jsr | charge utile (mémoire), 8 cibles selon la combinaison | chordtables, crush, digidelay, eq, pots, reso, ring, smpfilter | notes/66, notes/68, notes/69, notes/72, notes/73, notes/74, notes/75, notes/76 |
| `0x40020ad0` | `47f9400cf9a8` | jsr | charge utile (mémoire) +0x908 | perform | notes/81 |
| `0x40020dca` | `202a00847207` | jsr | charge utile (mémoire), 3 cibles selon la combinaison | chordtables, digidelay, pots | notes/66, notes/68, notes/69 |
| `0x40021f56` | `2f034e944879404a8cb8…` | jsr | charge utile (image) +0x4f16 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x40022112` | `4eb9400cfc5e` | jsr | charge utile (mémoire), 2 cibles selon la combinaison | refmachine2, sampler | notes/60, notes/63 |
| `0x4002249c` | `4eb940072490` | jsr | masque `0x4015c044` +0x28 `th_press` | trig-hold | notes/33 |
| `0x400224ee` | `2f034eb9400724a0` | jmp | cave `0x401489fa` +0x0 | model-tg, model-tg-st, trig-preview | notes/31, notes/36 |
| `0x40022d44` | `4eb940072460` | jsr | masque `0x4015c044` +0x3a `th_hold` | trig-hold | notes/33 |
| `0x40022da6` | `4eb94006b736` | jsr | masque `0x4015c044` +0x6c `th_release` | trig-hold | notes/33 |
| `0x40022eac` | `2f034eb94007` | jmp | charge utile (mémoire), 2 cibles selon la combinaison | refmachine2, sampler | notes/60, notes/63 |
| `0x4002351a` | `2f024eb9400740ca` | jmp | cave `0x40148328` +0x0 | latching-mute, model-tg, model-tg-st | notes/31, notes/36 |
| `0x40025e10` | `4feffff02f0a` | jmp | masque `0x40173848` +0xf6 `lfo_gate` | lfo-plus | notes/56 |
| `0x4002cad0` | `4eb9400107d8` | jsr | charge utile (mémoire) +0xc14 | transpose | notes/80 |
| `0x4002d480` | `4cef7c7c0018` | jmp | masque `0x4016cae8` +0xc0 | arp | notes/32 |
| `0x4002f7d8` | `4cef7c7c0018` | jmp | charge utile (image) +0x11350 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x40032aee` | `4cef7c7c0018` | jmp | charge utile (mémoire) +0x7e0 | cpu | notes/78 |
| `0x40032aee` | `4cef7c7c0018` | jmp | charge utile (image) +0xd424 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4003560a` | `4eb940044df84a8057c0…` | jmp | masque `0x40192ba4` +0x0 `midi_key` | midi-live-both | notes/53 |
| `0x4004486c` | `4eb94005a274` | jsr | charge utile (mémoire), 5 cibles selon la combinaison | crush, eq, reso, ring, smpfilter | notes/72, notes/73, notes/74, notes/75, notes/76 |
| `0x4004486c` | `4eb94005a274` | jsr | masque `0x40166760` +0xaa `tf_boot` | track-filter | notes/47 |
| `0x4004df40` | `704c222f0004` | jmp | charge utile (mémoire), 3 cibles selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/54, notes/60, notes/63, notes/65, notes/71 |
| `0x4004df5c` | `7206202f0004` | jmp | charge utile (mémoire), 10 cibles selon la combinaison | acid, macro, macro-acid, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-vintage | notes/18, notes/36, notes/60, notes/63, notes/65, notes/71 |
| `0x4004df5c` | `4ef9401ae84e` | jmp | charge utile (mémoire), 7 cibles selon la combinaison | acid-tg, macro-acid-tg, macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36, notes/43, notes/54 |
| `0x4004df5c` | `7206202f0004` | jmp | charge utile (image) +0x470e | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4004df76` | `7205202f0004` | jmp | charge utile (mémoire), 10 cibles selon la combinaison | acid, macro, macro-acid, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-vintage | notes/18, notes/36, notes/60, notes/63, notes/65, notes/71 |
| `0x4004df76` | `4ef9401b278a` | jmp | charge utile (mémoire), 7 cibles selon la combinaison | acid-tg, macro-acid-tg, macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36, notes/43, notes/54 |
| `0x4004df76` | `7205202f0004` | jmp | charge utile (image) +0x864a | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4004dfa2` | `704c222f0004` | jmp | charge utile (mémoire), 3 cibles selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/54, notes/60, notes/63, notes/65, notes/71 |
| `0x40053a6c` | `4fefff8048d77cfc42af…` | jsr | OS `0x4008e6ba` | boot-anim | notes/39 |
| `0x40054d6a` | `23c040a78888` | jsr | charge utile (mémoire) +0x0 | perform | notes/81 |
| `0x40055510` | `23d640a78888` | jsr | charge utile (mémoire) +0x5c | perform | notes/81 |
| `0x4005571e` | `23d640a78888` | jsr | charge utile (mémoire) +0x5c | perform | notes/81 |
| `0x40055c62` | `23c240a78888` | jsr | charge utile (mémoire) +0x2e | perform | notes/81 |
| `0x40056610` | `4fefffd848d73cfc` | jmp | charge utile (image) +0xdbf6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400567d8` | `4eb94005802e` | jsr | charge utile (mémoire), 2 cibles selon la combinaison | digidelay, pots | notes/68, notes/69 |
| `0x4005699c` | `4eb940057488` | jsr | charge utile (mémoire), 2 cibles selon la combinaison | digidelay, pots | notes/68, notes/69 |
| `0x40056b38` | `4878000448798000b990` | jsr | charge utile (image) +0xab08 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400587f6` | `4eb940091f20` | jsr | masque `0x4018a788` +0x1b2 | arp | notes/32 |
| `0x40058ca0` | `a93c00000020` | jsr | masque `0x4015c044` +0x1f8 | 6ch-usbup, acid, macro, macro-acid, model-tg, model-tg-st, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31) | notes/31, notes/36 |
| `0x40058e28` | `72ff242a0008202a000c` | jsr | masque `0x4018a788` +0x0 | arp | notes/32 |
| `0x4005910e` | `4aaa0030670c2002` | jsr | masque `0x40183118` +0x0 `pv_copy` | sample-preview, sample-preview-st | notes/46 |
| `0x40059382` | `4eb94005979e` | jsr | charge utile (mémoire), 25 cibles selon la combinaison | cpu, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36, notes/78 |
| `0x40059392` | `4eb940002912` | jsr | masque `0x4015c044` +0x292 | 6ch-usbup, acid, macro, macro-acid, model-tg, model-tg-st, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31) | notes/31, notes/36 |
| `0x400593ce` | `4eb940002912` | jsr | masque `0x4015c044` +0x292 | 6ch-usbup, acid, macro, macro-acid, model-tg, model-tg-st, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31) | notes/31, notes/36 |
| `0x400597a8` | `4eb940058474` | jsr | charge utile (mémoire) +0xb1a | transpose | notes/80 |
| `0x400597c6` | `4eb940091ab2` | jsr | masque `0x401835b8` +0x8e `lfo_audio` | lfo-plus | notes/56 |
| `0x4005981e` | `4eb9400a7d4a` | jsr | charge utile (mémoire), 2 cibles selon la combinaison | digidelay, pots | notes/68, notes/69 |
| `0x4005981e` | `4eb9401b715c` | jsr | charge utile (mémoire) +0x3350e | syntakt-tg-* (1/33) | notes/31 |
| `0x40059852` | `4eb940056f58` | jsr | charge utile (mémoire), 5 cibles selon la combinaison | crush, eq, reso, ring, smpfilter | notes/72, notes/73, notes/74, notes/75, notes/76 |
| `0x40059852` | `4eb940056f58` | jsr | masque `0x4014ab5c` +0x0 `tf_post` | track-filter | notes/47 |
| `0x40059872` | `4eb9400567ba` | jsr | charge utile (mémoire) +0x0 | resample | notes/79 |
| `0x40059872` | `4eb9401b7b54` | jsr | charge utile (mémoire) +0x3353e | syntakt-tg-* (1/33) | notes/31 |
| `0x40059dea` | `76ff781533c38c000000` | jmp | charge utile (mémoire) +0x1118 | transpose | notes/80 |
| `0x40059dea` | `76ff781533c38c000000` | jmp | masque `0x40192734` +0x0 `td_led` | trigless-dim | notes/45 |
| `0x4005a31a` | `20065286eb88` | jmp | charge utile (mémoire), 13 cibles selon la combinaison | acid-tg, macro-acid-tg, macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36, notes/43, notes/54 |
| `0x4005a340` | `7005b085643e` | jmp | charge utile (mémoire), 28 cibles selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage | notes/31, notes/36, notes/43, notes/54, notes/60, notes/63, notes/65, notes/71 |
| `0x4005a4ea` | `202f0004b280` | jmp | masque `0x4016f8c8` +0xc0 `lfo_id2k` | lfo-plus | notes/56 |
| `0x4005a50a` | `724c202f0004` | jmp | charge utile (mémoire), 28 cibles selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage | notes/31, notes/36, notes/43, notes/54, notes/60, notes/63, notes/65, notes/71 |
| `0x4005a6a6` | `4ef9401ae8fc` | jmp | charge utile (mémoire), 13 cibles selon la combinaison | acid-tg, macro-acid-tg, macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36, notes/43, notes/54 |
| `0x4005a6a6` | `7205b2826430` | jmp | charge utile (image) +0x47bc | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4005a6b6` | `4ef9401ae936` | jmp | charge utile (mémoire), 13 cibles selon la combinaison | acid-tg, macro-acid-tg, macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36, notes/43, notes/54 |
| `0x4005a6b6` | `eb8a41f940a7` | jmp | charge utile (image) +0x47f6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4005a8f0` | `7405b4816532` | jmp | charge utile (mémoire), 3 cibles selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/54, notes/60, notes/63, notes/65, notes/71 |
| `0x4005aa22` | `202f000cb481` | jmp | masque `0x40185308` +0x82 `lfo_plk_load` | lfo-plus | notes/56 |
| `0x4005aa34` | `7417b480640c` | jmp | charge utile (mémoire), 9 cibles selon la combinaison | crush, eq, refchord, refmachine2, reso, ring, sampler, smpfilter, transpose | notes/60, notes/63, notes/66, notes/72, notes/73, notes/74, notes/75, notes/76, notes/80 |
| `0x4005aa34` | `7417b480640c` | jmp | masque `0x40166760` +0x8a `tf_conv` | track-filter | notes/47 |
| `0x4005aecc` | `4feffff448d71c00` | jmp | charge utile (mémoire), 9 cibles selon la combinaison | crush, eq, refchord, refmachine2, reso, ring, sampler, smpfilter, transpose | notes/60, notes/63, notes/66, notes/72, notes/73, notes/74, notes/75, notes/76, notes/80 |
| `0x4005aecc` | `4feffff448d7` | jmp | charge utile (image) +0x9b66 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4005aecc` | `4feffff448d7` | jmp | masque `0x40166760` +0x0 `tf_load` | track-filter | notes/47 |
| `0x4005af1c` | `41f94010eea8` | jsr | masque `0x40184df8` +0x0 `lfo_unpack` | lfo-plus | notes/56 |
| `0x4005afa0` | `4feffff448d71c00` | jmp | charge utile (mémoire), 9 cibles selon la combinaison | crush, eq, refchord, refmachine2, reso, ring, sampler, smpfilter, transpose | notes/60, notes/63, notes/66, notes/72, notes/73, notes/74, notes/75, notes/76, notes/80 |
| `0x4005afa0` | `4feffff448d7` | jmp | charge utile (image) +0x9ace | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4005afa0` | `4feffff448d7` | jmp | masque `0x4016616c` +0x0 `tf_save2` | track-filter | notes/47 |
| `0x4005b028` | `356b005e005c` | jsr | masque `0x40185308` +0x0 `lfo_pack` | lfo-plus | notes/56 |
| `0x4005b054` | `4feffff448d71c00` | jmp | charge utile (mémoire), 9 cibles selon la combinaison | crush, eq, refchord, refmachine2, reso, ring, sampler, smpfilter, transpose | notes/60, notes/63, notes/66, notes/72, notes/73, notes/74, notes/75, notes/76, notes/80 |
| `0x4005b054` | `4feffff448d7` | jmp | charge utile (image) +0x9ae8 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4005b054` | `4feffff448d7` | jmp | masque `0x4016616c` +0x1c `tf_save1` | track-filter | notes/47 |
| `0x4005b0dc` | `356b005e005c` | jsr | masque `0x40185308` +0x0 `lfo_pack` | lfo-plus | notes/56 |
| `0x4005b2ae` | `4fefffe448d77c0c` | jmp | charge utile (mémoire) +0x948 | perform | notes/81 |
| `0x4005b4a8` | `7001156b001c001c` | jmp | masque `0x4016b6f8` +0x14e `ck_storage_load_hook` | chord-keys | notes/42 |
| `0x4005b4b0` | `156b00260026` | jsr | charge utile (mémoire), 3 cibles selon la combinaison | chordtables, digidelay, pots | notes/66, notes/68, notes/69 |
| `0x4005b9c6` | `16b5480317420001` | jsr | masque `0x40185308` +0x60 `lfo_plk_save` | lfo-plus | notes/56 |
| `0x4006155e` | `420011400026` | jsr | charge utile (mémoire), 3 cibles selon la combinaison | chordtables, digidelay, pots | notes/66, notes/68, notes/69 |
| `0x40061564` | `1140001b48780010` | jmp | masque `0x4018d1b8` +0xea `ck_storage_init_hook` | chord-keys | notes/42 |
| `0x400618e2` | `e18b35430026` | jsr | masque `0x40184df8` +0x6c `lfo_init` | lfo-plus | notes/56 |
| `0x4007240c` | `206f00042028` | jmp | charge utile (image) +0x4828 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4007240c` | `206f00042028` | jmp | charge utile (mémoire), 2 cibles selon la combinaison | perform, resample | notes/79, notes/81 |
| `0x40081474` | `b08365000178` | jmp | charge utile (image) +0x10ffc | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4008171e` | `4ef9401b3210` | jmp | masque `0x40185968` +0x0 `pv_note` | sample-preview, sample-preview-st | notes/46 |
| `0x4008173c` | `b083650001ce` | jmp | charge utile (image) +0x10fb2 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x40081908` | `4ebaf2ec588f` | jsr | masque `0x40189930` +0x102 | arp | notes/32 |
| `0x40084b8e` | `487800222d48` | jmp | charge utile (image) +0x9d98 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x40084c14` | `721b4fef0028` | jmp | charge utile (image) +0x9e1e | model-tg, model-tg-st | notes/31, notes/36 |
| `0x40094c9a` | `71aa00084fef0020` | jmp | charge utile (image) +0xd606 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a2638` | `eb8c48780001` | jmp | charge utile (mémoire), 17 cibles selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/54, notes/60, notes/63, notes/65, notes/71 |
| `0x400a26a2` | `7850428545f9` | jmp | charge utile (mémoire), 24 cibles selon la combinaison | acid-tg, macro-acid, macro-acid-tg, macro-tg, syntakt-* (27/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36, notes/43, notes/54 |
| `0x400a2798` | `2f022f054e94` | jmp | masque `0x4018bb48` +0x24 `cac_loop5` | control-all-config | notes/58 |
| `0x400a40a2` | `b2806c047005` | jmp | charge utile (mémoire) +0x3319e | refmachine, refmachine2, sampler, solid | notes/60, notes/63, notes/65, notes/71 |
| `0x400a4dc4` | `700541e8000a` | jmp | charge utile (mémoire), 17 cibles selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/54, notes/60, notes/63, notes/65, notes/71 |
| `0x400a4fac` | `b2806c047005` | jmp | charge utile (mémoire) +0x331aa | refmachine, refmachine2, sampler, solid | notes/60, notes/63, notes/65, notes/71 |
| `0x400a5588` | `2eaa028c4e95` | jmp | masque `0x401904b4` +0x2a `ml_row` | multiline-browser | notes/40 |
| `0x400a55a4` | `4fef001c226e` | jmp | masque `0x401904b4` +0x5e `ml_after` | multiline-browser | notes/40 |
| `0x400a5612` | `20522f0a20680040` | jsr | masque `0x401904b4` +0x10 `ml_bound` | multiline-browser | notes/40 |
| `0x400a576e` | `4eb940071da4` | jsr | masque `0x401904b4` +0x102 `ml_icon` | multiline-browser | notes/40 |
| `0x400a6426` | `4eb9400a3052` | jsr | masque `0x40185c58` +0x0 `pv_parse` | sample-preview, sample-preview-st | notes/46 |
| `0x400a6426` | `4eb9400a3052` | jsr | charge utile (mémoire) +0x4c4e | sampler | notes/60 |
| `0x400a6602` | `4eb9400a3052` | jsr | charge utile (mémoire), 2 cibles selon la combinaison | refmachine2, sampler | notes/60, notes/63 |
| `0x400a6816` | `206800504e90` | jsr | charge utile (image) +0x116ac | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a7da8` | `2d41003c4a936730` | jmp | charge utile (image) +0x1f2a | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a7dfe` | `b08465224ef9` | jmp | charge utile (mémoire), 16 cibles selon la combinaison | acid-tg, macro-acid-tg, macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36, notes/43, notes/54 |
| `0x400a7dfe` | `b08465222046` | jmp | charge utile (mémoire), 12 cibles selon la combinaison | syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31) | notes/36 |
| `0x400a7e02` | `204622704c002f0a2f0e…` | jmp | charge utile (image) +0x2918 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a7e24` | `269522434280` | jmp | charge utile (mémoire), 13 cibles selon la combinaison | syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) | notes/31, notes/36 |
| `0x400a8906` | `287c8000caa8` | jmp | charge utile (image) +0xddf6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a956c` | `2f0a226f00084280` | jmp | charge utile (image) +0xddd6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a98c4` | `22115c8124730800` | jmp | charge utile (image) +0xdcda | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a9daa` | `4feffff448d70c04` | jmp | charge utile (image) +0xdcf8 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400aae88` | `4fefffe448d71c3c` | jmp | masque `0x40185968` +0x0 `chord_audio_update` | chord-keys | notes/42 |
| `0x400ab0e4` | `d1fc4012142c` | jmp | masque `0x4018cd48` +0x0 `chord_audio_ratios` | chord-keys | notes/42 |
| `0x400ab15e` | `4eb9400a8080` | jsr | charge utile (mémoire) +0x0 | chordtables, refchord | notes/66 |
| `0x400d97f8` | `2f4a0008245f` | jmp | masque `0x40173848` +0xcc `lfo_dtor` | lfo-plus | notes/56 |

## 5. Pointeurs réécrits

Constantes 32 bits de l'OS (tables de fonctions, données) qui pointent maintenant vers le code ou les données d'un mod. Même regroupement qu'au §4.

| adresse | ancien | vers | mods |
|---|---|---|---|
| `0x40000532` | `401bf3d8` | masque `0x4016cae8` +0x0 | acid-tg, macro-acid-tg, macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) |
| `0x4000a94e` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4000b214` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4000b236` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4000b3ec` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4000b47e` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4000b522` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4000b662` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4000b6f4` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4000b790` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4001d5ee` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4001d902` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4001e032` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4001f32e` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x40022a84` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x40022b06` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x40029e88` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4002b438` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x40046d64` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4004e32e` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a2be` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a2de` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a322` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a390` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a3aa` | `40a7ada4` | charge utile (mémoire), 4 valeurs selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a4f4` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a516` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a538` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a562` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a59a` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a5d8` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a60a` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a634` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a67a` | `4010dce8` | charge utile (mémoire) +0x34008 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a6ba` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | acid, macro, macro-acid, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a6f0` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a77e` | `4010dd00` | charge utile (mémoire) +0x34020 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a78a` | `4010dd00` | charge utile (mémoire) +0x34020 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a7bc` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a7dc` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a804` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a826` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a848` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a86a` | `4010dce0` | charge utile (mémoire) +0x34000 | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005a912` | `40a7ada4` | charge utile (mémoire), 4 valeurs selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x4005b998` | `4010ee4c` | charge utile (mémoire), 9 valeurs selon la combinaison | crush, eq, refchord, refmachine2, reso, ring, sampler, smpfilter, transpose |
| `0x4005b998` | `4010ee4c` | masque `0x40160e6c` +0x7c | track-filter |
| `0x4005baca` | `4010ee4c` | charge utile (mémoire), 9 valeurs selon la combinaison | crush, eq, refchord, refmachine2, reso, ring, sampler, smpfilter, transpose |
| `0x4005baca` | `4010ee4c` | masque `0x40160e6c` +0x7c | track-filter |
| `0x400a2614` | `401177e4` | charge utile (mémoire) +0x33800 | acid, macro, macro-acid, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-vintage |
| `0x400a2614` | `401bf51a` | charge utile (mémoire) +0x33800 | acid-tg, macro-acid-tg, macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) |
| `0x400a7d6c` | `40118628` | charge utile (mémoire), 8 valeurs selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31), syntakt-vintage |
| `0x400a7dc4` | `40118640` | charge utile (mémoire), 8 valeurs selon la combinaison | acid, acid-tg, macro, macro-acid, macro-acid-tg, macro-tg, refmachine, refmachine2, sampler, solid, syntakt-* (32/32), syntakt-*-acid (31/31), syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-* (33/33), syntakt-tg-*-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) |
| `0x400a7e16` | `40118610` | charge utile (mémoire), 2 valeurs selon la combinaison | acid, macro, macro-acid, refmachine, refmachine2, sampler, sdvintage-7th, solid, syntakt-vintage |
| `0x400fd150` | `4000ae20` | masque `0x401784e8` +0x58 | lfo-plus |
| `0x400fd170` | `4000a70e` | masque `0x40179730` +0xf8 | chord-keys |
| `0x400fd174` | `4000a66a` | masque `0x40185968` +0xba | chord-keys |
| `0x400fd190` | `4000ba7a` | masque `0x401784e8` +0x6c | lfo-plus |
| `0x400fd218` | `4000a980` | masque `0x40152d38` +0x12 | trig-cond-order |
| `0x400ff9cc` | `4001a0d2` | masque `0x40185018` +0x0 | chord-keys |
| `0x400ff9cc` | `4001a0d2` | charge utile (mémoire) +0x848 | transpose |
| `0x400ffe30` | `4001b22a` | charge utile (mémoire), 3 valeurs selon la combinaison | perform, refmachine2, sampler |
| `0x4010053c` | `4001e40a` | charge utile (mémoire), 2 valeurs selon la combinaison | refmachine2, sampler |
| `0x401005a8` | `4001e814` | charge utile (mémoire), 10 valeurs selon la combinaison | chordtables, crush, eq, refchord, refmachine2, reso, ring, sampler, smpfilter, transpose |
| `0x401005a8` | `4001e814` | masque `0x401625bc` +0x0 | track-filter |
| `0x40100ee8` | `40024078` | masque `0x4018cbc8` +0x0 | control-all-config |
| `0x40100f98` | `40023d8c` | masque `0x4018d038` +0x0 | control-all-config |
| `0x401016e4` | `40024e86` | masque `0x40184df8` +0x88 | lfo-plus |
| `0x401016ec` | `400426fa` | masque `0x401780a8` +0xa2 | lfo-plus |
| `0x40102578` | `400299de` | charge utile (mémoire), 2 valeurs selon la combinaison | refmachine2, sampler |
| `0x40118614` | `400ab6e8` | charge utile (mémoire) +0x31196 | sdvintage-exact |
| `0x40118614` | `400ab6e8` | masque `0x4018a788` +0x0 | sdvintage-snare |
| `0x4011862c` | `400ab3b0` | charge utile (mémoire) +0x31000 | sdvintage-exact |
| `0x4011862c` | `400ab3b0` | masque `0x4016cae8` +0x0 | sdvintage-snare |

## 6. Saved data (declared claims, notes/65)

What the writes do not show: where each mod keeps its values, in a sound's parameters (k), in a sound's record and elsewhere in the saved structures. From the declared claims (`tools/claims.py`: a package's manifest, a part's `part.json`, the tweaks' `claims/claims.json`): a mod that keeps a value adds its claim there, with its note. A value scoped to a machine is kept on that machine's sounds only. Two mods that can be ticked together never share a number in scopes that meet (`tools/check_overlaps.py`). The RAM where payloads run is in §3; the state mods keep in their masks, in §1.

### Sound parameters k

| k | held by |
|---|---|
| 0–22 | the OS |
| 23–24 | model-tg, model-tg-st |
| 25–27 | model-tg, model-tg-st; sampler (SAMPLE's sounds) |
| 28 | fltslot (part); lfo-plus; refmachine2 (REF2's sounds); shortcuts (part); track-filter |
| 29 | fltslot (part); lfo-plus; shortcuts (part); track-filter |
| 30 | fltslot (part); lfo-plus; refchord (CHORD's sounds); shortcuts (part); track-filter |
| 31 | fltslot (part); lfo-plus; shortcuts (part); track-filter |
| 32 | lfo-plus; refmachine2 (REF2's sounds); sampler (SAMPLE's sounds); shortcuts (part) |

### Record slots (`+28 + 2 · slot` of a sound's record)

| slot | held by |
|---|---|
| 0–17 | the OS |
| 18 | refmachine2 (REF2's sounds); sampler (SAMPLE's sounds); shortcuts (part); track-filter |
| 19–23 | the OS |
| 24–26 | model-tg, model-tg-st; sampler (SAMPLE's sounds) |
| 27 | model-tg, model-tg-st; sampler (SAMPLE's sounds); track-filter |
| 28 | fltslot (part); model-tg, model-tg-st; refmachine2 (REF2's sounds); shortcuts (part) |
| 29 | fltslot (part); model-tg, model-tg-st; shortcuts (part) |
| 30 | fltslot (part); lfo-plus; refchord (CHORD's sounds); shortcuts (part); track-filter |
| 31 | fltslot (part); lfo-plus; shortcuts (part); track-filter |

### Other saved bytes, and RAM outside the payloads

| mod | what | source |
|---|---|---|
| arp | pattern, track +512: 1 byte | notes/32 |
| chord-keys | pattern, header +32: 4 bytes | notes/42 §4, §11, §12.4 |
| chord-keys | pattern, header +40: 24 bytes | notes/42 §4, §11, §12.4 |
| chordtables | pattern, header +36: 2 bytes | tools/machines/chordtables/manifest.json |
| chordtables | RAM `0x43400000`..`0x43700000` | tools/machines/chordtables/manifest.json |
| chordtables | RAM `0x80001c5c`..`0x800074b4` | tools/machines/chordtables/manifest.json |
| chordtables | RAM `0x8000cac0`..`0x8000eae0` | tools/machines/chordtables/manifest.json |
| fxslot (part) | pattern, header +29: 3 bytes | tools/machines/fxslot/part.json |
| lfo-plus | RAM `0x4233f000`..`0x4233f49c` | notes/56 §3 |
| resample (part) | RAM `0x42800000`..`0x43000000` | tools/machines/resample/part.json |
| sampler | RAM `0x43800000`..`0x46700000` | tools/machines/sampler/manifest.json |

## 7. Ce que chaque mod touche

Nombre d'écritures de chaque sorte (une plage pour une famille de moteurs).

| mod | écritures | patchs | crochets | pointeurs | masques | redirections | caves | charge utile (image) | note |
|---|---|---|---|---|---|---|---|---|---|
| latching-mute | 8 | 3 | 1 | 0 | 0 | 0 | 4 |  |  |
| trig-preview | 6 | 0 | 1 | 0 | 0 | 0 | 5 |  |  |
| browser-scroll | 5 | 1 | 0 | 0 | 0 | 0 | 4 |  |  |
| 6ch-multiout | 29 | 25 | 4 | 0 | 0 | 0 | 0 |  |  |
| 6ch-usbup | 25 | 12 | 7 | 0 | 5 | 1 | 0 |  | notes/36 |
| sdvintage-snare | 10 | 4 | 0 | 2 | 2 | 2 | 0 |  | notes/16 |
| sdvintage-exact | 9 | 4 | 1 | 2 | 1 | 1 | 0 | 205 200 o | notes/17 |
| sdvintage-7th | 116 | 58 | 9 | 47 | 1 | 1 | 0 | 218 208 o | notes/18 |
| syntakt-vintage | 117 | 57 | 11 | 47 | 1 | 1 | 0 | 218 560 o |  |
| syntakt-* (32 tweaks) | 124 | 56–57 | 16–17 | 47 | 2 | 2 | 0 | 260 352–269 056 o | notes/36 |
| syntakt-*-acid (31 tweaks) | 124 | 56 | 17 | 47 | 2 | 2 | 0 | 145 736–157 290 o | notes/36 |
| syntakt-*-macro (31 tweaks) | 124 | 56 | 17 | 47 | 2 | 2 | 0 | 230 410–241 962 o | notes/36 |
| syntakt-*-macro-acid (31 tweaks) | 124 | 56 | 17 | 47 | 2 | 2 | 0 | 235 642–247 168 o | notes/36 |
| macro | 122 | 56 | 14 | 48 | 2 | 2 | 0 | 105 152 o | notes/36 |
| macro-acid | 122 | 55 | 15 | 48 | 2 | 2 | 0 | 111 760 o | notes/36 |
| acid | 122 | 56 | 14 | 48 | 2 | 2 | 0 | 11 380 o | notes/36 |
| sampler | 140 | 52 | 32 | 54 | 1 | 1 | 0 | 50 484 o | notes/60 |
| refmachine | 116 | 52 | 14 | 48 | 1 | 1 | 0 | 6 992 o | notes/65 |
| refmachine2 | 134 | 52 | 26 | 54 | 1 | 1 | 0 | 11 620 o | notes/63 |
| model-tg | 142 | 94 | 32 | 0 | 1 | 1 | 14 | 87 936 o | notes/36 |
| model-tg-st | 142 | 94 | 32 | 0 | 1 | 1 | 14 | 87 936 o | notes/31 |
| syntakt-tg-* (33 tweaks) | 117–119 | 51 | 17–19 | 47 | 1 | 1 | 0 | 227 760–243 904 o | notes/31, notes/36 |
| syntakt-tg-*-acid (31 tweaks) | 117 | 51 | 17 | 47 | 1 | 1 | 0 | 145 997–157 538 o | notes/36 |
| syntakt-tg-*-macro (31 tweaks) | 117 | 51 | 17 | 47 | 1 | 1 | 0 | 230 680–242 230 o | notes/36 |
| syntakt-tg-*-macro-acid (31 tweaks) | 117 | 51 | 17 | 47 | 1 | 1 | 0 | 235 909–247 441 o | notes/36 |
| macro-acid-tg | 114 | 50 | 15 | 47 | 1 | 1 | 0 | 112 092 o | notes/54 |
| macro-tg | 114 | 50 | 15 | 47 | 1 | 1 | 0 | 105 564 o | notes/43 |
| sample-preview | 11 | 0 | 3 | 0 | 4 | 4 | 0 |  | notes/46 |
| sample-preview-st | 11 | 0 | 3 | 0 | 4 | 4 | 0 |  | notes/46 |
| refchord | 13 | 0 | 8 | 3 | 1 | 1 | 0 | 2 256 o | notes/66 |
| acid-tg | 114 | 50 | 15 | 47 | 1 | 1 | 0 | 11 792 o | notes/54 |
| chordtables | 10 | 0 | 7 | 1 | 1 | 1 | 0 | 4 756 o | notes/66 |
| digidelay | 10 | 0 | 8 | 0 | 1 | 1 | 0 | 3 884 o | notes/68 |
| arp | 14 | 0 | 6 | 0 | 4 | 4 | 0 |  | notes/32 |
| trig-hold | 5 | 0 | 3 | 0 | 1 | 1 | 0 |  | notes/33 |
| tempo-max | 12 | 12 | 0 | 0 | 0 | 0 | 0 |  | notes/38 |
| boot-anim | 1 | 0 | 1 | 0 | 0 | 0 | 0 |  | notes/39 |
| multiline-browser | 16 | 10 | 4 | 0 | 1 | 1 | 0 |  | notes/40 |
| chord-keys | 37 | 0 | 6 | 3 | 14 | 14 | 0 |  | notes/42 |
| level-pan-values | 8 | 1 | 3 | 0 | 2 | 2 | 0 |  | notes/44 |
| trigless-dim | 8 | 1 | 3 | 0 | 2 | 2 | 0 |  | notes/45 |
| track-filter | 40 | 1 | 6 | 3 | 15 | 15 | 0 |  | notes/47 |
| control-all-config | 15 | 0 | 5 | 2 | 4 | 4 | 0 |  | notes/58 |
| midi-both | 3 | 3 | 0 | 0 | 0 | 0 | 0 |  | notes/53 |
| midi-live-both | 6 | 0 | 4 | 0 | 1 | 1 | 0 |  | notes/53 |
| lfo-plus | 30 | 0 | 12 | 4 | 7 | 7 | 0 |  | notes/56 |
| pots | 10 | 0 | 8 | 0 | 1 | 1 | 0 | 7 632 o | notes/69 |
| solid | 117 | 52 | 15 | 48 | 1 | 1 | 0 | 20 512 o | notes/71 |
| smpfilter | 15 | 0 | 10 | 3 | 1 | 1 | 0 | 26 848 o | notes/72 |
| crush | 15 | 0 | 10 | 3 | 1 | 1 | 0 | 9 340 o | notes/73 |
| ring | 15 | 0 | 10 | 3 | 1 | 1 | 0 | 12 360 o | notes/74 |
| reso | 15 | 0 | 10 | 3 | 1 | 1 | 0 | 14 728 o | notes/75 |
| eq | 15 | 0 | 10 | 3 | 1 | 1 | 0 | 21 396 o | notes/76 |
| cpu | 5 | 0 | 3 | 0 | 1 | 1 | 0 | 2 756 o | notes/78 |
| resample | 6 | 1 | 3 | 0 | 1 | 1 | 0 | 17 164 o | notes/79 |
| trig-cond-order | 4 | 0 | 1 | 1 | 1 | 1 | 0 |  | notes/70 |
| transpose | 19 | 0 | 13 | 4 | 1 | 1 | 0 | 4 504 o | notes/80 |
| perform | 18 | 0 | 15 | 1 | 1 | 1 | 0 | 11 104 o | notes/81 |

## 8. Key combinations (declared claims, notes/65)

The combinations each mod answers: the held keys, then one action, in the words `tools/claims.py` lists. Two mods that can be ticked together never take one combination with another meaning in situations and scopes that meet (`tools/check_overlaps.py`). A mod that takes a stock combination (the second table) says what it replaces, or `tools/claims.py --check` refuses it.

| combination | situation | held by | meaning | replaces |
|---|---|---|---|---|
| FUNC + DATA-PRESS | menu:MIDI-PORTS | midi-live-both | adds the Cycles' own MIDI to THRU, or takes it away |  |
| FUNC + PITCH | params | macro, macro-acid, macro-acid-tg, macro-tg, syntakt-*-macro (31/31), syntakt-*-macro-acid (31/31), syntakt-tg-*-macro (31/31), syntakt-tg-*-macro-acid (31/31) (MACRO's tracks) | FINE as lo-fi RATE / BITS | FINE, the fine adjust of PITCH |
| LFO | page:LFO | lfo-plus | LFO 2, 3 and 4, then the page closes | closes the LFO page |
| LFO + RETRIG + SWEEP/CONTOUR/COLOR/SHAPE | params | fltslot (part) | the track filter's value becomes the LFO's destination |  |
| MACHINES | any | shortcuts (part) | on the tracks of a machine with a shortcut or a switch (on every track in a build with Transpose, since 0.6), the MACHINES list opens on the release, unless a shortcut or a switch acted | the toggle of the MACHINES list on the press (a press while it is open still closes it at once) |
| MACHINES + COLOR | params | refmachine2 (REF2's tracks) | Octave |  |
| MACHINES + COLOR/SHAPE/SWEEP/CONTOUR | params | shortcuts (part) | the shortcut of the track's machine |  |
| MACHINES + COLOR/SHAPE/SWEEP/CONTOUR | params | track-filter | Filter Env / Env Decay / Filter Cutoff / Filter Reso |  |
| MACHINES + DECAY/SWEEP/CONTOUR | params | model-tg, model-tg-st | Attack / Filter / Resonance |  |
| MACHINES + GATE | any | refmachine2 (REF2's tracks) | Tone open |  |
| MACHINES + GATE | any | sampler (SAMPLE's tracks) | Reverse |  |
| MACHINES + PUNCH | any | refmachine2 (REF2's tracks) | Square |  |
| MACHINES + PUNCH | any | sampler (SAMPLE's tracks) | Loop |  |
| MACHINES + PUNCH/GATE | any | shortcuts (part) | the switch of the track's machine |  |
| MACHINES + SWEEP | params | refchord (CHORD's tracks) | Wavetable |  |
| MACHINES + TRIG 15/TRIG 16 | keys | transpose (part) | the TRIG keyboard an octave down / up, two at most, on top of KBT | plays the note on the TRIG keyboard, as without MACHINES |
| MACHINES + TRIG 8/TRIG 9/TRIG 11/TRIG 12 | keys | transpose (part) | the active track's pitch jumps -7 / -5 / +5 / +7 semitones from its PITCH; the jump in force again: back | plays the note on the TRIG keyboard, as without MACHINES |
| PATTERN + REVERB-SIZE/DELAY-TIME | params | fxslot (part) | the shown pattern's effect in the reverb or delay slot | the knob's edit while PATTERN is held; the pattern selection is disarmed as in the stock OS, and since 0.6 it no longer waits after PATTERN is released |
| PATTERN + SWEEP | params | chordtables (CHORD's tracks) | the pattern's wavetable, on CHORD's tracks | disarms the pattern selection, then edits SWEEP as without PATTERN |
| RETRIG + NOTES | any | arp | an arpeggio of the held notes when Arp is not OFF | the retrig |
| RETRIG + PITCH | params | fltslot (part) | the sound's filter: none or one of the build's |  |
| RETRIG + SWEEP/CONTOUR/COLOR/SHAPE | params | fltslot (part) | the track filter's values: Cutoff, Reso, Env depth, AD |  |
| RETRIG + TRIG 1-16 | keys | chord-keys (CHORD's tracks) | the same chords, never retrigged (the note helper 0x40019e7a gets retrig -1) | the retrig |
| SETTINGS + PATTERN | any | perform (part) | switches the Perform Kit mode on and off | arms the pattern selection, as PATTERN without SETTINGS |
| SETTINGS + RECORD | any | resample (part) | opens the RESAMPLE page (RECORD on it arms, RETURN or SETTINGS + RECORD closes it) | the toggle of GRID RECORDING while SETTINGS is held (notes/79 §1) |
| TRACK + FUNC | any | latching-mute | latches the mute mode |  |
| TRACK + TRIG 1-6 | any | control-all-config | takes the track out of Control All, or back |  |
| TRIG 1-16 | keys | chord-keys (CHORD's tracks) | the chords of a scale, in the Keys mode of the retrig menu | the chromatic notes of the stock KeyboardView (0x4001a0d2), on a CHORD track with Keys ON |
| TRIG 1-16 + MACHINES | any | shortcuts (part) | on the tracks of a machine with a switch, the PRESET browser opens on the release of MACHINES, unless a switch acted | the PRESET browser on the press |
| TRIG 1-16 + MACHINES + PUNCH/GATE | any | shortcuts (part) | on the tracks of a machine with a switch, that switch of each held step as a p-lock of k 32 |  |
| TRIG 1-16 + PAGE | grid | trig-preview | the held step sounds, sequencer stopped or paused | PAGE turns the page |

The stock combinations, as far as they are read:

| combination | situation | meaning | source |
|---|---|---|---|
| FUNC + PITCH/DECAY/COLOR/SHAPE/SWEEP/CONTOUR | params | fine adjust | notes/63 §1.2 |
| TRACK + PITCH/DECAY/COLOR/SHAPE/SWEEP/CONTOUR | params | Control All | notes/63 §1.2 |
| LFO + PITCH/DECAY/COLOR/SHAPE/SWEEP/CONTOUR | params | the parameter becomes the LFO's destination | notes/63 §1.2 |
| TRIG 1-16 + PITCH/DECAY/COLOR/SHAPE/SWEEP/CONTOUR | params | parameter lock | notes/63 §1.3 |
| FUNC + DELAY-SEND/REVERB-SEND/LFO-SPEED/VOLUME-DIST/SWING/CHANCE | params | fine adjust | notes/68 §8.2 |
| FUNC + REVERB-SIZE/DELAY-TIME | params | Reverb Tone, Delay Fdbk | notes/68 §8.2 |
| TRACK + REVERB-SIZE/DELAY-TIME | params | edits as without TRACK (no Control All) | notes/68 §8.4 |
| TRIG 1-16 + SWING/CHANCE | params | Trig Nudge, Trig Cond | notes/68 §8.2 |
| PATTERN + PITCH/DECAY/COLOR/SHAPE/SWEEP/CONTOUR/DELAY-SEND/REVERB-SEND/LFO-SPEED/VOLUME-DIST/SWING/CHANCE/REVERB-SIZE/DELAY-TIME | params | disarms the pattern selection (its LED goes out), then edits as without PATTERN | 0x4001f50c; the maintainer's test, 2026-10-31 |
| PATTERN + TRIG 1-16 | any | chooses the next pattern | 0x40020a8c |
| PATTERN | any | arms the pattern selection | 0x40020ad0 |
| MACHINES | any | opens the MACHINES list, which passes PUNCH, GATE and every knob but LEVEL/DATA on | 0x4001ca1e, 0x400a292c, 0x400a28b4 |
| TRACK + PUNCH/GATE | any | Control All of PUNCH and GATE | STANDARD.md §5.4 |
| PUNCH/GATE | any | switches PUNCH or GATE on the selected track; a held RETRIG or MACHINES is not read | notes/63 §15.1; the MACHINES list passes them on (0x400a292c) |
| FUNC + PUNCH/GATE | any | opens a view | notes/63 §15.1 |
| FUNC + TRACK | any | the Track Setup menu | STANDARD.md §5.4 |
| FUNC + MACHINES | any | the PRESET browser | STANDARD.md §5.4 |
| TRIG 1-16 + MACHINES | any | the PRESET browser, on the press; a preset chosen while the trig is held locks it to the trig | 0x4001c27c, 0x400a6c44, 0x400a7112; notes/63 §24 |
| TRIG 1-16 + PUNCH/GATE | any | toggles a p-lock of PUNCH or GATE on the held steps | 0x400224ae, 0x40022eac; notes/63 §29 |
| FUNC + RETRIG | any | the retrig menu | notes/63 §1.2 |
| TRACK + RECORD/PLAY/STOP | any | copy, clear, paste | notes/58 §2 |
| RETRIG + NOTES | any | the retrig | notes/63 §1.2, notes/32 |
| TRIG 1-16 + PAGE | grid | PAGE turns the page | notes/34 |
| SETTINGS | any | a tap opens the settings menu; held, the question to save the project (after 1 s) | 0x4001c54c, 0x40039570; the maintainer's test, 2026-11-03 |
| SETTINGS + RECORD | any | toggles GRID RECORDING (SETTINGS is not read); the release of SETTINGS after it is not a tap and opens nothing | 0x4002439a, 0x40024482, the key scanner 0x4007fbde; notes/79 §1 |
| LFO | page:LFO | closes the LFO page (a hypothesis) | notes/65 §3.2 |

## 9. Descriptors, formatters, pictures, p-lock rows and MIDI (declared claims, notes/65)

Two mods that can be ticked together never share one of these in scopes that meet; a formatter and a picture belong to their interface object, whatever the scopes (notes/65 §12.2, STANDARD.md draft 0.8). A MIDI claim is checked against the other mods and, since 2026-11-11, against the stock OS's map in the last rows, which `tools/claims.py` refuses to a mod (notes/65 §17; STANDARD.md §5.5 has no stock map yet).

| claim | held by |
|---|---|
| descriptors 1–4 | fltslot (part); shortcuts (part); track-filter |
| descriptors 10 | chordtables (CHORD's tracks) |
| the formatter of interface object 53 | sampler (Cutoff) |
| the picture of interface object 53 | sampler (Cutoff) |
| the picture of interface object 54 | sampler (Reso) |
| the p-lock rows of k ≥ 23 | lfo-plus; shortcuts (part); track-filter |
| CC 75, 76 | fltslot (part) |
| CC 71, 74 | fltslot (part); track-filter |
| NRPN 1:22, 1:23 | fltslot (part) |
| NRPN 1:20, 1:21 | fltslot (part); track-filter |
| CC 3, 7, 10, 12–19, 65–67, 70, 80, 85–88, 93–95, 102–110 | the stock OS (Model:Cycles manual, appendix A; Solo, its descriptor 7) |
| CC 20–23 | nothing: the machines' window, looked up in the row of the track's machine only |
| CC 6, 38, 96–101, 120–127 | MIDI's own: data entry, (N)RPN, channel mode |
| NRPN 1:26–1:30, 1:32–1:39, 1:100–1:103, 2:0, 2:3, 2:9, 2:12, 3:0 | the stock OS (its tables at boot, its descriptor table) |

## 10. Views (declared claims, notes/65)

A machine draws on its own tracks; when two machines are built together, their draws go through the dispatchers (notes/63 §4). A draw on every track next to a machine's is a warning, not a conflict (notes/65 §5.4): only a look on the device tells whether they share the screen well.

| view | drawn by |
|---|---|
| knob | refmachine2 (REF2's tracks); sampler (SAMPLE's tracks) |
| main | level-pan-values (every track): its own hooks, 0x400081f2 and 0x4001aa4e; refmachine2 (REF2's tracks); sampler (SAMPLE's tracks) |
| note | refmachine2 (REF2's tracks); sampler (SAMPLE's tracks) |

