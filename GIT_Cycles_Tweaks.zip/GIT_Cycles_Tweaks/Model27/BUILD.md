# Construire un firmware modifié

> ⚠️ Aucune image firmware Elektron n'est fournie ici. Tu apportes **ta propre** copie de l'OS officiel,
> téléchargée sur elektron.se. Flasher un firmware modifié se fait **à tes risques** (garantie, brick possible).
> Une **interface MIDI reliée au MIDI IN** de l'appareil (jack TRS : câble jack stéréo depuis une sortie TRS,
> ou adaptateur DIN fourni) est obligatoire pour pouvoir revenir en arrière (STARTUP MENU).

## Chaîne d'outils

Python 3 uniquement, aucune dépendance externe, aucun compilateur. Le moteur bas niveau
(`tools/mtlib/`, transport SysEx + codec aPLib + conteneur ELE3/HMAC) vient de
[`drumkilla/elektron-model-tweaks`](https://github.com/drumkilla/elektron-model-tweaks) (MIT, voir `tools/mtlib/LICENSE`).
L'orchestration (`tools/build.py`) et les tables de patchs (`tweaks/`) sont propres à ce dépôt.

## Étapes

1. Télécharge `model-cycles_OS1.13.zip` sur elektron.se, dézippe-le pour obtenir `model-cycles_OS1.13.syx`
   (SHA-256 attendu `44fe5862…9800640c`).
2. Liste les patchs disponibles :
   ```sh
   python3 tools/build.py --list
   ```
3. Construis l'image. Il y a deux variantes du 6 canaux, **incompatibles entre elles** :
   ```sh
   python3 tools/build.py -i model-cycles_OS1.13.syx -t 6ch-multiout   # référence (casse l'upgrade USB)
   python3 tools/build.py -i model-cycles_OS1.13.syx -t 6ch-usbup      # garde l'upgrade USB (celle du flasher web)
   ```
   Et la machine **SD VINTAGE** (à la place de SNARE, [note 14](notes/14-machine-sd-vintage.md)), seule ou avec un 6 canaux :
   ```sh
   python3 tools/build.py -i model-cycles_OS1.13.syx -t sdvintage-snare
   python3 tools/build.py -i model-cycles_OS1.13.syx -t 6ch-usbup,sdvintage-snare
   ```
   Et les trois tweaks de [drumkilla](https://github.com/drumkilla/elektron-model-tweaks) (fichiers `01`–`03` de `tweaks/`,
   MIT) : `latching-mute`, `trig-preview`, `browser-scroll`. Notre build donne le **même MAIN OS, octet pour octet**, que leur
   propre `tweak.py` (vérifié pour chacun et pour les trois ensemble). La retouche de `trig-preview` du 04/10/2026 (le séquenceur
   en pause accepté, 3 octets, [note 34](notes/34-ecoute-en-pause.md)) est dans leur 1.2.0 : depuis le 30/10/2026, le fichier `02`
   est le leur, inchangé (note 34 §6).
   ```sh
   python3 tools/build.py -i model-cycles_OS1.13.syx -t 6ch-usbup,latching-mute,trig-preview,browser-scroll
   ```
   Et le **vrai moteur SD VINTAGE du Syntakt** ([note 17](notes/17-portage-exact-syntakt.md)), extrait au build de **ton** fichier Syntakt
   (aucun octet Elektron dans le dépôt : le tweak ne contient qu'une recette de copie et une table de relocalisation).
   L'OS Syntakt 1.42 ou 1.41 : même programme audio, donc même résultat ([note 16 §1](notes/16-moteur-syntakt.md#os-142--même-programme-audio)) :
   ```sh
   python3 tools/build.py -i model-cycles_OS1.13.syx -t 6ch-usbup,sdvintage-exact --syntakt Syntakt_OS1.42.syx
   ```
   Ou le même moteur en **7ᵉ machine « SDVtg »**, SNARE restant la SNARE d'origine ([note 18](notes/18-septieme-machine.md)) :
   ```sh
   python3 tools/build.py -i model-cycles_OS1.13.syx -t 6ch-usbup,sdvintage-7th --syntakt Syntakt_OS1.42.syx
   ```
   Ou n'importe quel choix de moteurs du Syntakt en machines ajoutées ([note 20](notes/20-moteurs-syntakt-a-cocher.md)) :
   `sdvintage-7th` (SD), `syntakt-vintage` (SD + CP), et `syntakt-<moteurs>` pour les autres choix parmi `sd`, `cp`, `toy`,
   `bits`, `swarm` (dans cet ordre : `syntakt-toy`, `syntakt-bits`, `syntakt-swarm`, `syntakt-sd-cp-toy-bits-swarm`…
   [notes 21](notes/21-sy-bits.md) et [22](notes/22-sy-swarm.md)). Un seul à la fois :
   ```sh
   python3 tools/build.py -i model-cycles_OS1.13.syx -t 6ch-usbup,syntakt-sd-cp-toy-bits-swarm --syntakt Syntakt_OS1.42.syx
   ```
   → écrit `model-cycles_OS1.13_mod.syx` à côté. `-t a,b` combine plusieurs patchs compatibles.
   `--all` applique tout, mais refuse si deux patchs sont incompatibles (c'est le cas de ces deux variantes).

Le build vérifie chaque octet `old` avant écriture, contrôle le SHA-256 de la section 3 d'origine,
et recalcule tous les checksums + le HMAC-SHA256. Seule la **section 3 (MAIN OS)** est touchée :
bootloader et updater sont conservés à l'identique.

Pour un patch qui écrit dans une zone `0xFF` (une « cave »), comme `6ch-usbup` ou `sdvintage-snare`, le build affiche la zone :
du début du bloc `0xFF` à la fin des octets écrits.
Il **refuse** si l'image d'origine contient un pointeur vers elle : `--force-cave` passe outre, après vérification à la main.
Exception : un pointeur que les patchs choisis réécrivent eux-mêmes, vers une adresse hors de la zone, est affiché « neutralisé » et ne bloque pas.
Autre exception, vérifiée à la main et listée dans `device.json` (`cave_refs_ok`) : une référence dont seule une partie de la
zone est lue. C'est le cas de `browser-scroll` : il écrit dans la table caractère → glyphe de la petite police de chiffres
(`0x401485ee`, 256 entrées de 16 bits, `0xFFFF` = pas de glyphe), aux entrées des caractères de contrôle 1 à 8, jamais dessinés.
La référence ne bloque plus tant que toutes les écritures restent dans la partie déclarée libre ; une écriture qui en sort est refusée.
C'est le cas des sprites dont on libère le masque `0xFF` en les redirigeant vers un masque identique
([note 14 §5](notes/14-machine-sd-vintage.md#5-place-libre--les-caves-0xff-étaient-des-masques-de-sprites), `tools/sprites.py`).
Les références relatives (`(d16,PC)`, branchements) sont seulement signalées, car une donnée peut les imiter.
Détails : [`notes/13-6ch-upgrade-usb.md`](notes/13-6ch-upgrade-usb.md) §4.

### Vérification de reproductibilité

Le patch 6 canaux doit produire un **MAIN OS décompressé** de SHA-256
`65e24b50dd457444e87daea79dd41b82f61098cb8ae5cd27cbe0d91742f29555`
(identique au résultat connu-bon de `ms-multi-output`). Pour l'exiger :
```sh
python3 tools/build.py -i model-cycles_OS1.13.syx -t 6ch-multiout \
    --expect-mainos 65e24b50dd457444e87daea79dd41b82f61098cb8ae5cd27cbe0d91742f29555
```
Le hash du `.syx` lui-même varie selon le packer ; c'est le MAIN OS décompressé qui fait foi.

Les autres patchs n'ont pas de résultat connu-bon extérieur. Voici ce que donne `build.py` sur l'OS 1.13 officiel
(le flasher web exige les mêmes valeurs pour celles qu'il propose) :

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `6ch-usbup` | `57fa258f209c10359f6888af79087f656e994930ff86ffcc1e2e2e48512d9530` |
| `sdvintage-snare` (v2, recalée sur le Syntakt) | `11049726efa102028f7365b0a672c8a244b98edcef5e7c8b5e0aafba369f60d3` |
| `6ch-multiout,sdvintage-snare` | `80d0d717c5054f9277c2ddadb588e3578968cc1427610c7367ee408fa8ffd2de` |
| `6ch-usbup,sdvintage-snare` | `9416ac0b7f0bffda6b91490aacf1b00f831196466f5f64dc87b3a3b63cbc9ccb` |
| `latching-mute,trig-preview,browser-scroll` | `c6aea7e51d1caf3e9be4553f3a0c5b033592d804cb25226ef9df3fd19add8c08` (`tweak.py` de drumkilla avant sa 1.2.0, sans la retouche de note 34 : `71fef138…`) |
| `6ch-usbup,latching-mute,trig-preview,browser-scroll` | `b8911cb1692476c266fdad6fae7bdabd824bd8976149cc5a2baae4dfb9252176` |

| `sdvintage-exact` (avec `--syntakt Syntakt_OS1.42.syx`) | `8e2290a79fb1406ce65b3af3c5d3d95faade666e98eb8ecce0c0fa25fe87b15d` |
| `6ch-usbup,sdvintage-exact` (idem) | `bd729d526c992fb5d678a1a2793d012fdcec47f6584631fc01afa896483fc061` |
| `syntakt-vintage` (idem) | `b4de3ec5f7eda7504bf03e7141f57bae6cf5bc137d39f6704da60881d56ed9b0` |
| `sdvintage-7th` (idem) | `c73ad4c796b94ab39d106d0798091eb39b5e3e31f66d7fe78e2db30db44daad3` |
| `syntakt-cp` (idem) | `e9e3a8c7aa438a00cc028574b78dac33a6b7a44cdf98623eaa1edcf4668ac1ee` |
| `syntakt-toy` (idem) | `a3d8fad221ed0920ec15ea0e791e3be3e869b04b147affefcda4108d0248796c` |
| `syntakt-sd-cp-toy` (idem) | `ea04669bbe10d83505cd9c2b4654f46c53dd1fc55d4d5229d2cad33c6e5f0a0e` |
| `syntakt-bits` (idem) | `0e73d4f76bb947db6392b7e1e1547f2951ec8fe1924668bec532ee9b531f93bd` |
| `syntakt-sd-cp-toy-bits` (idem) | `c6add70bea5a1f6d0d4bf6aa26ae454dc6f873c6ab55937edbd7d9ad7d96c86c` |
| `syntakt-swarm` (idem) | `b47c9d7d2fb8d9568503033a3d0f318396c4b52b8df34c081564005c92b69517` |
| `syntakt-sd-cp-toy-bits-swarm` (idem) | `c6cdfe22fe5a280c1e42ae1f11ae25156d86b36da1e9d0e83f1d6c3227117b7c` |

### Model-TG

`tweaks/model-cycles_OS1.13/30-model-tg.json` vient du build de [Model-TG](https://github.com/TinyGregAudio/Model-TG) lui-même (licence MIT),
au commit épinglé dans `tools/gen_model_tg.py`, avec les binutils m68k, depuis une copie de sa source avec deux retouches (`MC_PATCHES` : en
mode mute, chaque touche de piste mute tout de suite, [note 31 §10](notes/31-model-tg.md) ; sa copie de l'écoute d'un pas accepte le
séquenceur en pause, [note 34](notes/34-ecoute-en-pause.md) ; avec l'audio USB multipiste, une piste mutée n'est plus coupée net sur sa
piste USB, [note 35 §3](notes/35-glitches-usb-multipiste.md)), plus l'envoi à l'USB à heure fixe (`tools/usb_steady.py`) :
```sh
git clone https://github.com/TinyGregAudio/Model-TG vendor/Model-TG
git -C vendor/Model-TG checkout 70b39dd6787770ebefc7a2d78dea1678ec012679   # v1.1.0
python3 tools/gen_model_tg.py --cycles model-cycles_OS1.13.syx --model-tg vendor/Model-TG [--check]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `model-tg` | `aa0740d714d502d440ec003cca8ca389c1ac9190de28395aef748ec9bf5c4c3a` (sans nos ajouts : `a049d724…`, celle annoncée par Model-TG pour sa v1.1.0) |
| `6ch-usbup,model-tg` | `96b6aec20df7c66f4a8d84c3ab4358a92b01d754c319923927d272aed0d34322` |

Le même script écrit `30-model-tg-st.json`, la base de la **version combinée avec les moteurs du Syntakt** : Model-TG construit par son
build depuis une copie de sa source, avec les mêmes ajouts et une retouche de plus (sa zone d'échantillons s'arrête 1 Mo plus bas). Les moteurs s'appliquent
par-dessus (`31-syntakt-tg-<moteurs>.json`, `requires`), voir [note 31 §4](notes/31-model-tg.md) :
```sh
python3 tools/gen_syntakt_engines.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx --all --tg [--check]
python3 tools/build.py -i model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx -t model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm
python3 tools/emu/test_model_tg_syntakt.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `model-tg-st,syntakt-tg-sd` | `f09ab68d48b7cfb58604ce6dc31f0998def25390e0a02aa83ecd304754ef8321` |
| `model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm` | `d5e73e10a07042a85e9022e87e488b6ca4960ecef69f49652d5c3dc706a1f6fc` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm` | `70354db7660a9ffc60956d523d2976299be4fa4813e483c1222abe26edae2b3c` |

Le flasher web vérifie chaque mod, à chaque build, contre l'outil Python ([note 49](notes/49-verification-mod-par-mod.md)) :
`REF_MODS` de `docs/flasher/app.js` donne l'empreinte des écritures et de la charge utile de chaque tweak, et `REF_MAINOS`
le MAIN OS d'un échantillon de combinaisons (chaque carte seule, chaque paire, les plus grandes : 464 aujourd'hui).
`tools/ref_mainos.py` réécrit les deux blocs (`--check` pour vérifier) ; `tools/check_overlaps.py` prouve, sans firmware,
que deux mods qu'on peut cocher ensemble n'écrivent jamais aux mêmes octets (sauf écriture identique ou mod posé
par-dessus l'autre par `requires`) ; `tools/registry.py` écrit `tweaks/model-cycles_OS1.13/REGISTRY.md`, le registre
de la place libre (masques de sprites pris et libres, caves, charges utiles) et des crochets posés sur l'OS
([note 52](notes/52-registre-place-libre.md)), à régénérer et commettre avec tout nouveau tweak ;
`tools/webflash_smoke.sh model-cycles_OS1.13.syx Syntakt_OS1.42.syx` reconstruit l'échantillon dans la page et le compare.
SD VINTAGE v1 (clean-room d'origine, **testée sur le matériel** le 29/09/2026, compilée par GCC 13.3) donnait `80b7b2bd…` seule et `38754937…` avec `6ch-usbup` ;
la v2 est compilée par `m68k-elf-gcc` 16.2 (Homebrew), voir [note 16 §6](notes/16-moteur-syntakt.md).

### Écoute des samples (Model-TG)

`tweaks/model-cycles_OS1.13/33-sample-preview.json` (sur `model-tg`) et `33-sample-preview-st.json` (sur `model-tg-st`,
mêmes écritures) sont produits par `tools/gen_sample_preview.py`, qui assemble `tools/machines/sample_preview/` et le lie
dans quatre masques de sprites 47×47 libérés, partagés avec `chord-keys`, qui exclut Model-TG (`conflicts`)
([note 46](notes/46-ecoute-des-samples.md)). Le code appelle celui de
Model-TG aux adresses des `symbols` de `30-model-tg*.json` ; le générateur vérifie ce code avant d'écrire. Le tweak
exige Model-TG (`requires`) : les builds de Model-TG sans lui ne changent pas. La preuve fait tourner le vrai code de
l'OS et de Model-TG, du navigateur à la boucle des voix (avec `--syntakt` seul, les deux versions) :
```sh
python3 tools/gen_sample_preview.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/build.py -i model-cycles_OS1.13.syx -t model-tg,sample-preview
python3 tools/build.py -i model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx \
    -t model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,sample-preview-st
python3 tools/emu/test_sample_preview.py --cycles model-cycles_OS1.13.syx \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,arp,trig-hold,tempo-max,boot-anim] \
    [--syntakt Syntakt_OS1.42.syx]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `model-tg,sample-preview` | `b73428049e2779ff8c73d91787c6bbaffe0a97b4f77e6b2e3819f09e035d9353` |
| `6ch-usbup,model-tg,sample-preview` | `4671f7b80784249d8e8c533d4546297fda2ff52b97c993fab7de83cbb5c60867` |
| `model-tg,arp,trig-hold,tempo-max,boot-anim,sample-preview` | `1d90726905d583347dc8cdaf359ad4fb25c1b907e659fa665cecdada35c1c585` |
| `model-tg-st,syntakt-tg-sd,sample-preview-st` (avec `--syntakt`) | `2557d21b5d2f20cdd909e727ae458fa71ce59ed864ab701c43d1f86730c31d17` |
| `model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,sample-preview-st` (idem) | `cde4365ff392e68b373afe9fa2004dc5e275c7c15f8a3c732549478ca2d36ca4` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,sample-preview-st` (idem) | `7b142604f35d11c63e3c22a0f1a4426c6630e2d184c5f680ed5f47125e2e891e` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max,boot-anim,sample-preview-st` (idem) | `20a116b1dbbc05e84dfc32df2f269f5c23df2d54fcb39d9b4a7c577c5916a432` |
| `model-tg-st,macro-tg,sample-preview-st` (avec la machine MACRO) | `9da219fbb5bccd19e496e880c00af5192d08d2d2a11995f209db09f9697dc9f4` |

### Arpégiateur

`tweaks/model-cycles_OS1.13/40-arp.json` est produit par `tools/gen_arp.py`, qui compile `tools/machines/arp/` (`m68k-elf-gcc`)
et le lie dans quatre masques de sprites libérés ([note 32](notes/32-arpegiateur.md)). La preuve fait tourner le code du tweak
et celui de l'OS, jusqu'à la vraie boucle d'événements de l'interruption audio, et le live rec par les vraies fonctions
d'envoi de note de l'OS :
```sh
python3 tools/gen_arp.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_arp.py --cycles model-cycles_OS1.13.syx \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm --syntakt Syntakt_OS1.42.syx]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `arp` | `e445bf895123d3fc94762a65739558b579ec8df3000c9bdf5747a3d73287e6a6` |
| `model-tg,arp` | `062f16db10bae6d9d3c6fda89aff382bf2896b531a6b511c236bb07c632247be` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,arp` | `f933b2b99cf4d525e9529c0c6c445f2f45b94b5f479d3157a0821f566a3ac592` |

L'arpégiateur et les moteurs du Syntakt libèrent le même masque (`0x4016cae8`) : les deux constructeurs (`tools/build.py`,
`docs/flasher/builder.js`) acceptent une écriture déjà faite à l'identique par un autre tweak.

### Effacer un trig

`tweaks/model-cycles_OS1.13/41-trig-hold.json` est produit par `tools/gen_trig_hold.py`, qui assemble
`tools/machines/trig_hold/trig_hold.S` (166 o avec l'heure d'appui des 16 touches de pas) au début du masque de sprite libéré
`0x4015c044`, devant les stubs de `6ch-usbup` ([note 33](notes/33-effacer-un-trig.md)). La preuve fait tourner la vraie chaîne de
l'OS, de la lecture des touches (anti-rebond, horloge de maintien à 120 Hz) au mode grille, à la milliseconde :
```sh
python3 tools/gen_trig_hold.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_trig_hold.py --cycles model-cycles_OS1.13.syx \
    [--with 6ch-usbup,model-tg-st,arp,syntakt-tg-sd-cp-toy-bits-swarm --syntakt Syntakt_OS1.42.syx]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `trig-hold` | `bbb8a4217a888c46a60cfb17ae444bec9cf21d6ff2d2d36bf8d1f1cdb81d1ef4` |
| `6ch-usbup,trig-hold` | `5be28240875818efd2b912680bb589300cd51a2c0aa4a86ae289b3241fbf7f44` |
| `model-tg,trig-hold` | `f71e6ea6d7bc530e3ad255b161babbfa388a93595d74c671a4ed9793bde5c87c` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp` | `ea715e19eec998366c2c8e4ef40c354060dd3550fc42a89b46e77b71256f4ba2` |

Avec `6ch-usbup`, les deux tweaks réécrivent de la même façon le pointeur du sprite dont le masque est libéré.

### Tempo jusqu'à 546 BPM

`tweaks/model-cycles_OS1.13/42-tempo-max.json` est produit par `tools/gen_tempo_max.py` : les six bornes à 300 BPM (moteur,
horloge MIDI reçue, projet, pattern, menu Tempo) passent à 546,0 BPM, plafond du champ 16 bits du projet, ainsi que les deux
contrôles au chargement ; la remise dans le cycle de la phase du LFO devient une boucle (au-delà de 351,6 BPM, le pas peut
dépasser un cycle). 12 écritures, aucune place libre ([note 38](notes/38-tempo-546-bpm.md)). La preuve fait tourner le vrai
code de l'OS, d'origine et modifié, jusqu'aux 6 LFO (EMAC exacte) :
```sh
python3 tools/gen_tempo_max.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_tempo_max.py --cycles model-cycles_OS1.13.syx
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `tempo-max` | `5d6417b175e89b68c76743bbcad45306ba210969ad049fc1bfa6da46e432eaef` |
| `6ch-usbup,tempo-max` | `0f7a47738be9a70aa3c8e586d28636c535d787693ddf6cc756c92b5824717d42` |
| `model-tg,tempo-max` | `97cc13b34d3f4b3440d42bdb1c692e64bf0aa8b2de54b806b14320914936ef4f` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max` | `c8214dc5fe88a5ff346d8554f05753bb25acec448cb0eb23140236b10a9404d4` |


### Control All : choix des pistes

`tweaks/model-cycles_OS1.13/49-control-all-config.json` est produit par `tools/gen_control_all_config.py`, qui assemble
`tools/machines/control_all_config/control_all_config.s` (le mod **Control All Config** 1.0 de durchgemacht, MIT, recopié
tel quel) et le pose dans quatre masques de sprites 48×22 libérés ([note 58](notes/58-control-all-config.md)). TRACK + TRIG 1-6
écarte une piste de Control All ou l'y remet ; TRACK tenu, les TRIG 1-6 montrent les pistes qui suivent ; la piste active
suit toujours ; choix en RAM. La preuve fait tourner le vrai code des cinq boucles de Control All, du gestionnaire de
touches et du producteur de LED de `TrackSelectionView`, d'origine et modifié :
```sh
python3 tools/gen_control_all_config.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_control_all_config.py --cycles model-cycles_OS1.13.syx \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,arp,trig-hold,tempo-max,boot-anim --syntakt Syntakt_OS1.42.syx]
python3 tools/build.py -i model-cycles_OS1.13.syx -t control-all-config
```

### Machine SOLID

`tweaks/model-cycles_OS1.13/71-solid.json` est produit par `tools/gen_solid.py`, qui écrit les tables des matériaux
(`tools/machines/solid/solid_tables.h`), compile `tools/machines/solid/` (`solid.c`, `ring_cf.S`) en son objet et le
compose seul avec `tools/compose.py` : une machine ajoutée, huit modes en virgule fixe sur l'EMAC, frappés par une
mailloche, une bouffée de bruit ou un bruit tenu ([note 71](notes/71-solid.md), MODAL jusqu'au 11/11/2026). COLOR est
Bright, SHAPE le corps (corde, peau, marimba, barre, cloche, verre, en glissant), SWEEP le point d'écoute, CONTOUR
l'excitateur ; DECAY le T60 du corps (20 ms à 8 s), GATE l'étouffe à la fin de la note. La preuve tourne sur le code de
l'OS (Unicorn), au bit près contre le build hôte du même fichier (`tools/emu/solid_ref.c`) :
```sh
python3 tools/gen_solid.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_solid.py --cycles model-cycles_OS1.13.syx [--dry] [--quick] [--modes 8,16]
python3 tools/emu/test_compose.py --cycles model-cycles_OS1.13.syx --machines solid --machines sampler,solid
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines solid                # seule
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines sampler,solid        # avec SAMPLE
```
MAIN OS patché, `solid` 0.1 seule, avec ses propres images (release 0.64, note 71 §13) : `3febf7a572aef0d0ebffbf70db50e4db2d6a52af782df875d0bc2c17be414b0e` (sans : `ded57d3e…`) ; avec SAMPLE 0.17 et ses images :
`8581385a0dc5782912b4e3eca6ebea88967f38be33f91eccf50f42a526daf94b` (sans images : `f7b26b90…` ; SAMPLE 0.15 : `b1fc2896…`) ; avec toutes les cartes de la page (dix-sept,
release 0.64 : `--machines sampler,solid,chordtables,digidelay,pots,smpfilter,crush,ring,reso,eq --cpu --resample
--transpose --perform --with control-all-config,trig-preview,trig-cond-order`) :
`c5d6879a3b55b9ebd787770ddccd43733ef04d330e851130429a6f82ac747b00` ; sans Perform Kit (seize, la même commande sans
`--perform`) : `b7b50e9ad1d6cff67ff96d47c7ba1a197e931d189480822a07b4f8eb90d3bc62`, le fichier essayé dans digiemu et sur un
Model:Cycles depuis la ligne de commande le 14/11/2026, avec les images de SOLID et de SAMPLE (note 71 §13.5) ; release
0.63 (Perform Kit, sans les images, note 81) : `d91ef5bf…` ; release 0.59 : `0901bf28…`, essayé dans digiemu et sur un Model:Cycles depuis la ligne de commande le 11/11/2026 (note 71 §11),
puis flashé depuis la page le même jour (note 71 §12).

### CHORD Tables (wavetables du +Drive)

`tweaks/model-cycles_OS1.13/36-chordtables.json` est produit par `tools/gen_chordtables.py`, qui compile
`tools/machines/chordtables/` (`chordtables.c`, `entries.S`) en son objet et le compose seul avec `tools/compose.py`,
sans rien enregistrer : une extension de la machine CHORD d'origine ([note 66](notes/66-chord-wavetables-from-drive.md)).
Depuis la 0.3 (note 66 §27 à §31), le pattern choisit une table pour toutes les pistes CHORD, PATTERN + SWEEP (octets 36
et 37 de l'en-tête du pattern, deux pas par table) : 0 la table d'origine, 1 à 63 les fichiers de `/Wavetables`
dont le nom commence par ce numéro (depuis la 0.4), lus sur le tick de l'écran ; la table entière prend la place de
la table d'origine en SRAM. Ses cinq crochets en chaîne (le lookup des potards, `0x4001f886`, le relâchement de PATTERN, le chargeur et l'initialisation de l'en-tête)
passent devant les parties du constructeur aux mêmes endroits (note 66 §30.2). La preuve tourne sur le code de l'OS
(Unicorn) :
```sh
python3 tools/gen_chordtables.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_chordtables.py --cycles model-cycles_OS1.13.syx [--dry] [--machines chordtables]
python3 tools/emu/probe_chord_lines.py --cycles model-cycles_OS1.13.syx
python3 tools/emu/probe_chord_switch.py --cycles model-cycles_OS1.13.syx [--wav <dossier>]
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines chordtables                # seul
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines sampler,chordtables        # avec SAMPLE
```
MAIN OS patché, `chordtables` 0.4 seul : `6b1b29521cce0222fe093b5fd3226131fdb3cc0da589e94c81bb3cc840fce04b` ; avec
SAMPLE 0.17 et ses images : `3ac976494d89790d3925f8dedc32efe1835d3c35d1d4f56cbc37a3cea16bf565` (sans images : `e4d22760…` ; SAMPLE 0.15 : `8aa5757d…`) ; avec toutes les cartes de la page (quinze,
release 0.54 : `--machines sampler,chordtables,digidelay,pots,smpfilter,crush,ring,reso,eq --cpu --resample --transpose
--with control-all-config,trig-preview,trig-cond-order`) : `8e0a92418f6ecbd14df773a41b60f0702e2a9abe85f668740bf997a1b3a84409`,
le fichier essayé sur un Model:Cycles depuis la ligne de commande le 09/11/2026 (note 66 §36.10) ; puis flashé depuis
la page le même jour (note 66 §36.12).
Depuis la 0.4 (note 66 §36), le chargeur lit le dossier `/Wavetables` avec les appels de l'OS (`0x4007aa78`,
`0x4007ab26`) : un nom qui commence par deux chiffres `01` à `63` suivis d'autre chose qu'un chiffre est cette table
(`07 Glass Pad`). La 0.3 (les noms fixes `01` à `63`) : seule `49596b80…`, avec SAMPLE `e34b7597…`, avec les quinze
cartes `0e1c33bc…`, le fichier essayé sur un Model:Cycles depuis la ligne de commande le 08/11/2026 (note 66 §33 : les
huit essais). Pas encore flashé depuis la page.

### Digital Delay (effet)

`tweaks/model-cycles_OS1.13/39-digidelay.json` est produit par `tools/gen_digidelay.py`, qui compile
`tools/machines/digidelay/digidelay.c` (le delay numérique des mods PPPCCC de gialloinfuso, 2.0.0, MIT, porté en C pas à
pas) et le compose seul avec `tools/compose.py` : un effet de l'emplacement du delay, avec la partie `fxslot`
([note 68](notes/68-fx-slots.md) §14 à §19). PATTERN + Delay Time choisit l'effet du pattern (TRACK + Delay Time jusqu'à fxslot 0.4) (octets 29 à 31 de son
en-tête) ; la ligne de 1 Mio est celle de l'emplacement, dans les variables de la charge utile. La preuve fait tourner le
vrai code du mixer, du gestionnaire des potards, du chargement et de l'initialisation des en-têtes de pattern, d'origine
et modifié, et compte la charge ; avec `--pppccc`, le son contre le code même de PPPCCC :
```sh
python3 tools/gen_digidelay.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_fxslot.py --cycles model-cycles_OS1.13.syx \
    [--pppccc PPPCCC-Model-Cycles-1.13-Mods/patches/06-delay-fx.json]
python3 tools/build.py -i model-cycles_OS1.13.syx -t digidelay
```
MAIN OS patché, `digidelay` seul : `280f662b39263d5c77f841a2e699dcff71bf6833712df5d411e7f2afec82425b`, celui que la page
compose, avec la partie `fxslot` 0.6 (PATTERN + Delay Time, la carte des touches du 31/10/2026, et l'attente de la
sélection de patterns terminée au relâchement de PATTERN, note 68 §23 ; avec 0.5, jouée sur un Model:Cycles le
31/10/2026 : `0eb57c92…`). Avec `fxslot` 0.4, qui lance la préparation des effets d'origine avant la boucle des voix
(note 68 §21, l'idée de Model-TG), jouée sur un Model:Cycles depuis la page le 29/10/2026 (§21.8) : `0ce37cf6…` ; le
build joué le 27/10/2026 était `4fb4eac7…`.

### POTS (effet)

`tweaks/model-cycles_OS1.13/70-pots.json` est produit par `tools/gen_pots.py`, qui écrit les tables de
`tools/machines/pots/pots_tables.h` (la paire de Hilbert vient de `tools/machines/pots/hilbert.json`, calculée par
`tools/gen_hilbert.py`, qui demande numpy), compile `tools/machines/pots/pots.c` (le code propre à model27, en virgule
fixe sur l'EMAC) et le compose seul avec `tools/compose.py` : le deuxième effet de l'emplacement du delay (id 2), avec la
partie `fxslot` ([note 69](notes/69-pots-delay.md)). Sa ligne de 256 Kio est celle de l'emplacement, partagée avec
Digital Delay. `tools/emu/pots_host.py` compile le même code pour l'hôte et vérifie le son contre ses mesures ; la preuve
de `test_fxslot.py` fait tourner le code de l'appareil dans l'OS contre ce build hôte, au bit près, et compte la charge :
```sh
python3 tools/gen_hilbert.py --check
python3 tools/gen_pots.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/pots_host.py
python3 tools/emu/test_fxslot.py --cycles model-cycles_OS1.13.syx --machines pots --machines sampler,pots,refreverb
python3 tools/build.py -i model-cycles_OS1.13.syx -t pots
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines sampler,digidelay,pots   # avec Digital et SAMPLE
```
MAIN OS patché, `pots` seul : `93ad7348e2ffa42879d2bcfabf66780f0cce721a03022f543ad785c92ba779e8` ; `digidelay` et `pots`
composés : `81bc4d1e4cfee2bc8daba59ecf99e89a6c33f924ef11b3819632558ccfc4b64a` ; avec SAMPLE 0.17 (`sampler`,
`digidelay`, `pots`, SAMPLE avec ses images) : `1d94c968c60ddd0aab2fee4459dc8c91add1824160dd815fc5a4e6ddda031a77` (sans images : `a5ecc06d…` ; la couche de raccourcis 0.6 ; SAMPLE 0.15 : `4f8a41c5…` ; avec la couche 0.5 : `a545a230…` ; SAMPLE 0.14 : `14345987…` ; SAMPLE 0.13 : `bf9a0636…`),
ceux que la page compose avec
`fxslot` 0.7 (le compteur de la page CPU, note 78 §8) et la couche de raccourcis 0.5 (note 63 §25–§31). Depuis POTS 0.2 la ligne tourne à
6 kHz (`pots_cf.S` pour la décimation, note 69 §24), environ un tiers de la charge de la version à 12 kHz ; celle-ci
(note 69 §23) avait été testée sur un Model:Cycles (§23.6, `28cf64c0…`), puis jouée avec `fxslot` 0.4 depuis la page le
29/10/2026 (note 68 §21.8). POTS 0.2 essayé depuis la ligne de commande le 03/11/2026 (note 69 §24.7), puis flashé
depuis la page et testé sur un Model:Cycles le 04/11/2026 (note 69 §25).

### Filtre Samples (filtre de piste)

`tweaks/model-cycles_OS1.13/72-smpfilter.json` est produit par `tools/gen_smpfilter.py`, qui compile le filtre de
SAMPLE (les sources de Cycles One-Shot de `tools/machines/sampler/src/`, inchangées) avec sa colle
`tools/machines/smpfilter/smpfilter.c` et le compose seul avec `tools/compose.py` : le premier filtre (id 1) de la
partie `fltslot` (`tools/gen_parts.py`), qui fait passer chaque piste, après Volume + Dist, par le filtre que son son a
choisi ([note 72](notes/72-track-filters.md)). RETRIG + PITCH choisit le filtre, RETRIG + SWEEP / CONTOUR règlent
Cutoff et Reso (k 28 et 29, descripteurs 1 et 2 de toutes les machines : p-locks, LFO, Control All, CC 74 / 71). REFF
(`tools/machines/refflt/`, id 255), jamais proposé, sert à la preuve. Celle-ci fait tourner le vrai bloc audio, les
tables construites au démarrage, la recherche des potards, le chemin du LFO, les p-locks du pattern et l'enregistrement
des sons, d'origine et modifiés, Samples au bit près contre le build hôte des sources de SAMPLE, et compte la charge :
```sh
python3 tools/gen_parts.py --check
python3 tools/gen_refmachine.py --cycles model-cycles_OS1.13.syx --check
python3 tools/gen_smpfilter.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_fltslot.py --cycles model-cycles_OS1.13.syx
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines smpfilter
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines sampler,smpfilter   # avec SAMPLE
```
MAIN OS patché, `smpfilter` seul : `c422bf3817202993a9e133e3ea77cd82027f7083fe623818823ebb33f6c3af03` (la couche de raccourcis 0.6 ; avec la couche 0.5 : `e9838dee…`) ; avec SAMPLE
(`sampler` 0.17 avec ses images, `smpfilter`) : `90ca4667b5bf2e55597e1f65f6fb39fbae4180c17a5b6adba59f84484aef5d19` (sans images : `242fe9b1…` ; SAMPLE 0.15 : `5dee5685…` ; `fltslot` 0.11 et la couche de raccourcis 0.6 ; avec la couche 0.5 : `1caed5f9…`, qui
garde les rangées de p-locks de k 23 et plus, note 63 §25 ; avec `fltslot` 0.10 et SAMPLE 0.14 : `a545bb6b…`, `b7507068…` ;
Samples 0.4, le même son que 0.3 au bit près en
moins d'instructions, note 72 §25 ; SAMPLE 0.13 : `f1ae1200…` ; avec Samples 0.3 : `62db5452…`, `d343e6c9…` ; SAMPLE 0.12 :
`7350c436…`, note 60 §21), ceux que la page compose
(`fltslot` 0.10 : un potard sans valeur montre le popup du type et ne change rien, note 73 §19 ; avec 0.9, huit par
build, pas de recherche pour « aucun », note 73 §16 : `adb6d1bf…`, `62f07d89…` ; avec 0.8 : `854342c2…`, `9499b519…`). Avec `fltslot` 0.6 et Samples 0.3
(Cutoff de -64 à 63 comme SAMPLE, CUTO comme destination du LFO, note 72 §22), flashés depuis la page et joués sur un
Model:Cycles le 01/11/2026 (note 72 §23) : seul `92f6955e…`, avec SAMPLE `83801ea7…`, avec toutes les cartes
`e6a60aa3…`. Avec `fltslot` 0.5 et Samples 0.2 (L64 … OFF … H63, FREQ), joués sur un Model:Cycles depuis la ligne de
commande le 01/11/2026 (note 72 §20) : seul `76b47553…`, avec toutes les cartes `449b7df8…`.

### Crush (Track FX)

`tweaks/model-cycles_OS1.13/73-crush.json` est produit par `tools/gen_crush.py`, qui écrit la table de l'horloge
(`tools/machines/crush/crush_tab.h`), compile `tools/machines/crush/crush.c` et le compose seul avec `tools/compose.py` :
le premier effet (id 2) des Track FX, la partie `fltslot` 0.7, qui prend des effets comme des filtres et quatre par
build ([note 73](notes/73-track-fx-crush.md)). RETRIG + SWEEP est Rate (au centre rien, à droite un maintien dur, à
gauche un maintien doux), RETRIG + CONTOUR est Bits (127 rien, puis de 8 bits à 1 bit en tournant à gauche ; un son
qui passe à Crush part de 127, la
valeur de départ de `fltslot` 0.8), les mêmes descripteurs 1 et 2 que Samples. La
preuve est celle du filtre Samples, avec Crush au bit près contre le build hôte du même fichier et une sélection de
quatre filtres dans un build :
```sh
python3 tools/gen_crush.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_fltslot.py --cycles model-cycles_OS1.13.syx
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines crush
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines smpfilter,crush   # avec Samples
```
MAIN OS patché, `crush` seul : `e3e6b94acfd533b949192691ea6c1e1b5eeab31d2c374f08367c7740c1b246da` (la couche de raccourcis 0.6 ; avec la couche 0.5 : `29c30e96…`) ; avec Samples
(`smpfilter`, `crush`) : `e05c2951153a0aca2153734785690cf4cc528de2086480d44e6688fe8958dbbf` (`fltslot` 0.11, la couche 0.6 ; avec la couche 0.5 : `973ed79a…` ; avec `fltslot` 0.10 : `36494141…`,
`9c33360e…`) ; avec toutes les cartes de
la page (dix-sept, release 0.64, la commande de SOLID ci-dessus) : `c5d6879a3b55b9ebd787770ddccd43733ef04d330e851130429a6f82ac747b00` (les images de SOLID et de SAMPLE, note 71 §13, avec Perform Kit ; seize, sans Perform Kit : `b7b50e9a…` ; release 0.63 : `d91ef5bf…`, Perform Kit, note 81 ; release 0.62 : `6b88b851…`, SAMPLE 0.17, note 60 §24 ; release 0.60 : `dd9183af…`, `fltslot` 0.12, CC 75 / 76, note 73 §21 ; seize, release 0.59 : `0901bf28…` ; quatorze, release 0.51 : `398b05d1…`, SAMPLE 0.15, `fltslot` 0.11, la couche de raccourcis 0.6 et Transpose 0.3 ; avec Transpose 0.2 : `cd89791b…` ; treize cartes, release 0.50, la couche 0.5 : `a503f081…` ; note 63 §25–§31 ; release 0.44 : `4f6a8756…`, SAMPLE 0.14 ; release 0.41 : `275ea11f…` ; EQ 0.6, note 76 §17 ; avec EQ 0.5, release 0.40 : `9e7c87d2…` ; Reso 0.4, note 75 §17 ; avec Reso 0.3, release 0.39 : `021d39d1…`), ceux que la page compose (Ring 0.3, note 74 §13 ; avec Ring 0.2 :
`289e6c14…` (onze cartes, release 0.35 : `2fbe6c3f…`) ; Samples 0.4, note 72 §25 ;
avec Samples 0.3, release 0.34 : `44e16270…`, `0d64b14e…` ; Crush 0.5, le même son
que 0.4 au bit près en moins d'instructions, note 73 §20 ; avec Crush 0.4, Bits de 8 bits à 1 bit, `fltslot` 0.10 : `3e95ccad…`,
`32df8895…`, `09661941…` (release 0.32) ; avec `fltslot` 0.9 : `8f78c203…`, `2b6d98a7…`, `a1736027…` ; avec les huit cartes de la release 0.27 : `74ac0913…` ; avec `fltslot` 0.8, joués et testés depuis la page : `a151818c…`, `cbf53b93…`, `388d2043…` ; avec Crush 0.3, Bits de 16 à 1 : `da5584a0…`, `167d2883…`, `2b2fae73…` ; avec Crush
0.2, le même son que 0.3 : `365f496b…`, `01cf9060…`, `c089f700…`). Crush 0.4 joué sur un Model:Cycles depuis la ligne
de commande le 01/11/2026 (note 73 §14). Avec Crush 0.1 (Bits à l'envers) et `fltslot` 0.7, joués sur un Model:Cycles depuis la ligne de
commande le 01/11/2026 (note 73 §10) : seul `25aac3ea…`, avec Samples `c8cdc37c…`, avec toutes les cartes `67f0d95e…`.

### Ring (Track FX)

`tweaks/model-cycles_OS1.13/74-ring.json` est produit par `tools/gen_ring.py`, qui écrit les tables de la porteuse
(`tools/machines/ring/ring_tab.h` : le pas de phase par note, le cosinus de 2 048 pas depuis Ring 0.3), compile
`tools/machines/ring/ring.c` et `ring_cf.S` (la boucle des trames, depuis 0.3) et le compose seul avec
`tools/compose.py` : le deuxième effet (id 3) des Track FX ([note 74](notes/74-ring.md)). RETRIG + SWEEP est Freq (la
note de la porteuse, de 8,2 Hz à 12,5 kHz), RETRIG + CONTOUR est Mix (0 sec, 127 l'anneau seul), RETRIG + COLOR est
Wave (Shape jusqu'à 0.3, note 74 §14 ; du sinus au carré ; un son qui passe à Ring part du sinus, sa valeur de départ),
les descripteurs 1 à 3. La preuve est celle des Track FX, avec Ring au bit près contre le build hôte du même fichier et
une sélection de huit dans un build :
```sh
python3 tools/gen_ring.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_fltslot.py --cycles model-cycles_OS1.13.syx
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines ring
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines smpfilter,crush,ring   # avec Samples et Crush
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines ring --cpu             # avec la page CPU
```
MAIN OS patché (Ring 0.3), `ring` seul : `5f7e2f0394147695ca6b0be74e82b8aaeecf95766316879fc722d3a93d96b897` (`fltslot` 0.12, CC 75 sur COLOR, note 73 §21 ; avec 0.11 : `20ae22ce…` ; la couche de raccourcis 0.6 ; avec la couche 0.5 : `c8e189ce…`) ; avec Samples
et Crush : `9fcac455acb0d5209e43f3cd275e255404c63c24edea6a855edfae3db0e1ab6e` (`fltslot` 0.12 ; avec 0.11 : `031021a9…` ; la couche de raccourcis 0.6 ; avec la couche 0.5 : `dd49ce7a…`) ; avec la page CPU :
`5cbc86eec33cd1f662856af5471df701cddd48c69e888a10cdcc1fe3362a4f90` (`fltslot` 0.12 ; avec 0.11 : `532766f2…` ; la couche 0.6 ; avec la couche 0.5 : `9fc74881…` ; avec `fltslot` 0.10 : `a6340129…`, `4a1554a4…`, `df80d34a…` ; Ring 0.2 : `333bae39…`) ; avec toutes les cartes de la page (dix-sept,
release 0.64, la commande de SOLID ci-dessus) : `c5d6879a3b55b9ebd787770ddccd43733ef04d330e851130429a6f82ac747b00` (les images de SOLID et de SAMPLE, note 71 §13, avec Perform Kit ; seize, sans Perform Kit : `b7b50e9a…` ; release 0.63 : `d91ef5bf…`, Perform Kit, note 81 ; release 0.62 : `6b88b851…`, SAMPLE 0.17, note 60 §24 ; release 0.60 : `dd9183af…`, `fltslot` 0.12, CC 75 / 76, note 73 §21 ; seize, release 0.59 : `0901bf28…` ; quatorze, release 0.51 : `398b05d1…`, SAMPLE 0.15, `fltslot` 0.11, la couche de raccourcis 0.6 et Transpose 0.3 ; avec Transpose 0.2 : `cd89791b…` ; treize cartes, release 0.50, la couche 0.5 : `a503f081…` ; note 63 §25–§31 ; release 0.44 : `4f6a8756…`, SAMPLE 0.14 ; release 0.41 : `275ea11f…` ; EQ 0.6, note 76 §17 ; avec EQ 0.5, release 0.40 : `9e7c87d2…` ; Reso 0.4, note 75 §17 ; avec Reso 0.3, release 0.39 : `021d39d1…`) (Ring 0.3, la porteuse de 2 048 pas sans interpolation et la boucle dans `ring_cf.S`, un tiers
d'instructions en moins, note 74 §13, et le nom Wave, §14 ; avec Ring 0.2 : `704f5f65…`, `68b3f5f1…`,
`289e6c14…` (onze cartes, release 0.35 : `2fbe6c3f…`) ; Ring 0.2, le produit sur l'EMAC, `fltslot` 0.10 ; Crush 0.5 ; Samples 0.4 ;
avec Samples 0.3, release 0.34 : `7f9371fa…`, `0d64b14e…` ; avec Crush 0.4, release 0.32 : `85467706…`, `09661941…` ;
avec `fltslot` 0.9 : `3cdd61c0…`, `b5a8c7e9…`, `a1736027…` ; avec les cartes de la release 0.27 : `6960abd2…`). Ring 0.2 joué sur un Model:Cycles depuis la ligne de commande le
01/11/2026 (note 74 §10). Avec Ring 0.1, le même son, joués sur un Model:Cycles depuis la ligne de commande le
01/11/2026 : `a32b09d0…`, `ce50adf3…`, `9647a93b…`.

### Reso (Track FX)

`tweaks/model-cycles_OS1.13/75-reso.json` est produit par `tools/gen_reso.py`, qui écrit les tables
(`tools/machines/reso/reso_tab.h`), compile `tools/machines/reso/reso.c` et `reso_cf.S` et le compose seul avec
`tools/compose.py` : le Track FX 4 du slot de filtre, un résonateur en peigne ([note 75](notes/75-reso.md)). RETRIG +
SWEEP est Pitch (la note MIDI, 60 = C4 ; un son qui passe à Reso part de C4), RETRIG + CONTOUR Amount (0 : la piste
intacte, au bit près), RETRIG + COLOR Tone (de sourd à métallique), RETRIG + SHAPE Decay (20 ms à 10 s). La preuve est
celle des Track FX, avec Reso au bit près contre le build hôte de `reso.c` (la boucle en C, modèle de `reso_cf.S`) :
```sh
python3 tools/gen_reso.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_fltslot.py --cycles model-cycles_OS1.13.syx
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines reso
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines smpfilter,crush,reso   # avec Samples et Crush
```
MAIN OS patché, `reso` seul : `6ff88f345a7f786aea2fda10e21d88e9d5c80abc9d8258ba56fa892155c3c97e` (`fltslot` 0.12, CC 75 / 76 sur COLOR / SHAPE, note 73 §21 ; avec 0.11 : `aaf1adbc…` ; la couche de raccourcis 0.6 ; avec la couche 0.5 : `540699be…`) ; avec Samples et
Crush : `9ce86da68368ec0437116e9841bdeadc82a2f2a7cd156d034a373fc23431b8c8` (`fltslot` 0.12 ; avec 0.11 : `dee2a5f8…` ; la couche 0.6 ; avec la couche 0.5 : `f2f326ad…` ; avec `fltslot` 0.10 : `7626270e…`, `ccdcf75a…`) ;
avec toutes les cartes de la page (dix-sept,
release 0.64, la commande de SOLID ci-dessus) : `c5d6879a3b55b9ebd787770ddccd43733ef04d330e851130429a6f82ac747b00` (les images de SOLID et de SAMPLE, note 71 §13, avec Perform Kit ; seize, sans Perform Kit : `b7b50e9a…` ; release 0.63 : `d91ef5bf…`, Perform Kit, note 81 ; release 0.62 : `6b88b851…`, SAMPLE 0.17, note 60 §24 ; release 0.60 : `dd9183af…`, `fltslot` 0.12, CC 75 / 76, note 73 §21 ; seize, release 0.59 : `0901bf28…` ; quatorze, release 0.51 : `398b05d1…`, SAMPLE 0.15, `fltslot` 0.11, la couche de raccourcis 0.6 et Transpose 0.3 ; avec Transpose 0.2 : `cd89791b…` ; treize cartes, release 0.50, la couche 0.5 : `a503f081…` ; note 63 §25–§31 ; release 0.44 : `4f6a8756…`, SAMPLE 0.14 ; release 0.41 : `275ea11f…` ; EQ 0.6, note 76 §17 ; avec EQ 0.5, release 0.40 : `9e7c87d2…` ; Reso 0.4, le bloc et les coefficients
dans `reso_cf.S`, un cinquième d'instructions de moins au pire, note 75 §17 ; avec Reso 0.3, release 0.39 : `0b0fdba1…`,
`d8f9807c…`, `021d39d1…` ; Reso 0.3, Tone sur COLOR et Decay sur SHAPE, `fltslot` 0.10 ; Crush 0.5 ;
Samples 0.4 ; Ring 0.3 ; avec Ring 0.2 : `289e6c14…` (onze cartes, release 0.35 : `2fbe6c3f…`) ; avec Samples 0.3, release 0.34 : `c1be9428…`, `0d64b14e…` ; avec Crush 0.4, release 0.32 : `45a81abb…`, `09661941…` ; avec
`fltslot` 0.9 : `c92e3d14…`, `8dc2d4c2…`, `a1736027…` ; avec les cartes de la release 0.27 : `f14b2b21…` ; avec Reso 0.2, Decay sur COLOR et Brightness sur SHAPE : `54ec2859…`, `4e31c87f…`,
`8dede451…` ; avec Reso 0.1, le même son : `0a4eba0e…`, `b274ee03…`, `5a8d16a6…`). Reso 0.1 avec Samples et Crush joué
sur un Model:Cycles depuis la ligne de commande le 01/11/2026 (note 75 §12), Reso 0.3 aussi (note 75 §14), Reso 0.4
le 04/11/2026 (note 75 §17).

### EQ (Track FX)

`tweaks/model-cycles_OS1.13/76-eq.json` est produit par `tools/gen_eq.py`, qui écrit les tables des coefficients
(`tools/machines/eq/eq_tab.h`, d'après les formules de l'Audio EQ Cookbook), compile `tools/machines/eq/eq.c` et
`eq_cf.S` et le compose seul avec `tools/compose.py` : le Track FX 5, un égaliseur trois bandes
([note 76](notes/76-eq.md)). RETRIG + SWEEP est la fréquence du Mid (cloche Q 1, 200 Hz à 4,9 kHz), RETRIG + CONTOUR
son gain (part du centre, sa valeur de départ), RETRIG + COLOR Low (shelf à 100 Hz), RETRIG + SHAPE High (shelf à
8 kHz) ; ±12 dB, plat au centre, intouché au bit près. La preuve est celle des Track FX, avec EQ au bit près
contre le build hôte du même fichier :
```sh
python3 tools/gen_eq.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/gen_eq.py --response
python3 tools/emu/test_fltslot.py --cycles model-cycles_OS1.13.syx
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines eq
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines smpfilter,crush,eq   # avec Samples et Crush
```
MAIN OS patché (EQ 0.6), `eq` seul : `b5f6d9d865886b023e9f3f253b65ac518120d1c5143dc6cd9fd1581fe0cf29c5` (`fltslot` 0.12, CC 75 / 76 sur COLOR / SHAPE, note 73 §21 ; avec 0.11 : `e205497b…` ; la couche de raccourcis 0.6 ; avec la couche 0.5 : `fb2a9f9b…`) ; avec Samples et
Crush : `bc55e38d28918b3fb2cb3a1472c9a37120075d4fa92fb76c54973562b8c84ea7` (`fltslot` 0.12 ; avec 0.11 : `aab432fb…` ; la couche 0.6 ; avec la couche 0.5 : `015937f5…` ; avec `fltslot` 0.10 : `49130cc3…`, `33824b1c…`) ;
avec toutes les cartes de la page (dix-sept,
release 0.64, la commande de SOLID ci-dessus) : `c5d6879a3b55b9ebd787770ddccd43733ef04d330e851130429a6f82ac747b00` (les images de SOLID et de SAMPLE, note 71 §13, avec Perform Kit ; seize, sans Perform Kit : `b7b50e9a…` ; release 0.63 : `d91ef5bf…`, Perform Kit, note 81 ; release 0.62 : `6b88b851…`, SAMPLE 0.17, note 60 §24 ; release 0.60 : `dd9183af…`, `fltslot` 0.12, CC 75 / 76, note 73 §21 ; seize, release 0.59 : `0901bf28…` ; quatorze, release 0.51 : `398b05d1…`, SAMPLE 0.15, `fltslot` 0.11, la couche de raccourcis 0.6 et Transpose 0.3 ; avec Transpose 0.2 : `cd89791b…` ; treize cartes, release 0.50, la couche 0.5 : `a503f081…` ; note 63 §25–§31 ; release 0.44 : `4f6a8756…`, SAMPLE 0.14 ; release 0.41 : `275ea11f…` ; EQ 0.6, le bloc et les coefficients
dans `eq_cf.S`, un septième d'instructions de moins au pire, note 76 §17 ; avec EQ 0.5, release 0.40 : `cf01be47…`,
`937099de…`, `9e7c87d2…` ; avec Reso 0.3, release 0.39 : `021d39d1…`) (`fltslot` 0.10 ; Crush 0.5 ; Samples 0.4 ; Ring 0.3 ; avec Ring 0.2 : `289e6c14…` (onze cartes, release 0.35 : `2fbe6c3f…`) ;
avec Samples 0.3, release 0.34 : `567c2b42…`, `0d64b14e…` ; avec Crush 0.4, release 0.32 : `d53b1fe6…`, `09661941…` ; avec `fltslot` 0.9 : `31e4456f…`, `be915b71…`,
`a1736027…` ; avec les cartes de la release 0.27 : `7351d116…`).
EQ 0.4 (les noms EQ Mid Freq … EQ High Gain, que l'écran coupait à « EQ Mid ») : `47d7d40b…`, `076475d6…`, `49241853…`.
EQ 0.3 (Low sur SWEEP, High sur CONTOUR, le Mid sur COLOR et SHAPE ; le même son) : `14aeae02…`, `1e2385b8…`,
`6d9eeda5…`.
EQ 0.2 (le même son, en plus d'instructions) : `4fe6c32d…`, `8fd0bc5f…`, `4c47d8c3…`.
EQ 0.1 (les noms EQ Low, EQ High, EQ Mid), joué sur un Model:Cycles depuis la ligne de commande le 01/11/2026 (note 76
§10) : seul `c2a00bed…`, avec Samples et Crush `31369bf8…`, avec toutes les cartes `9f57b1a0…`. EQ 0.5 joué sur un
Model:Cycles le 01/11/2026 (note 76 §14), EQ 0.6 le 04/11/2026 depuis la ligne de commande (note 76 §17).

### Page CPU

`tweaks/model-cycles_OS1.13/78-cpu.json` est produit par `tools/gen_cpu.py`, qui compose seule avec `tools/compose.py
--cpu` la partie `cpu` du constructeur (`tools/machines/cpu/`, objet construit par `tools/gen_parts.py`) : une sonde
autour de l'appel de la fonction audio (`0x40059382`) mesure la part de chaque bloc, une ligne CPU au bout de la liste
de la configuration de l'appareil (`0x40032aee`) ouvre une page à elle, construite comme la page System de Model-TG
([note 78](notes/78-cpu-page.md)). La page lit aussi ce que mesurent `fltslot` (Track FX) et `fxslot` 0.7 (effets).
La preuve tourne sur le code de l'OS (Unicorn) :
```sh
python3 tools/gen_cpu.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_cpu.py --cycles model-cycles_OS1.13.syx [--show]
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --cpu                       # la page seule
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines pots,crush --cpu  # avec POTS et Crush
```
MAIN OS patché, `cpu` seul : `425ad022c55c0037e7846c3c5b84fd87235dba4c1847cf1733795236a50b25b5` ; avec POTS et Crush
(dans l'ordre des cartes, comme la page) : `1e56ae5c2eb9fa12612d2096a97c80c025df0cd554e11341106790a20d770759` (`fltslot` 0.11, la couche 0.6 ; avec la couche 0.5 : `1e87a24f…` ; avec
`fltslot` 0.10 : `49a0e74a…`) ; avec
toutes les cartes de la page (douze, release 0.37) : `5af3a7473353c494edefc8ebec1a36642d22b287a06867145aa7c7fff9afa17d`. Avec POTS et Crush, essayé sur un Model:Cycles depuis la ligne de commande le 03/11/2026, les valeurs
rafraîchies deux fois par seconde (note 78 §10). La page sans son rafraîchissement (`cpu` 0.2), essayée de même le
même jour (note 78 §9) : avec Crush et POTS `7773846a…`. Flashée depuis la page et testée sur un Model:Cycles le
04/11/2026 (note 78 §11).
### RESAMPLE

`tweaks/model-cycles_OS1.13/79-resample.json` est produit par `tools/gen_resample.py`, qui compose seule avec
`tools/compose.py --resample` la partie `resample` du constructeur (`tools/machines/resample/`, objet construit par
`tools/gen_parts.py`) : l'appel du mixeur par la fonction audio (`0x40059872`) passe par l'enregistreur, qui prend une
piste avant le mixeur, le mix principal ou l'USB après lui, dans une réserve de RAM à lui (`0x42800000..0x43000000`) ;
SETTINGS + RECORD (`0x40024482`, SETTINGS aussi par ses événements, `0x4007240c`) ouvre sa page ; la prise est nommée
dans l'éditeur de noms d'origine et enregistrée dans `/recordings` ([note 79](notes/79-resample.md)). La preuve tourne
sur le code de l'OS (Unicorn) :
```sh
python3 tools/gen_resample.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/resample_host.py
python3 tools/emu/test_resample.py --cycles model-cycles_OS1.13.syx [--keys] [--show]
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --resample                         # seul
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines sampler --resample      # avec SAMPLE
```
MAIN OS patché, `resample` seul : `d88f8603927fd2bbf8eade07af3cd58994e6bafa17a3f4145751e7ba6a8a9a9f` ; avec SAMPLE 0.17 et ses images :
`5b78474801ce8fc7dae526ebea132f96ad8f609d8ba2899812537bb57a28b46c` (sans images : `878d0560…` ; la couche de raccourcis 0.6 ; SAMPLE 0.15 : `92a109a8…` ; avec la couche 0.5 : `d1852177…` ; SAMPLE 0.14 : `87476afd…` ; SAMPLE 0.13 : `e6e162fe…`) ; avec SAMPLE 0.13 et Trig Preview (le fichier essayé sur
un Model:Cycles depuis la ligne de commande le 04/11/2026, note 79 §12) :
`15a32ac02984461ede21bca62bf83e93aa2599bf3f4734c6f18ff2828ef6c76a`, le même que la page construit avec ces trois cartes,
téléchargé depuis la page et testé sur un Model:Cycles le 04/11/2026 (note 79 §13) ; avec toutes les cartes de la page (treize, release
0.39) : `7359f2a209e377fed9806ec9a768bf1a3f29205385edf3f5ae9c2896d9441847`.

### Transpose

`tweaks/model-cycles_OS1.13/81-transpose.json` est produit par `tools/gen_transpose.py`, qui compose seule avec
`tools/compose.py --transpose` la partie `transpose` du constructeur (`tools/machines/transpose/`, objet construit par
`tools/gen_parts.py`), toujours avec la couche de raccourcis (depuis sa 0.6, MACHINES y est une touche tenue sur toutes
les pistes) : en mode clavier, MACHINES + TRIG 15 / 16 déplacent le clavier des TRIG d'une octave (KBT, `0x4001a164`),
MACHINES + TRIG 8 / 9 / 11 / 12 font sauter la hauteur de la piste active (le mot PITCH après le lissage, `0x400597a8`) ;
les six touches s'allument avant toutes les vues (`0x40006a76`) et l'interruption du panneau les atténue
(`0x40059dea`) ; depuis la 0.3, un rechargement du pattern (FUNC + PATTERN, les trois appels de `0x400107d8`) remet les
sauts à 0 ([note 80](notes/80-transpose.md)). La preuve tourne sur le code de l'OS (Unicorn) :
```sh
python3 tools/gen_transpose.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/probe_transpose.py --cycles model-cycles_OS1.13.syx
python3 tools/emu/test_transpose.py --cycles model-cycles_OS1.13.syx [--dry]
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --transpose                         # seul
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines sampler --transpose      # avec SAMPLE
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --transpose --transpose-n 3         # essai : 333 Hz
```
MAIN OS patché, `transpose` seul : `637d945544ae0fcc3b0242382bc02752d310ed4b0836d00cfa25c7ab04dbb4ff` ; avec SAMPLE 0.17 et ses images :
`5a6356884fa3ba27497315e4133df6add998c1f5d40d7f9e78e8391fdae41b6e` (sans images : `5a4d375f…` ; SAMPLE 0.15 : `96cb4ba0…`) ; avec toutes les cartes de la page (quatorze,
release 0.51) : `398b05d1e35e04d071ccda408a7f17bf1967e14888a185858d48fe7bf8471ee9`. La période d'atténuation de 3 ms
(essai, jamais proposé) seule : `614643c26793f343227adc404819a2e147ff8cd849f6744c5bd161f4d870cf3d`. Transpose 0.3, le
rechargement du pattern remet les sauts à 0 (note 80 §5.5) ; avec la 0.2 : `ad9e4492…`, `ab74cbf2…`, `cd89791b…`,
`1a29b016…`. Essayé depuis la ligne de commande sur un Model:Cycles le 06/11/2026 (note 80 §6.1 : avec SAMPLE, la 0.2
avec les quatorze cartes, la 0.3 avec les quatorze cartes et les deux rechargements) ; puis flashé depuis la page le
même jour (« passt »).

### Perform Kit

`tweaks/model-cycles_OS1.13/82-perform.json` is written by `tools/gen_perform.py`, which composes alone, with
`tools/compose.py --perform`, the builder's part `perform` (`tools/machines/perform/`, its object built by
`tools/gen_parts.py`): SETTINGS + PATTERN switches a mode in which a pattern change keeps the six track sounds, the six
levels and the four effect values (bytes 0..693 of the kit, copied at the sequencer's four writes of the playing kit);
the kit serializer hands out the pattern's own bytes, so nothing is saved until the pattern is; a popup and a
checkerboard stripe on the main screen show the mode ([note 81](notes/81-perform-kit.md)). In a build with RESAMPLE
the part reads RESAMPLE's SETTINGS byte; behind its mark is the main draw the build has otherwise (the stock one,
SAMPLE's, or the dispatcher's). The proof runs on the OS's own code (Unicorn), the logic also on the host:
```sh
python3 tools/gen_perform.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_perform.py --cycles model-cycles_OS1.13.syx [--dry]
(cd tools/machines/perform && cc -std=c99 -Wall -Wextra -Werror -DPK_HOST -o /tmp/test_perform test_perform.c && /tmp/test_perform)
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --perform                           # alone
python3 tools/compose.py --cycles model-cycles_OS1.13.syx --machines sampler --perform        # with SAMPLE
```
Patched MAIN OS, `perform` alone: `65a6f2a90c664cfd29c8c375ec1c6ddf376fa46ec63f0614215e6a17c9d96b17`; with every card of
the page (seventeen, release 0.63: `--machines sampler,solid,chordtables,digidelay,pots,smpfilter,crush,ring,reso,eq
--cpu --resample --transpose --perform --with control-all-config,trig-preview,trig-cond-order`):
`d91ef5bf0372dff894a1fa6250cdd18a46e49e05a46e64b12f47ba9776d2ca37`. Tested on a Model:Cycles from the command line on
2026-11-14 (note 81 §9 to §10.1: alone, every step of saving; with every card, the switch and the mark), then flashed
from the page the same day (note 81 §12). Release 0.64, with SOLID's and SAMPLE's own pictures (note 71 §13):
`c5d6879a3b55b9ebd787770ddccd43733ef04d330e851130429a6f82ac747b00`.

### Trig Cond dans un autre ordre

`tweaks/model-cycles_OS1.13/80-trig-cond-order.json` est produit par `tools/gen_trig_cond_order.py`, qui assemble
`tools/machines/trig_cond_order/trig_cond_order.S`, y écrit l'ordre (`ORDER`) et le pose dans le masque de sprite 48×22
libéré `0x40152d38` ([note 70](notes/70-trig-cond-order.md)). Un trig tenu + CHANCE parcourt FILL … !1st, puis 1:2 …
8:8, puis 1 % … 99 %, et les cinq points sous la valeur suivent cet ordre ; le code que garde le trig, que joue le séquenceur et qu'affiche l'écran reste celui de l'OS
d'origine. La preuve fait tourner la méthode « valeur + pas » de `TrigParameterSet`, le pas du potard d'un trig tenu
(`0x4001e268`) jusqu'à l'octet de la condition et les cinq points de la fenêtre de valeur (`0x4001d818`), d'origine
et modifié :
```sh
python3 tools/gen_trig_cond_order.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_trig_cond_order.py --cycles model-cycles_OS1.13.syx \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,arp,trig-hold,tempo-max --syntakt Syntakt_OS1.42.syx]
python3 tools/build.py -i model-cycles_OS1.13.syx -t trig-cond-order
```
MAIN OS patché, `trig-cond-order` seul : `018690231f705e49422a5032a36d1685637db2dd682c65942277759d7da351f1`
(la première version, sans les points, `43562797…`).
### OS Cycles pour Model:Samples (et retour par USB)

Pas un tweak : `tools/crossflash.py` met l'OS Cycles officiel dans le conteneur officiel du Model:Samples, en changeant les
32 octets de la constante de sa clé de vérification (`0x401296b2`) pour qu'il accepte la signature du Samples ; le retour
est l'OS Samples officiel, inchangé, dans le transport SysEx du Cycles ([note 41](notes/41-os-cycles-sur-samples.md)).
La clé vient du `.syx` officiel du Samples, jamais du dépôt. La preuve fait tourner les vérifications de mise à jour des
deux OS sur les deux fichiers :
```sh
python3 tools/crossflash.py --cycles model-cycles_OS1.13.syx --samples model-samples_OS1.13.syx --to samples
python3 tools/crossflash.py --cycles model-cycles_OS1.13.syx --samples model-samples_OS1.13.syx --back-samples
python3 tools/emu/test_crossflash_samples.py --cycles model-cycles_OS1.13.syx --samples model-samples_OS1.13.syx
```

| Fichier | SHA-256 |
|---|---|
| `model-cycles_OS1.13_for-model-samples.syx` | `c06c23f31e50fac6ad40cd0f633acd4a7da4f63c929dff563dae887b93105dd4` |
| son MAIN OS | `b6fbc48f7d7d07cecae3859e07270fa2298f393e8afa2643144bdb4efc317aad` |
| `model-samples_OS1.13_back-from-cycles-os.syx` | `d63ce13dd1a5039d11b60d3f69d4e88e9d0f56fb2e7350c105ec641d32083680` |

### OS Cycles avec mods pour Model:Samples

Le firmware est **toujours l'OS du Model:Cycles**, avec les mods choisis, quelle que soit la machine
([note 57](notes/57-os-cycles-quelle-que-soit-la-machine.md)) : sur un Model:Samples, le sampling vient de Model-TG. On
construit les mods comme pour un Model:Cycles, puis `tools/mods_for_samples.py` met ce MAIN OS dans le conteneur officiel
du Samples avec le même correctif de 32 octets que `crossflash.py --to samples` (toujours appliqué), et écrit deux
fichiers : `_smp-os` pour un Model:Samples sous son OS (transport `0x0F`), `_cyc-os` pour un Model:Samples déjà sous un
OS Cycles de la page ou de ce script (transport `0x11`, pour changer de mods). La page fait la même chose
(`MCBuilder.modsForSamples`, choix de la machine dans l'onglet Mods).
```sh
python3 tools/build.py -i model-cycles_OS1.13.syx -t model-tg,arp -o mods.syx
python3 tools/mods_for_samples.py --cycles model-cycles_OS1.13.syx --samples model-samples_OS1.13.syx --mods mods.syx
python3 tools/emu/test_mods_for_samples.py --cycles model-cycles_OS1.13.syx --samples model-samples_OS1.13.syx \
    --syntakt Syntakt_OS1.42.syx
```

Sans mods (l'OS Cycles officiel en `--mods`), le fichier `_smp-os` est octet pour octet celui de
`crossflash.py --to samples`. Empreintes de la preuve (le MAIN OS installé est celui de `REF_MAINOS` sauf les 32 octets
de la clé) :

| Combinaison | `_smp-os` (SHA-256) | `_cyc-os` (SHA-256) |
|---|---|---|
| `model-tg` | `1985e8e703092b768d32aa2c9b446cb0f95c1f944dc3e206f75973337469f686` | `1317199fbc625c38700344b69ce00496cdee0c8be6fae305843e6373e6394d19` |
| `6ch-usbup,model-tg` | `fdbf4621e291618a98de64c561a39de59852d5a4dfdb58c927e312467557a839` | `a5a21ac6dfe5697b9e39fa80518a53989af4be8edac3cf9cbe6f1ebddb00ce79` |
| `model-tg-st,sample-preview-st,macro-tg` | `0a525bc98e88f3e7ebcd7ff6a774bd23c65f315d73c6ffce27c1331632e86aee` | `d700dd1186ac68da5c26daa769612d76fbe5f76efd56f9d56c4225dbc5ff15fc` |
| `6ch-usbup,model-tg-st,sample-preview-st,trig-hold,arp,tempo-max,boot-anim,multiline-browser,level-pan-values,trigless-dim,midi-live-both,lfo-plus,syntakt-tg-sd-cp-toy-bits-swarm-macro` | `5fb25f5b1a588c10e52d3d6a5514c1641369034227106bc214786a3b1a6ae47d` | `3682e474204c242b1285be2f74eaa40a03a4b3885473e937c9f6fd64735f2f3f` |

### Animation de démarrage modded-cycles

`tweaks/model-cycles_OS1.13/43-boot-anim.json` est produit par `tools/gen_boot_anim.py` : le corps de la tâche d'animation de
démarrage de l'OS (`0x40053a6c`) est réécrit à sa place, assemblé depuis `tools/machines/boot_anim/` (690 o sur 1 032, aucune
place libre). Mêmes 80 images de 20 ms, même fin ; les carrés du logo puis « modded-cycles » ([note 39](notes/39-animation-demarrage.md)).
La preuve fait tourner la tâche d'origine et la nouvelle avec le vrai code de l'écran de l'OS, jusqu'au registre du DSPI1, et
compare chaque image vue sur l'écran au modèle du générateur ; le modèle de l'écran est d'abord validé par un « 7 » des grands
chiffres de l'OS, écrit par son code de texte (l'OS compte les lignes depuis le bas, note 39 §2) ; `--gif` écrit l'animation vue :
```sh
python3 tools/gen_boot_anim.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_boot_anim.py --cycles model-cycles_OS1.13.syx [--gif anim.gif] \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,arp,trig-hold,tempo-max]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `boot-anim` | `388ed6c6ee65529e2dc2d2c93aadb37c6878324acf90ad931d5ca3f7c6b68b27` |
| `6ch-usbup,boot-anim` | `76b1a532c8119ce222a3545b8a21b4cf0b2e12887e40c32f9a80b0d70975533e` |
| `model-tg,boot-anim` | `cbec181684805bf37dd07c62dc47f7daf35e6abab530a3f3b06ec5db590278ec` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max,boot-anim` | `d468a729f32780870dbd591e52e8c782a5cdd347459ac1c61ef35473e26c9323` |

### Accords de gamme sur TRIG 1–16

Contribution de Nico Heuser ([PR #46](https://github.com/18nelli18/Modded-Cycles/pull/46)).
`45-chord-keys.json` est généré depuis `tools/machines/chord_keys/` par `tools/gen_chord_keys.py`
(GCC m68k-elf 16.2.0, binutils 2.47 : ceux de Homebrew, ou compilés depuis les sources d'Ubuntu comme au
[§16 de la note 42](notes/42-clavier-accords-diatoniques.md)). Le générateur refuse `m68k-linux-gnu-gcc` : son ABI lit
dans `a0` les pointeurs que l'OS rend dans `d0`, ce qui fausserait les appels à l'OS ([note 42 §6](notes/42-clavier-accords-diatoniques.md)).
**Testé** sur la machine par Maxime, seul et avec six autres mods (07/10/2026), puis la correction de la note
bloquée (note 42 §16, 10/10/2026). Sélectionnez une piste CHORD,
puis activez **Keys** dans **FUNC + RETRIG**. Root, Scale et I–VII choisissent la tonique, le mode
et les extensions diatoniques ; le majeur s'affiche **MAJ**. Hors édition des pas, TRIG 1–7 jouent I–VII,
8–14 les mêmes degrés une octave plus haut, 15–16 I–II deux octaves plus haut. Les grands pads T1–T6
conservent leur sélection et leur jeu stock ; les accords des TRIG ne déclenchent pas le retrig/arpège.
Réglages par piste, enregistrés avec le pattern. **I–VII** seuls choisissent les extensions ; **SHAPE** règle
la disposition (**BASE**, **CLS0–3**, **OPN0–3**) et **COLOR** les niveaux, sans changement d'octave.
Model-TG est explicitement incompatible.

Quatorze masques identiques sont redirigés avant d'y placer les 5 063 octets de code, constantes et état ; seule la section 3 change. Aucun firmware
n'est distribué dans le dépôt. Génération, preuve autonome, puis preuve avec tous les mods compatibles :

```sh
python3 tools/test_chord_keys.py
python3 tools/gen_chord_keys.py --cycles firmware/model-cycles_OS1.13.syx --check
python3 tools/emu/test_chord_keys.py --cycles firmware/model-cycles_OS1.13.syx
python3 tools/emu/test_chord_keys.py --cycles firmware/model-cycles_OS1.13.syx \
  --with 6ch-usbup,latching-mute,trig-preview,browser-scroll,trig-hold,arp,tempo-max,boot-anim,syntakt-sd-cp-toy-bits-swarm \
  --syntakt firmware/Syntakt_OS1.42.syx
python3 tools/emu/test_chord_keys_release.py --cycles firmware/model-cycles_OS1.13.syx
python3 tools/build.py -i firmware/model-cycles_OS1.13.syx -t chord-keys \
  -o build/model-cycles_OS1.13_chord-keys.syx
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `chord-keys` | `901675f5b8291f3b91d134208236e83431d6a079c73c2d5f1e4e54ebc334321f` |
| `6ch-usbup,chord-keys` | `d6e43f0ca6a8df953df7a12da7458c70552f1b3a8de1bb39213f0c52168f0352` |
| `6ch-usbup,arp,trig-hold,tempo-max,boot-anim,chord-keys` | `0922d3967c6d29ea86c14ffe41a5555cfb5346ecffb6298fe84c8ba3e3c51c43` |
| `macro,chord-keys` | `8731007b4b8c223c14530aa88b1ac73837d4146dcb54678ec2f8054b12056abe` |
| `6ch-usbup,latching-mute,trig-preview,browser-scroll,trig-hold,arp,tempo-max,boot-anim,chord-keys,syntakt-sd-cp-toy-bits-swarm` | `569e6bb39b628ebbd8a8f1ef64e43f0097f4c3d4bb8430974f01dab6d82ca110` |

La preuve exécute les touches, pads, menus, sauvegardes et calculs CHORD du véritable OS ; 14 000 accords
BASE, 2 205 combinaisons SHAPE et les chemins inactifs sont comparés à la référence. COLOR, les frontières de
SHAPE, les libellés et le plafond aigu du premier opérateur sont contrôlés. Les frontières simulées, le coût en instructions et
les vérifications restantes sur la machine sont détaillés dans [la note 42](notes/42-clavier-accords-diatoniques.md).
Les accords étendus restent limités à quatre notes ; l'enregistrement conserve la fondamentale et le réglage
du degré s'applique à la relecture, sans enregistrer une extension différente par trig.

### Machine MACRO (les modèles de Braids)

`tweaks/model-cycles_OS1.13/25-macro.json` (7e machine) et `32-macro-tg.json` (avec Model-TG : 8e machine, par-dessus
`model-tg-st`) sont produits par `tools/gen_macro.py` : le code de Braids d'Émilie Gillet (MIT,
[pichenettes/eurorack](https://github.com/pichenettes/eurorack) au commit `08460a6`, stmlib `e3bd7c9`) compilé tel quel
avec la passerelle `tools/machines/macro/macro.cc`, en charge utile rangée après l'image et reconstituée au démarrage à
`0x43000000` (`0x46700000` avec Model-TG), avec la mécanique des machines ajoutées des moteurs du Syntakt
([note 43](notes/43-machine-macro.md)) ; 13 modèles rendus à 48 kHz et le lo-fi RATE/BITS sur FINE, réglé par FUNC + PITCH
([note 55](notes/55-macro-allegee-et-lofi.md), §8). Le générateur a besoin du clone d'eurorack (sous `vendor/`, ignoré par git) et de
`m68k-linux-gnu-g++` (les JSON versionnés viennent du GCC 13.3 d'Ubuntu 24.04 : un autre GCC donne d'autres octets) ; la
preuve, de `g++` pour Braids compilé pour l'ordinateur, la référence :
```sh
git clone https://github.com/pichenettes/eurorack vendor/eurorack
git -C vendor/eurorack checkout 08460a69a7e1f7a81c5a2abcc7189c9a6b7208d4
git -C vendor/eurorack submodule update --init stmlib
python3 tools/gen_macro.py --cycles model-cycles_OS1.13.syx --eurorack vendor/eurorack [--check]
python3 tools/emu/test_macro.py --cycles model-cycles_OS1.13.syx --eurorack vendor/eurorack [--quick] \
    [--with 6ch-usbup,model-tg-st,sample-preview-st,trig-hold,arp,tempo-max,boot-anim]
python3 tools/emu/test_macro.py --cycles model-cycles_OS1.13.syx --eurorack vendor/eurorack --spectres   # notes/55 §2
```
Avec les moteurs du Syntakt : les tweaks combinés de la section suivante. Incompatible avec SD VINTAGE (même mécanique,
même place).

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `macro` | `d15698c455425b9ea3b5ba54f5ffded1fc914464fc9db4529f389e8efc6a1786` |
| `6ch-usbup,macro` | `7958b0c5ad0392977a5dee2c559460d5f2ee5ceb11632dd985ea102eda09f49e` |
| `model-tg-st,macro-tg` | `12c5d004ec2faae36d96f8fa31593c77d3b9104d22b5f52c0bcb88f68dadd5bb` |
| `6ch-usbup,model-tg-st,macro-tg,trig-hold,arp,tempo-max,boot-anim` | `39aaf51be940e774e65133fa0a54d2eefc5c8948f1ce3a54e59858685476558c` |

### MACRO avec les moteurs du Syntakt

`tweaks/model-cycles_OS1.13/24-syntakt-<moteurs>-macro.json` et `31-syntakt-tg-<moteurs>-macro.json` (avec Model-TG,
par-dessus `model-tg-st`) sont produits par `tools/gen_macro_syntakt.py` : les moteurs exactement comme dans leur tweak
(passerelle reprise octet pour octet, pas recompilée), MACRO en dernière machine, après eux ; la charge utile commune
(476 128 o) est rangée compressée et décompressée au démarrage ([note 50](notes/50-macro-avec-moteurs-syntakt.md)).
Mêmes besoins que les deux mods (fichier Syntakt, clone d'eurorack, `m68k-linux-gnu-g++` 13.3) :
```sh
python3 tools/gen_macro_syntakt.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx \
    --eurorack vendor/eurorack [--engines sd,cp] [--tg] [--check]
python3 tools/emu/test_macro_syntakt.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx \
    --eurorack vendor/eurorack [--engines sd,cp] [--only alone|tg] [--with 6ch-usbup,trig-hold,arp,tempo-max,boot-anim]
```

| `-t` (avec `--syntakt Syntakt_OS1.42.syx`) | MAIN OS patché (SHA-256) |
|---|---|
| `syntakt-sd-macro` | `85d615ecf3710e9f39f61f1e29ea1727902adae34027ee6611a7005995c8eca2` |
| `syntakt-sd-cp-toy-bits-swarm-macro` | `fe83cc278357b13eb340801b80d9c5d8c4da36a537d6edd17649a7c406b70184` |
| `6ch-usbup,syntakt-sd-cp-toy-bits-swarm-macro,trig-hold,arp,tempo-max,boot-anim` | `57b6866d07a3c731347320b6541dd07d7f991889d7f1bdcb7b7a3fd8f69e347d` |
| `model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm-macro` | `d8c0c0d67139df6b983c9330887d0a9e5ce5365ed567b45285431b978d588826` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm-macro,trig-hold,arp,tempo-max,boot-anim` | `b6e7b757c299b3fb42f19cba85674e6404a08a00b31aabe9cad570cc36e3a973` |
| `6ch-usbup,model-tg-st,sample-preview-st,syntakt-tg-sd-cp-toy-bits-swarm-macro,trig-hold,arp,tempo-max,boot-anim` | `fceae95b069d1fae8c25612558ab355b97b89a79575a82e38365bc6939076b8a` |

### Machine ACID (basse acide à la manière de la TB-303)

`tweaks/model-cycles_OS1.13/26-acid.json` (7e machine) et `35-acid-tg.json` (avec Model-TG : 8e machine, par-dessus
`model-tg-st`) sont produits par `tools/gen_acid.py` : notre code en virgule fixe d'après le modèle d'Open303 de Robin
Schmidt (MIT, [RobinSchmidt/Open303](https://github.com/RobinSchmidt/Open303) au commit `313bf0d`), `tools/machines/acid/`,
avec la mécanique de machine ajoutée de MACRO (`gen_macro.added_machine`) ; la charge utile est reconstituée au
démarrage à `0x43000000` (`0x46700000` avec Model-TG) ([note 54](notes/54-machine-acid.md)). Pas de clone à faire : les
sources sont dans le dépôt. Le générateur a besoin de `m68k-linux-gnu-gcc` (les JSON versionnés viennent du GCC 13.3
d'Ubuntu 24.04 : un autre GCC donne d'autres octets) ; la preuve, de `gcc` pour le cœur compilé pour l'ordinateur (la
référence) et de `m68k-elf-objdump` (un lien vers `m68k-linux-gnu-objdump` suffit) :
```sh
python3 tools/gen_acid.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_acid.py --cycles model-cycles_OS1.13.syx [--quick] \
    [--with 6ch-usbup,model-tg-st,trig-hold,arp,tempo-max,boot-anim]
```
Incompatible avec SD VINTAGE (même mécanique, même place). Avec MACRO ou les moteurs du Syntakt : les versions
combinées, ci-dessous.

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `acid` | `01e81a42dd24060d73b68e3abc0fc55d40b976a5fcef16f970b1bc4288aeade8` |
| `6ch-usbup,acid` | `990a083a302ee2559d7f7790132c842d1f189ae06eb3ae7156e4ccd3292d761b` |
| `model-tg-st,acid-tg` | `39b0b593eb8ee353a9bc8897ea67bdbe8975088d165ad5c32988e00c5a6220cf` |
| `6ch-usbup,model-tg-st,acid-tg,trig-hold,arp,tempo-max,boot-anim` | `d878cba74140edcc0dbf4e056cd8f0d67a39a761ad002770bfbbdaf829ca3de9` |
| `6ch-usbup,model-tg-st,sample-preview-st,acid-tg,trig-hold,arp,tempo-max,boot-anim,multiline-browser,level-pan-values,trigless-dim` | `f13e4b3c13b125551503a494f7d900802e0d94a86f4d058d22991b82b0437ff0` |
| `6ch-usbup,acid,trig-hold,arp,tempo-max,boot-anim,multiline-browser,level-pan-values,trigless-dim` | `ca155f8d6e5a08e821d34ff774951ccc0651f2bb6b2065e83e39660e134424a8` |
| `6ch-usbup,acid,track-filter,trig-hold,arp,tempo-max,boot-anim,multiline-browser,level-pan-values,trigless-dim` | `9f440f23090b103f6b6399dc43dda21dcfa4456817ca76cb23633b14fd98d8f3` |

ACID avec MACRO et les moteurs du Syntakt ([note 54 §11](notes/54-machine-acid.md)) : `tools/gen_acid_combos.py`
produit `25-macro-acid.json` et `32-macro-acid-tg.json` (MACRO puis ACID), et `24-syntakt-<moteurs>[-macro]-acid.json`
et `31-syntakt-tg-<moteurs>[-macro]-acid.json` (les moteurs, MACRO s'il est coché, puis ACID) : 126 fichiers. ACID y
est compilé avec `GOV_SKIP` et lié à `+0x76000` dans toutes ; MACRO comme dans `25-macro.json` (même clone de
pichenettes/eurorack que `gen_macro.py`) ; les moteurs comme dans leurs tweaks. La preuve demande `gcc`, `g++` (Braids
et ACID compilés pour l'ordinateur) et `m68k-elf-objdump` :
```sh
python3 tools/gen_acid_combos.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx \
    --eurorack vendor/eurorack [--engines sd,cp | --engines none] [--tg] [--macro yes|no|both] [--check]
python3 tools/emu/test_acid_combos.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx \
    --eurorack vendor/eurorack [--engines sd,cp,toy,bits,swarm | --engines none] [--macro yes|no|both] \
    [--only alone|tg] [--quick] [--with 6ch-usbup,model-tg-st,trig-hold,…]
```

| `-t` (avec `--syntakt Syntakt_OS1.42.syx`) | MAIN OS patché (SHA-256) |
|---|---|
| `macro-acid` | `bf24f6c0461ce168daf94b3caf6041996d579b0da328338197d38fd1ac63425b` |
| `6ch-usbup,macro-acid` | `19a64308feb58da22152d3aedba585858877b22bf1f3a96de69dfd9fed54c54a` |
| `model-tg-st,macro-acid-tg` | `20288a4746499f43f7e9350fdcce0ec6f763bb902e3c3d580c69be4cda276acf` |
| `syntakt-sd-acid` | `cbd0dc0b07ce7931e83838cb4f17467e8745d893234e96cfb1abd128b71ae62f` |
| `syntakt-sd-macro-acid` | `13079fc76c734a5a46e3481c88f0bf7ea7bc0387524262c2c66678cc965b418f` |
| `syntakt-sd-cp-toy-bits-swarm-macro-acid` | `4fe2f5a8ce63b2f51b4a32fd523c6633237addfa9b53f314b7cf2c93880b4264` |
| `model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm-macro-acid` | `a44bc3e09b82ce2f8f4cfb9949787794c1ea27a09bdeb6f88499310e527fea5f` |
| `6ch-usbup,model-tg-st,sample-preview-st,syntakt-tg-sd-cp-toy-bits-swarm-macro-acid,trig-hold,arp,tempo-max,boot-anim,multiline-browser,level-pan-values,trigless-dim` | `82cdc6a71078307692b7085410b74e0963dd2f1559ced16ac55c56bfe6960ce3` |
| `6ch-usbup,syntakt-sd-cp-toy-bits-swarm-macro-acid,track-filter,trig-hold,arp,tempo-max,boot-anim,multiline-browser,level-pan-values,trigless-dim` | `4e22da455cda7187ea8c441f46c6cf8e4d84ede429ba1d4308928cbdcbf4efd1` |

### Navigateur sur plusieurs lignes

`tweaks/model-cycles_OS1.13/44-multiline-browser.json` est produit par `tools/gen_multiline_browser.py`, qui assemble
`tools/machines/multiline_browser/multiline_browser.S` (370 o) dans le masque de sprite 47×47 libéré `0x401904b4`
(`tools/sprites.py`) : le navigateur de presets (sons, dossiers, échantillons de Model-TG) montre 3 lignes en petite police au
lieu d'une, « > » devant la ligne du curseur, le son chargé inversé, un repère de 7 px pour les dossiers. Quatre accroches dans
le dessin `0x400a539c`, huit constantes, et deux retouches de la liste dans un sous-dossier de +Drive (`0x4003f622`,
`0x400406a8`) pour que le curseur y descende sur les 3 lignes au lieu de rester sur la 1ʳᵉ ; l'accroche du défilement des noms longs (`0x400a55a1`, browser-scroll et Model-TG)
n'est pas touchée et ne sert qu'à la ligne du curseur ([note 40](notes/40-navigateur-multiligne.md)). La preuve fait tourner le
vrai dessin, avec les vraies polices, dans un vrai écran de l'OS ; `--png` écrit l'écran d'origine et le modifié :
```sh
python3 tools/gen_multiline_browser.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_multiline_browser.py --cycles model-cycles_OS1.13.syx [--png dossier] \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max --syntakt Syntakt_OS1.42.syx]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `multiline-browser` | `75a5054403de65968e07bed84f3fcb183719b965626fd0c042b29bc963f8af31` |
| `6ch-usbup,multiline-browser` | `ce1681cd208f4ca812f25b9386ad64fd0c4aa5957314cde5ba6f77a302d2c49f` |
| `browser-scroll,multiline-browser` | `32e4a6b8e3897a1faa8ab12b33cd8e82b5a214cd3e91b80824ab17bc9d6042c1` |
| `model-tg,multiline-browser` | `428e7bc4f18fde071a201544266d97012dd41556220867b60b59df193d861221` |
| `boot-anim,multiline-browser` | `120860e74d59d207951128ed926d8e0196d9d16142c6a67b004d64510bed339e` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max,boot-anim,multiline-browser` | `0787cf23a48549870bb9580b3b99e284c72056c677986671659e7f949d67d1e2` |

### Volume et pan en chiffres sur l'écran principal

`tweaks/model-cycles_OS1.13/46-level-pan-values.json` est produit par `tools/gen_level_pan.py` : d'après le mod de djd_oz,
LEVEL/DATA affiche le volume de la piste sélectionnée (0 à 127) à la place du haut-parleur, FUNC + LEVEL/DATA son pan (-64 à
63) à la place du « R », 3 s après le dernier mouvement ; LEVEL/DATA avance de 1 au lieu de 2 sur l'écran principal. Assemblé
depuis `tools/machines/level_pan/` dans deux masques de sprites libérés ([note 44](notes/44-volume-pan-en-chiffres.md)). La
preuve passe par le vrai tick de la tâche de l'interface, le pas de LEVEL/DATA, le gestionnaire des encodeurs et le dessin de
l'écran principal, compare chaque pixel au modèle pour les 256 valeurs, et, avec `--djd`, au fichier de djd_oz ; `--show`
dessine l'écran avec les barres de l'OS :
```sh
python3 tools/gen_level_pan.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_level_pan.py --cycles model-cycles_OS1.13.syx [--show] \
    [--djd model-cycles_OS1.13_PAN-Level-values-3s-turn-only.syx] \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,arp,trig-hold,tempo-max,boot-anim,trigless-dim \
     --syntakt Syntakt_OS1.42.syx]
```

### Trigless trigs atténués

`tweaks/model-cycles_OS1.13/47-trigless-dim.json` est produit par `tools/gen_trigless_dim.py` : d'après le mod de djd_oz, en
mode grille, une touche qui porte un trigless trig prend l'état de LED 260 (traité comme 4 par l'OS) ; l'interruption du
panneau, qui charge les verrous des LED, ne l'allume qu'une milliseconde sur trois (333 Hz) en rechargeant sa rangée en plus
du tour d'origine. Assemblé depuis `tools/machines/trigless_dim/` dans deux masques de sprites libérés
([note 45](notes/45-trigless-trigs-attenues.md)). La preuve fait tourner le vrai code de l'interruption du panneau, du tick des
LED et de l'image de l'interface sur une même ligne de temps, d'origine contre modifié, avec un modèle des verrous ; `--defsym`
construit les variantes d'essai (jamais versionnées, `--out` hors de `tweaks/`) :
```sh
python3 tools/gen_trigless_dim.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/gen_trigless_dim.py --cycles model-cycles_OS1.13.syx --defsym WAIT=68 --out essai-0p5us.json
python3 tools/emu/test_trigless_dim.py --cycles model-cycles_OS1.13.syx \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,arp,trig-hold,tempo-max,boot-anim,level-pan-values \
     --syntakt Syntakt_OS1.42.syx]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `level-pan-values` | `7fb415147e8605ab035e3fc064986b1c640cddc7ced972ad5b6ff6fcaa9f5eb7` |
| `trigless-dim` | `ff47b71399d7ab72a53f73e2e0ff0f5759e4ef20fe1da1780eb0c28e85ed4631` |
| `level-pan-values,trigless-dim` | `c4a547df87f681e27e5f7d0b04d9e08d601017577f810e2dced51eb4a68797e6` |
| `model-tg,level-pan-values,trigless-dim` | `551e86a8aa2a0288440a8e620ff1cdf11da34676489a5895f4f9a031021efd07` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max,boot-anim,level-pan-values,trigless-dim` | `366aebfc88b31a9f6d8206e53fa94b76897ef7fc929ff0237aa57578e3fe7540` |

### THRU qui envoie aussi le MIDI du Cycles (d'AveyCole)

Deux tweaks d'AveyCole ([AveyCole/Modded-Cycles](https://github.com/AveyCole/Modded-Cycles), commit `ba5f8bb`), produits par
`tools/gen_midi_thru.py`, qui s'excluent ([note 53](notes/53-midi-thru-aveycole.md)) :

- `50-midi-both.json` (`midi-both`) : avec THR choisi dans CONFIG › MIDI › PORTS › OUT/THRU, le Cycles relaie le MIDI reçu et
  envoie aussi son horloge, ses notes et ses paramètres. Les trois portes de sortie (`0x4000154a`, `0x4000156a`, `0x40001590`)
  ne lisent plus le réglage. Aucune place libre.
- `51-midi-live-both.json` (`midi-live-both`) : sur la ligne OUT/THRU qui affiche THR, FUNC + appui sur LEVEL/DATA alterne THR
  seul et THR + MIDI du Cycles (valeur 2 du réglage `0x404e9b50`). `tools/machines/midi_thru/midi_thru.S` (132 o) est assemblé
  dans le masque de sprite 34×34 libéré `0x40192ba4` (`tools/sprites.py`) ; le fork le mettait en `0x40167c50`.

La preuve fait tourner les vraies portes de sortie, le vrai relais, la vraie touche de la ligne et son affichage, d'origine et
modifiés, et compare avec la version du fork :
```sh
python3 tools/gen_midi_thru.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_midi_thru.py --cycles model-cycles_OS1.13.syx \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max --syntakt Syntakt_OS1.42.syx]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `midi-both` | `5d0755ef0bd34617bcd5adbb54f09c77cd066e7439d26cc460bbadb0090bb75f` |
| `midi-live-both` | `ca439a48cb8d818c8c09a8bfc8fa1ac391ffa5f9263e971db39ff602afce6742` |
| `6ch-usbup,midi-both` | `efc0f1c328f8b65eedd45bc20dd68b513eb091ea1c67d8d3fba0d0e60081b17a` |
| `6ch-usbup,midi-live-both` | `09f5b51061b2d387c897824984618f7f8b92d2d5028750115b3f6cb3eb2748dc` |
| `model-tg,midi-live-both` | `29e4b13b5cf8a995c163ddfd8040c7e41567f687fde27bd6985d3bf2042ca048` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max,boot-anim,multiline-browser,midi-both` | `705302a9ddf03d02dc2dae40422796b476d1583261e2971560a195dd033d18a8` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max,boot-anim,multiline-browser,midi-live-both` | `a00ac9d50ce7e11a92737ee54ddf782ac94ce29bdd9f40caf29cb4be434319ad` |

### Filtre par piste

`tweaks/model-cycles_OS1.13/48-track-filter.json` est produit par `tools/gen_track_filter.py` : le filtre (`track_filter.S`), les
potards, l'affichage et la sauvegarde (`tf_ui.S`) sont assemblés depuis `tools/machines/track_filter/` et liés par
`track_filter.ld` dans quinze masques de sprites 35×35 libérés (3 001 o) ; les tables sont calculées par le générateur. Quatre
paramètres de toutes les machines sur les descripteurs « Error » 1 à 4, accroche après Volume + Dist ([note 47](notes/47-filtre-piste.md)).
Incompatible avec Model-TG pour l'instant. La preuve fait tourner la vraie boucle des voix et le vrai site de l'accroche, l'OS sans
le filtre à côté, puis l'interface et la sauvegarde fonction par fonction :
```sh
python3 tools/gen_track_filter.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_track_filter.py --cycles model-cycles_OS1.13.syx [--quick] \
    [--with 6ch-usbup,syntakt-sd-cp-toy-bits-swarm,arp,trig-hold,tempo-max,boot-anim --syntakt Syntakt_OS1.42.syx]
    [--with syntakt-sd-cp-toy-bits-swarm-macro,6ch-usbup,chord-keys,level-pan-values,trigless-dim,multiline-browser,… --syntakt Syntakt_OS1.42.syx]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `track-filter` | `f5db01334779499fc0932cfdc4a23c899319d333fed98fc5169972080b662967` |
| `6ch-usbup,track-filter` | `340fb353bacb25fc2923f836b7d685a704c710e43988258cdc2d21f42b997016` |
| `6ch-usbup,syntakt-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max,boot-anim,track-filter` | `5493f878652f5050a75ed0aab4aba9b19671764455943c5dd525484465c3f5ac` |
| `macro,track-filter` | `ec73769aa6f665bd4696bbc9e20de9de393aa21f9298d8f0f25ebee2a9713814` |

### LFO 2, 3, 4 (d'après DavidCaruso)

LFO 2, 3, 4 du firmware `Model-TG-VA-DR-v1` de DavidCaruso, réécrits sans ses octets ([note 56](notes/56-ajouts-davidcaruso.md)).
`60-lfo-plus.json` (`lfo-plus`, avec ou sans Model-TG) : `tools/machines/lfo_plus/lfo_plus.S` (1 844 o) dans sept
masques 34×34 libérés, mémoire de travail `0x4233f000..0x4233f49b` (§3). Son fichier n'est jamais nécessaire : la
preuve accepte `--david Model-TG-VA-DR-v1.syx` pour comparer à son binaire, sans l'exiger. Incompatible avec
`track-filter` (mêmes emplacements du son, §3.6) : `build.py` refuse les deux ensemble.

```sh
python3 tools/gen_lfo_plus.py --cycles model-cycles_OS1.13.syx [--check]
python3 tools/emu/test_lfo_plus.py --cycles model-cycles_OS1.13.syx [--with model-tg,arp] [--david Model-TG-VA-DR-v1.syx]
```

| `-t` | MAIN OS patché (SHA-256) |
|---|---|
| `lfo-plus` | `61c48e85f74bca0387871df4bd82cd8bfa770759fbfab9dc629ec62e4b9dd26c` |
| `model-tg,lfo-plus` | `32a8bbfe233fb0440f9ef622b9ee5ede0eaf7e8258d63c10aa5fcc70aad07a61` |
| `model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,lfo-plus` | `b9d7de91dfa89e973359556098dd6d94eac1e8a60517d8d7a7cfd4135971d881` |
| `macro,lfo-plus` | `3400211f0037631364435452b5491898d60b5f4473c215cfb7578d889c1e438a` |
| `6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,trig-hold,arp,tempo-max,boot-anim,multiline-browser,lfo-plus` | `7717f596492bf1eb375e9800f7901e1769e9d1d51b0036cd8a5f28c57f5de975` |

### Écoute d'un pas en pause

`trig-preview` (et sa copie dans Model-TG) accepte le séquenceur en pause, où le met un Stop MIDI reçu même à l'arrêt : 3 octets
retouchés en `0x40148a30` ([note 34](notes/34-ecoute-en-pause.md)). La preuve passe par le vrai gestionnaire du Stop MIDI de l'OS,
puis par le mode grille :
```sh
python3 tools/emu/test_trig_preview.py --cycles model-cycles_OS1.13.syx \
    [--with 6ch-usbup,model-tg-st,syntakt-tg-sd-cp-toy-bits-swarm,arp,trig-hold --syntakt Syntakt_OS1.42.syx]
```
Seul, `-t trig-preview` donne le MAIN OS `b5733f5ddcee498a0e3bb74587979789c76216ef5dc03bbe0771b401a9d01410`. Dans le flasher
depuis la version 0.20 (note 34 §6) : ses combinaisons avec les autres cartes sont dans `REF_MAINOS` (`docs/flasher/app.js`).

### Variante `6ch-usbup`

`tweaks/model-cycles_OS1.13/11-6ch-usbup.json` n'est pas écrit à la main : `tools/relocate_6ch.py` le dérive du patch 6 canaux
(stubs déplacés dans une cave ; descripteurs et table des modes USB laissés d'origine), sans l'image firmware, avec les binutils m68k.
Depuis la [note 35](notes/35-glitches-usb-multipiste.md), il rend aussi le flux USB robuste : envoi de chaque bloc au début de
l'interruption suivante (`tools/machines/usb6/feed.S`, écritures dans `tools/usb_steady.py`, les mêmes que dans Model-TG et les moteurs
du Syntakt), file alignée au démarrage, ring de 9 cases de 168 o au lieu de 8 de 192 o, copie des 6 pistes déroulée
(`tools/machines/usb6/tracks6.S`). La preuve fait tourner le vrai pilote USB de l'OS avec un contrôleur modélisé :
```sh
python3 tools/relocate_6ch.py --check                  # le fichier versionné est-il à jour ?
python3 tools/emu/test_usb_in.py --cycles model-cycles_OS1.13.syx [--seconds 2] [--long 60]   # ~15 min
```

### Machine SD VINTAGE

`tweaks/model-cycles_OS1.13/20-sdvintage-snare.json` est produit par `tools/gen_sdvintage.py`, qui compile
`tools/machines/sdvintage/sdvintage.c` pour le ColdFire du M:C (paquet `gcc-m68k-linux-gnu`, testé avec GCC 13.3).
La validation rejoue le vrai moteur de l'OS dans un émulateur (paquets Python `unicorn` et `numpy`, plus `binutils-m68k-linux-gnu`) :
```sh
python3 tools/gen_sdvintage.py --check                               # le JSON versionné correspond-il au source ?
python3 tools/emu/test_sdvintage.py -i model-cycles_OS1.13.syx       # ~2 min ; --wav dossier/ pour écouter les rendus
```
Le vrai moteur du Syntakt, à la place de SNARE ([note 17](notes/17-portage-exact-syntakt.md)) ou en 7ᵉ machine SDVtg
([note 18](notes/18-septieme-machine.md)), a ses générateurs et ses preuves (`m68k-elf-gcc` / `m68k-elf-objdump`) :
```sh
python3 tools/gen_sdvintage_exact.py --syntakt Syntakt_OS1.42.syx --check
python3 tools/gen_sdvintage_7th.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx --check
python3 tools/emu/test_sdvintage_exact.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx
python3 tools/emu/test_sdvintage_7th.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx
python3 tools/gen_syntakt_machines.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx --check
python3 tools/emu/test_syntakt_machines.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx
python3 tools/gen_syntakt_engines.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx --all --check
python3 tools/emu/test_syntakt_machines.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx \
    --tweak tweaks/model-cycles_OS1.13/24-syntakt-sd-cp-toy.json
python3 tools/emu/test_sram_scratch.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx \
    --tweak tweaks/model-cycles_OS1.13/24-syntakt-sd-cp-toy-bits-swarm.json   # SRAM empruntée (notes/26)
python3 tools/emu/test_sram_code.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx \
    --tweak tweaks/model-cycles_OS1.13/24-syntakt-sd-cp-toy-bits-swarm.json   # code du Syntakt en SRAM (notes/28)
python3 tools/emu/test_model_tg.py --cycles model-cycles_OS1.13.syx                                  # Model-TG seul (notes/31, notes/35 §3)
python3 tools/emu/test_model_tg_syntakt.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx   # version combinée
python3 tools/ref_mainos.py --cycles model-cycles_OS1.13.syx --syntakt Syntakt_OS1.42.syx --check
```
Pour ajouter un moteur : l'ajouter à `CATALOG` de `tools/gen_syntakt_engines.py` (et ses plages copiées), puis relancer
`gen_syntakt_engines.py --all` et `--all --tg`, `gen_flasher_tweaks.py`, `check_overlaps.py` et `ref_mainos.py`, et tester chaque
nouveau tweak en émulation.

## Flasher (rappel)

1. **STARTUP MENU** : éteindre, maintenir **[FUNC]**, allumer, **[TRIG 4]** (OS UPGRADE).
2. Envoyer le `.syx` modifié sur le **MIDI IN** de l'appareil (`flash.sh` / `flash.bat`, SysEx Librarian ou C6),
   par câble jack stéréo depuis une interface à sortie TRS, ou par l'adaptateur DIN fourni.
   L'upgrade par le menu de démarrage **ne marche pas en USB MIDI** — MIDI IN obligatoire.
3. Détails, tests et récupération : [`notes/06-flash-et-recuperation.md`](notes/06-flash-et-recuperation.md).

## Autre chaîne d'outils

Le C [`mischa85/elektron-firmware-tool`](https://github.com/mischa85/elektron-firmware-tool) fait le même travail
de conteneur ; voir [`notes/02-format-os-syx.md`](notes/02-format-os-syx.md).
