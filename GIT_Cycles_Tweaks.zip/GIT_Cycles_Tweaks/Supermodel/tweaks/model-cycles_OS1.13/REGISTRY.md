# Registre de la place libre et des points d'accroche — Model:Cycles OS 1.13

Généré par `tools/registry.py` à partir des tweaks de ce dossier (notes/52) : ne pas éditer à la main. `python3 tools/registry.py` le régénère, `--check` vérifie qu'il est à jour, `--git <branche>` y ajoute à l'écran les mods d'autres branches, `--cycles <OS officiel>` vérifie le relevé des masques sur l'image.

Adresses : VA de l'OS 1.13 (la section 3 commence en `0x40000400`). Un mod qui veut de la place prend un masque marqué *libre* au §1 (`sprites.redirect_write`, voir `tools/AGENTS.md`), régénère ce fichier et le commet avec son tweak. `tools/check_overlaps.py` refuse deux mods installables ensemble aux mêmes octets ; ce registre refuse une écriture dans un masque dont le sprite n'est pas redirigé.

## En bref

- 171 tweaks, 17 603 écritures.
- Masques de sprites libérables : 164 (35 960 o), dont 148 pris (32 712 o) et **16 libres (3 248 o)**.
- Crochets sur l'OS : 108 adresses détournées, dont 68 à l'identique par des mods de familles différentes.
- Pointeurs réécrits : 73 adresses. Écritures dans des octets 0xFF hors masques : 14 zones.
- Charges utiles ajoutées après l'OS : 139 tweaks ; place restante au §3.

## 1. Masques de sprites libérés

Les masques d'un groupe sont identiques octet pour octet et chacun n'est désigné que par la constante 32 bits de son constructeur (notes/14 §5, notes/32 §11, notes/52). Faire pointer cette constante sur la copie gardée libère le masque : le rendu ne change pas et l'OS, chargé en SDRAM, n'y lit plus rien. Règles : un mod qui écrit dans un masque le redirige dans le même tweak (ou dans un tweak qu'il demande) ; personne n'écrit dans une copie gardée ; deux mods ne partagent un masque que s'ils ne s'installent jamais ensemble, ou l'un par-dessus l'autre.

### 47×47 : 21 masques de 376 o (copie gardée `0x40172220`) : 21 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4016b6f8` | `0x400b133e` | pris (plein) | chord-keys (376 o), scale-gen (342 o), scale-gen-queued (374 o), scale-gen-st (342 o), scale-gen-st-queued (374 o) |
| `0x4016b9e8` | `0x400b131c` | pris (374/376 o) | chord-keys (374 o), scale-gen (300 o), scale-gen-queued (342 o), scale-gen-st (300 o), scale-gen-st-queued (342 o) |
| `0x40171f30` | `0x400b05a0` | pris (plein) | chord-keys (376 o), scale-gen (288 o), scale-gen-queued (306 o), scale-gen-st (288 o), scale-gen-st-queued (306 o) |
| `0x40172608` | `0x400b0544` | pris (362/376 o) | chord-keys (362 o), scale-gen-queued (304 o), scale-gen-st-queued (304 o) |
| `0x40179730` | `0x400af64a` | pris (373/376 o) | chord-keys (373 o), scale-gen-queued (300 o), scale-gen-st-queued (300 o) |
| `0x40182b38` | `0x400adfda` | pris (plein) | chord-keys (376 o), scale-gen-queued (288 o), scale-gen-st-queued (288 o) |
| `0x40182e28` | `0x400adfba` | pris (plein) | chord-keys (376 o) |
| `0x40183118` | `0x400adf9e` | pris (374/376 o) | chord-keys (374 o), sample-preview (292 o), sample-preview-st (292 o) |
| `0x40185018` | `0x400adba8` | pris (372/376 o) | chord-keys (372 o), sample-preview (300 o), sample-preview-st (300 o) |
| `0x40185968` | `0x400ada00` | pris (372/376 o) | chord-keys (372 o), sample-preview (332 o), sample-preview-st (332 o) |
| `0x40185c58` | `0x400ad9e0` | pris (374/376 o) | chord-keys (374 o), sample-preview (312 o), sample-preview-st (312 o) |
| `0x40189930` | `0x400ad328` | pris (354/376 o) | arp (354 o) |
| `0x4018a220` | `0x400ad202` | pris (359/376 o) | arp (359 o) |
| `0x4018cd48` | `0x400acdb2` | pris (plein) | chord-keys (376 o) |
| `0x4018d1b8` | `0x400acd76` | pris (372/376 o) | chord-keys (372 o) |
| `0x4018d4a8` | `0x400acd56` | pris (210/376 o) | chord-keys (210 o) |
| `0x4018dba8` | `0x400accfe` | pris (114/376 o) | trigless-dim (114 o) |
| `0x4018f4b4` | `0x400ac8d0` | pris (360/376 o) | level-pan-values (360 o) |
| `0x4018fc74` | `0x400ac81c` | pris (364/376 o) | level-pan-values (364 o) |
| `0x401904b4` | `0x400ac784` | pris (370/376 o) | multiline-browser (370 o) |
| `0x40192734` | `0x400ac2b2` | pris (318/376 o) | trigless-dim (318 o) |

### 48×22 : 42 masques de 192 o (copie gardée `0x4014b364`) : 28 pris, 14 libres (2 688 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x40152d38` | `0x400b9726` | pris (156/192 o) | scale-gen (156 o), scale-gen-queued (156 o), scale-gen-st (156 o), scale-gen-st-queued (156 o) |
| `0x401592bc` | `0x400b7404` | pris (148/192 o) | scale-gen (148 o), scale-gen-queued (148 o), scale-gen-st (148 o), scale-gen-st-queued (148 o) |
| `0x4015943c` | `0x400b73e4` | pris (142/192 o) | scale-gen (142 o), scale-gen-queued (142 o), scale-gen-st (142 o), scale-gen-st-queued (142 o) |
| `0x4015f38c` | `0x400b504a` | pris (142/192 o) | scale-gen (140 o), scale-gen-queued (142 o), scale-gen-st (140 o), scale-gen-st-queued (142 o) |
| `0x40165fec` | `0x400b28b4` | pris (140/192 o) | scale-gen-queued (140 o), scale-gen-st-queued (140 o) |
| `0x40168a84` | `0x400b1bc0` | pris (188/192 o) | lfo-secondary (188 o) |
| `0x40168da4` | `0x400b1b32` | pris (150/192 o) | scramble (150 o), scramble-gen (150 o), scramble-gen-queued (150 o), scramble-st (150 o), scramble-st-gen (150 o), scramble-st-gen-queued (150 o) |
| `0x4016bcd8` | `0x400b12fe` | pris (186/192 o) | lfo-secondary (186 o) |
| `0x4016dab8` | `0x400b0f78` | pris (146/192 o) | scramble (146 o), scramble-gen (146 o), scramble-gen-queued (146 o), scramble-st (146 o), scramble-st-gen (146 o), scramble-st-gen-queued (146 o) |
| `0x4016fae8` | `0x400b0b20` | pris (134/192 o) | scramble (134 o), scramble-gen (134 o), scramble-gen-queued (134 o), scramble-st (134 o), scramble-st-gen (134 o), scramble-st-gen-queued (134 o) |
| `0x40170c48` | `0x400b08da` | pris (184/192 o) | lfo-secondary (184 o) |
| `0x40171a48` | `0x400b06ec` | pris (182/192 o) | lfo-secondary (182 o) |
| `0x40172a68` | `0x400b0508` | pris (180/192 o) | lfo-secondary (180 o) |
| `0x40172be8` | `0x400b04ec` | pris (178/192 o) | lfo-secondary (178 o) |
| `0x401736c8` | `0x400b036c` | pris (176/192 o) | lfo-secondary (176 o) |
| `0x40177f28` | `0x400af962` | pris (158/192 o) | lfo-secondary (158 o) |
| `0x40178708` | `0x400af812` | pris (152/192 o) | lfo-secondary (152 o) |
| `0x40178fc0` | `0x400af6e2` | pris (144/192 o) | lfo-secondary (144 o) |
| `0x401792b0` | `0x400af6a6` | pris (142/192 o) | lfo-secondary (142 o) |
| `0x40179430` | `0x400af686` | pris (140/192 o) | lfo-secondary (140 o) |
| `0x401795b0` | `0x400af66a` | pris (140/192 o) | lfo-secondary (140 o) |
| `0x40179b18` | `0x400af60e` | pris (28/192 o) | lfo-secondary (28 o) |
| `0x4017c97c` | `0x400aee4e` | pris (26/192 o) | lfo-secondary (26 o) |
| `0x401829b8` | `0x400adff6` | pris (22/192 o) | lfo-secondary (22 o) |
| `0x40183408` | `0x400adf7e` | pris (20/192 o) | lfo-secondary (20 o) |
| `0x40184808` | `0x400adc40` | pris (4/192 o) | lfo-secondary (4 o) |
| `0x40184af8` | `0x400adc04` | pris (4/192 o) | lfo-secondary (4 o) |
| `0x40184c78` | `0x400adbe4` | pris (4/192 o) | lfo-secondary (4 o) |
| `0x40187528` | `0x400ad742` | libre | |
| `0x401876a8` | `0x400ad726` | libre | |
| `0x40188f98` | `0x400ad3a0` | libre | |
| `0x4018a608` | `0x400ad1c6` | libre | |
| `0x4018b9c8` | `0x400ad048` | libre | |
| `0x4018bb48` | `0x400ad028` | libre | |
| `0x4018cbc8` | `0x400acdce` | libre | |
| `0x4018d038` | `0x400acd92` | libre | |
| `0x4018d798` | `0x400acd3a` | libre | |
| `0x4018f80c` | `0x400ac894` | libre | |
| `0x40190184` | `0x400ac7e0` | libre | |
| `0x40190334` | `0x400ac7a4` | libre | |
| `0x4019089c` | `0x400ac748` | libre | |
| `0x40192a24` | `0x400ac292` | libre | |

### 35×35 : 19 masques de 280 o (copie gardée `0x4014a660`) : 17 pris, 2 libres (560 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4014ab5c` | `0x400bb120` | pris (plein) | scale-gen-queued (280 o), scale-gen-st-queued (280 o), track-filter (152 o) |
| `0x4014b85c` | `0x400bae4e` | pris (148/280 o) | track-filter (148 o) |
| `0x4014d74c` | `0x400bac28` | pris (164/280 o) | track-filter (164 o) |
| `0x401542f8` | `0x400b91d8` | pris (224/280 o) | sample-wizard (224 o), track-filter (162 o) |
| `0x401548b4` | `0x400b903a` | pris (206/280 o) | track-filter (206 o) |
| `0x4015b8f8` | `0x400b668c` | pris (260/280 o) | track-filter (260 o) |
| `0x4015f50c` | `0x400b5028` | pris (260/280 o) | track-filter (260 o) |
| `0x401601fc` | `0x400b4b4a` | pris (260/280 o) | track-filter (260 o) |
| `0x40160864` | `0x400b48ac` | pris (260/280 o) | track-filter (260 o) |
| `0x40160b6c` | `0x400b4870` | pris (216/280 o) | track-filter (216 o) |
| `0x40160e6c` | `0x400b482e` | pris (256/280 o) | track-filter (256 o) |
| `0x401625bc` | `0x400b3e2a` | pris (136/280 o) | track-filter (136 o) |
| `0x40163fb8` | `0x400b34c8` | pris (147/280 o) | track-filter (147 o) |
| `0x4016616c` | `0x400b2898` | pris (164/280 o) | track-filter (164 o) |
| `0x40166760` | `0x400b272e` | pris (208/280 o) | track-filter (208 o) |
| `0x40167c50` | `0x400b211e` | pris (114/280 o) | midi-bth-three-state (114 o) |
| `0x401696a0` | `0x400b1540` | pris (194/280 o) | lfo-secondary (194 o) |
| `0x401699a8` | `0x400b1500` | libre | |
| `0x4016aa28` | `0x400b1480` | libre | |

### 34×34 : 14 masques de 272 o (copie gardée `0x4016bfc8`) : 14 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4016f8c8` | `0x400b0b3c` | pris (266/272 o) | scale-gen (266 o), scale-gen-queued (260 o), scale-gen-st (266 o), scale-gen-st-queued (260 o) |
| `0x40173848` | `0x400b0350` | pris (260/272 o) | scale-gen (260 o), scale-gen-queued (250 o), scale-gen-st (260 o), scale-gen-st-queued (250 o) |
| `0x401780a8` | `0x400af946` | pris (250/272 o) | scale-gen (250 o), scale-gen-queued (248 o), scale-gen-st (250 o), scale-gen-st-queued (248 o) |
| `0x401784e8` | `0x400af832` | pris (246/272 o) | scale-gen (246 o), scale-gen-queued (246 o), scale-gen-st (246 o), scale-gen-st-queued (246 o) |
| `0x401835b8` | `0x400adedc` | pris (240/272 o) | scale-gen (240 o), scale-gen-queued (240 o), scale-gen-st (240 o), scale-gen-st-queued (240 o) |
| `0x40184df8` | `0x400adbc8` | pris (236/272 o) | scale-gen (232 o), scale-gen-queued (236 o), scale-gen-st (232 o), scale-gen-st-queued (236 o) |
| `0x40185308` | `0x400adb8c` | pris (232/272 o) | scale-gen-queued (232 o), scale-gen-st-queued (232 o) |
| `0x40185f48` | `0x400ad9c4` | pris (232/272 o) | scale-gen-queued (232 o), scale-gen-st-queued (232 o) |
| `0x40186238` | `0x400ad988` | pris (228/272 o) | scale-gen-queued (228 o), scale-gen-st-queued (228 o) |
| `0x40189618` | `0x400ad364` | pris (266/272 o) | scramble (266 o), scramble-gen (266 o), scramble-gen-queued (266 o), scramble-st (266 o), scramble-st-gen (266 o), scramble-st-gen-queued (266 o) |
| `0x4018af88` | `0x400ad18a` | pris (200/272 o) | scale-gen-queued (200 o), scale-gen-st-queued (200 o) |
| `0x4018b1a8` | `0x400ad16e` | pris (222/272 o) | scramble (222 o), scramble-gen (222 o), scramble-gen-queued (222 o), scramble-st (222 o), scramble-st-gen (222 o), scramble-st-gen-queued (222 o) |
| `0x4018ff64` | `0x400ac7fc` | pris (234/272 o) | lfo-secondary (234 o) |
| `0x40192ba4` | `0x400ac276` | pris (132/272 o) | midi-live-both (132 o) |

### 27×27 : 24 masques de 108 o (copie gardée `0x4014a550`) : 24 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4014a890` | `0x400bb1fc` | pris (plein) | scale-gen (108 o), scale-gen-queued (108 o), scale-gen-st (108 o), scale-gen-st-queued (108 o) |
| `0x4014aa34` | `0x400bb178` | pris (106/108 o) | scale-gen (106 o), scale-gen-queued (106 o), scale-gen-st (106 o), scale-gen-st-queued (106 o) |
| `0x4014af84` | `0x400bb044` | pris (106/108 o) | scale-gen (106 o), scale-gen-queued (46 o), scale-gen-st (106 o), scale-gen-st-queued (46 o) |
| `0x4014b05c` | `0x400bb028` | pris (44/108 o) | scale-gen (34 o), scale-gen-queued (44 o), scale-gen-st (34 o), scale-gen-st-queued (44 o) |
| `0x4014b5b4` | `0x400baf2e` | pris (42/108 o) | scale-gen (32 o), scale-gen-queued (42 o), scale-gen-st (32 o), scale-gen-st-queued (42 o) |
| `0x4014b784` | `0x400bae6e` | pris (40/108 o) | scale-gen (32 o), scale-gen-queued (40 o), scale-gen-st (32 o), scale-gen-st-queued (40 o) |
| `0x4014e608` | `0x400ba8f2` | pris (34/108 o) | scale-gen (28 o), scale-gen-queued (34 o), scale-gen-st (28 o), scale-gen-st-queued (34 o) |
| `0x40152f88` | `0x400b96ce` | pris (32/108 o) | scale-gen (28 o), scale-gen-queued (32 o), scale-gen-st (28 o), scale-gen-st-queued (32 o) |
| `0x40159a04` | `0x400b71ea` | pris (32/108 o) | scale-gen (22 o), scale-gen-queued (32 o), scale-gen-st (22 o), scale-gen-st-queued (32 o) |
| `0x40159adc` | `0x400b71ce` | pris (28/108 o) | scale-gen (20 o), scale-gen-queued (28 o), scale-gen-st (20 o), scale-gen-st-queued (28 o) |
| `0x4015b820` | `0x400b66a8` | pris (28/108 o) | scale-gen (18 o), scale-gen-queued (28 o), scale-gen-st (18 o), scale-gen-st-queued (28 o) |
| `0x4015bf24` | `0x400b6476` | pris (28/108 o) | scale-gen (12 o), scale-gen-queued (28 o), scale-gen-st (12 o), scale-gen-st-queued (28 o) |
| `0x4015c9a4` | `0x400b6232` | pris (22/108 o) | scale-gen-queued (22 o), scale-gen-st-queued (22 o) |
| `0x4015fb6c` | `0x400b4e5a` | pris (20/108 o) | scale-gen-queued (20 o), scale-gen-st-queued (20 o) |
| `0x40160a94` | `0x400b488c` | pris (106/108 o) | scramble (106 o), scramble-gen (106 o), scramble-gen-queued (106 o), scramble-st (106 o), scramble-st-gen (106 o), scramble-st-gen-queued (106 o) |
| `0x401617a8` | `0x400b4386` | pris (90/108 o) | scramble (90 o), scramble-gen (90 o), scramble-gen-queued (90 o), scramble-st (90 o), scramble-st-gen (90 o), scramble-st-gen-queued (90 o) |
| `0x40161880` | `0x400b4366` | pris (70/108 o) | scramble (70 o), scramble-gen (70 o), scramble-gen-queued (70 o), scramble-st (70 o), scramble-st-gen (70 o), scramble-st-gen-queued (70 o) |
| `0x401629dc` | `0x400b3d96` | pris (56/108 o) | scramble (56 o), scramble-gen (56 o), scramble-gen-queued (56 o), scramble-st (56 o), scramble-st-gen (56 o), scramble-st-gen-queued (56 o) |
| `0x40163a60` | `0x400b362e` | pris (20/108 o) | scramble (20 o), scramble-gen (20 o), scramble-gen-queued (20 o), scramble-st (20 o), scramble-st-gen (20 o), scramble-st-gen-queued (20 o) |
| `0x40167900` | `0x400b21ac` | pris (11/108 o) | scramble (11 o), scramble-gen (11 o), scramble-gen-queued (11 o), scramble-st (11 o), scramble-st-gen (11 o), scramble-st-gen-queued (11 o) |
| `0x40167aa8` | `0x400b216c` | pris (18/108 o) | scale-gen-queued (18 o), scale-gen-st-queued (18 o) |
| `0x40168440` | `0x400b1d7c` | pris (12/108 o) | scale-gen-queued (12 o), scale-gen-st-queued (12 o) |
| `0x401688b4` | `0x400b1c5e` | pris (98/108 o) | lfo-secondary (98 o) |
| `0x401698d0` | `0x400b1522` | pris (88/108 o) | lfo-secondary (88 o) |

### 31×22 : 18 masques de 124 o (copie gardée `0x4016e980`) : 18 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4016f7d0` | `0x400b0b5c` | pris (122/124 o) | scale-gen (111 o), scale-gen-queued (122 o), scale-gen-st (111 o), scale-gen-st-queued (122 o) |
| `0x4016fd60` | `0x400b0ae4` | pris (112/124 o) | scale-gen-queued (112 o), scale-gen-st-queued (112 o) |
| `0x40172510` | `0x400b0564` | pris (112/124 o) | scale-gen-queued (112 o), scale-gen-st-queued (112 o) |
| `0x40178888` | `0x400af7f6` | pris (111/124 o) | scale-gen-queued (111 o), scale-gen-st-queued (111 o) |
| `0x40179a20` | `0x400af62e` | pris (112/124 o) | scramble (112 o), scramble-gen (112 o), scramble-gen-queued (112 o), scramble-st (112 o), scramble-st-gen (112 o), scramble-st-gen-queued (112 o) |
| `0x4017a4d4` | `0x400af43c` | pris (plein) | lfo-secondary (124 o) |
| `0x401837d8` | `0x400adeba` | pris (122/124 o) | lfo-secondary (122 o) |
| `0x401871a0` | `0x400ad77e` | pris (118/124 o) | lfo-secondary (118 o) |
| `0x40189838` | `0x400ad344` | pris (116/124 o) | lfo-secondary (116 o) |
| `0x4018a510` | `0x400ad1e6` | pris (82/124 o) | lfo-secondary (82 o) |
| `0x4018bcc8` | `0x400ad00c` | pris (76/124 o) | lfo-secondary (76 o) |
| `0x4018f98c` | `0x400ac874` | pris (74/124 o) | lfo-secondary (74 o) |
| `0x4018fa84` | `0x400ac858` | pris (70/124 o) | lfo-secondary (70 o) |
| `0x4018fb7c` | `0x400ac838` | pris (68/124 o) | lfo-secondary (68 o) |
| `0x401907a4` | `0x400ac768` | pris (62/124 o) | lfo-secondary (62 o) |
| `0x40190a1c` | `0x400ac72c` | pris (50/124 o) | lfo-secondary (50 o) |
| `0x40194ad4` | `0x400abeaa` | pris (44/124 o) | lfo-secondary (44 o) |
| `0x40195a7c` | `0x400abc76` | pris (34/124 o) | lfo-secondary (34 o) |

### 26×26 : 14 masques de 104 o (copie gardée `0x4014b4e4`) : 14 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x401573cc` | `0x400b83da` | pris (plein) | scale-gen (104 o), scale-gen-queued (104 o), scale-gen-st (104 o), scale-gen-st-queued (104 o) |
| `0x40160d9c` | `0x400b4850` | pris (99/104 o) | scale-gen (99 o), scale-gen-queued (99 o), scale-gen-st (99 o), scale-gen-st-queued (99 o) |
| `0x40162ab4` | `0x400b3d76` | pris (96/104 o) | scale-gen (96 o), scale-gen-queued (96 o), scale-gen-st (96 o), scale-gen-st-queued (96 o) |
| `0x401630e4` | `0x400b3b2e` | pris (96/104 o) | scale-gen (96 o), scale-gen-queued (96 o), scale-gen-st (96 o), scale-gen-st-queued (96 o) |
| `0x401638c0` | `0x400b366a` | pris (94/104 o) | scale-gen (94 o), scale-gen-queued (94 o), scale-gen-st (94 o), scale-gen-st-queued (94 o) |
| `0x40163990` | `0x400b364a` | pris (92/104 o) | scale-gen (92 o), scale-gen-queued (90 o), scale-gen-st (92 o), scale-gen-st-queued (90 o) |
| `0x40163b38` | `0x400b360e` | pris (84/104 o) | scale-gen (84 o), scale-gen-queued (84 o), scale-gen-st (84 o), scale-gen-st-queued (84 o) |
| `0x40166690` | `0x400b274c` | pris (80/104 o) | scale-gen (80 o), scale-gen-queued (80 o), scale-gen-st (80 o), scale-gen-st-queued (80 o) |
| `0x401679d8` | `0x400b218a` | pris (76/104 o) | scale-gen (60 o), scale-gen-queued (76 o), scale-gen-st (60 o), scale-gen-st-queued (76 o) |
| `0x40167b80` | `0x400b2144` | pris (72/104 o) | scale-gen (60 o), scale-gen-queued (72 o), scale-gen-st (60 o), scale-gen-st-queued (72 o) |
| `0x40168c4c` | `0x400b1b80` | pris (64/104 o) | scale-gen (46 o), scale-gen-queued (64 o), scale-gen-st (46 o), scale-gen-st-queued (64 o) |
| `0x40168fb4` | `0x400b1a72` | pris (60/104 o) | scale-gen (44 o), scale-gen-queued (60 o), scale-gen-st (44 o), scale-gen-st-queued (60 o) |
| `0x40179c98` | `0x400af5f2` | pris (60/104 o) | scale-gen (40 o), scale-gen-queued (60 o), scale-gen-st (40 o), scale-gen-st-queued (60 o) |
| `0x40186168` | `0x400ad9a4` | pris (50/104 o) | scale-gen (40 o), scale-gen-queued (50 o), scale-gen-st (40 o), scale-gen-st-queued (50 o) |

### 46×31 : 7 masques de 184 o (copie gardée `0x4016be58`) : 7 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x40170ad8` | `0x400b08f6` | pris (182/184 o) | scale-gen (182 o), scale-gen-queued (182 o), scale-gen-st (182 o), scale-gen-st-queued (182 o) |
| `0x40171bc8` | `0x400b06d0` | pris (178/184 o) | scale-gen (178 o), scale-gen-queued (178 o), scale-gen-st (178 o), scale-gen-st-queued (178 o) |
| `0x401728f8` | `0x400b0528` | pris (176/184 o) | scale-gen (176 o), scale-gen-queued (176 o), scale-gen-st (176 o), scale-gen-st-queued (176 o) |
| `0x40179140` | `0x400af6c2` | pris (170/184 o) | scale-gen (170 o), scale-gen-queued (170 o), scale-gen-st (170 o), scale-gen-st-queued (170 o) |
| `0x40184988` | `0x400adc20` | pris (170/184 o) | scale-gen (170 o), scale-gen-queued (170 o), scale-gen-st (170 o), scale-gen-st-queued (170 o) |
| `0x40185648` | `0x400ada58` | pris (166/184 o) | scale-gen (166 o), scale-gen-queued (166 o), scale-gen-st (166 o), scale-gen-st-queued (166 o) |
| `0x401857f8` | `0x400ada1c` | pris (162/184 o) | scale-gen (162 o), scale-gen-queued (162 o), scale-gen-st (162 o), scale-gen-st-queued (162 o) |

### 41×41 : 1 masques de 328 o (copie gardée `0x40187298`) : 1 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4018d918` | `0x400acd1a` | pris (326/328 o) | scale-gen (326 o), scale-gen-queued (326 o), scale-gen-st (326 o), scale-gen-st-queued (326 o) |

### 52×22 : 1 masques de 208 o (copie gardée `0x4014bfe4`) : 1 pris, 0 libres (0 o)

| masque | constante | état | mods (octets écrits) |
|---|---|---|---|
| `0x4016ea78` | `0x400b0d50` | pris (206/208 o) | scale-gen (206 o), scale-gen-queued (201 o), scale-gen-st (206 o), scale-gen-st-queued (201 o) |

### Masques 0xFF redirigés vers `0x40154ae4` (notes/14 §5)

Trois masques entièrement à 0xFF, les plus grands ; plusieurs mods s'y partagent la place (`check_overlaps.py` garantit qu'ils n'écrivent pas les mêmes octets, ou à l'identique).

| masque | taille | constante | état | mods (octets écrits) |
|---|---|---|---|---|
| `0x4015c044` | 720 o | `0x400b6434` | pris (550/720 o) | 6ch-usbup (384 o), macro (208 o), model-tg (208 o), model-tg-st (208 o), retrosyn (208 o), retrosyn-all-machines (208 o), syntakt-* (32/32, 208 o), syntakt-*-macro (31/31, 208 o), trig-hold (166 o) |
| `0x4016cae8` | 1024 o | `0x400b1106` | pris (1016/1024 o) | arp (824 o), macro (104 o), macro-tg (96 o), retrosyn (104 o), retrosyn-all-machines (188 o), retrosyn-all-machines-wizard (180 o), retrosyn-wizard (96 o), sdvintage-7th (40 o), sdvintage-exact (40 o), sdvintage-snare (973 o), syntakt-* (32/32, 80 o), syntakt-*-macro (31/31, 188 o), syntakt-tg-* (33/33, 172–188 o), syntakt-tg-*-macro (31/31, 180 o), syntakt-vintage (40 o) |
| `0x4018a788` | 1024 o | `0x400ad1aa` | pris (1016/1024 o) | arp (1016 o), sdvintage-snare (638 o) |

## 2. Autres écritures dans des octets 0xFF (caves)

Octets à 0xFF dans l'OS d'origine, hors des masques ci-dessus (tables à trous, fins de blocs). `build.py` refuse d'y écrire si l'image d'origine pointe dedans, sauf référence vérifiée à la main (`device.json`, `cave_refs_ok`).

| adresse | octets | mods |
|---|---|---|
| `0x4010df48` | 8 | model-tg, model-tg-st |
| `0x40147f22` | 2 | browser-scroll, model-tg, model-tg-st |
| `0x40147f25` | 126 | browser-scroll, model-tg, model-tg-st |
| `0x40147fa4` | 52 | browser-scroll, model-tg, model-tg-st |
| `0x40148328` | 104 | latching-mute, model-tg, model-tg-st |
| `0x401485f0` | 16 | browser-scroll, model-tg, model-tg-st |
| `0x40148662` | 348 | latching-mute, model-tg, model-tg-st |
| `0x401487e0` | 4 | latching-mute, model-tg, model-tg-st |
| `0x401487ec` | 2 | latching-mute, model-tg, model-tg-st |
| `0x401489fa` | 2 | model-tg, model-tg-st, trig-preview |
| `0x401489fd` | 246 | model-tg, model-tg-st, trig-preview |
| `0x40148af4` | 76 | model-tg, model-tg-st, trig-preview |
| `0x40148b41` | 15 | model-tg, model-tg-st, trig-preview |
| `0x40148b51` | 49 | model-tg, model-tg-st, trig-preview |

## 3. Charges utiles ajoutées après l'OS

Code trop gros pour un masque, ajouté à la fin de l'image (`at`) et copié au démarrage en mémoire (`dest`) ; les charges d'un même firmware s'enchaînent dans l'ordre `order` (notes/17, 31), ce que `check_overlaps.py` vérifie pour chaque ensemble installable. L'image ne peut pas dépasser `0x40200000`.

| mod | order | dans l'image (`at`) | octets | fin | en mémoire (`dest`) | octets | demande |
|---|---|---|---|---|---|---|---|
| sample-wizard | 20 | `0x401aa140` | 93 216 | `0x401c0d60` | `0x401aa140` | 93 216 |  |
| sdvintage-exact | 21 | `0x401aa140` | 205 200 | `0x401dc2d0` | `0x43000000` | 205 200 |  |
| sdvintage-7th | 22 | `0x401aa140` | 218 208 | `0x401df5a0` | `0x43000000` | 218 208 |  |
| syntakt-vintage | 23 | `0x401aa140` | 218 560 | `0x401df700` | `0x43000000` | 218 560 |  |
| syntakt-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-bits-macro | 24 | `0x401aa140` | 234 723 | `0x401e3623` | `0x43000000` | 476 128 |  |
| syntakt-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-bits-swarm-macro | 24 | `0x401aa140` | 240 959 | `0x401e4e7f` | `0x43000000` | 476 128 |  |
| syntakt-cp | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-cp-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-cp-bits-macro | 24 | `0x401aa140` | 234 976 | `0x401e3720` | `0x43000000` | 476 128 |  |
| syntakt-cp-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-cp-bits-swarm-macro | 24 | `0x401aa140` | 241 179 | `0x401e4f5b` | `0x43000000` | 476 128 |  |
| syntakt-cp-macro | 24 | `0x401aa140` | 230 067 | `0x401e23f3` | `0x43000000` | 476 128 |  |
| syntakt-cp-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-cp-swarm-macro | 24 | `0x401aa140` | 240 943 | `0x401e4e6f` | `0x43000000` | 476 128 |  |
| syntakt-cp-toy | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-cp-toy-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-cp-toy-bits-macro | 24 | `0x401aa140` | 235 181 | `0x401e37ed` | `0x43000000` | 476 128 |  |
| syntakt-cp-toy-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-cp-toy-bits-swarm-macro | 24 | `0x401aa140` | 241 389 | `0x401e502d` | `0x43000000` | 476 128 |  |
| syntakt-cp-toy-macro | 24 | `0x401aa140` | 230 327 | `0x401e24f7` | `0x43000000` | 476 128 |  |
| syntakt-cp-toy-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-cp-toy-swarm-macro | 24 | `0x401aa140` | 241 157 | `0x401e4f45` | `0x43000000` | 476 128 |  |
| syntakt-sd | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-sd-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-sd-bits-macro | 24 | `0x401aa140` | 235 011 | `0x401e3743` | `0x43000000` | 476 128 |  |
| syntakt-sd-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-bits-swarm-macro | 24 | `0x401aa140` | 241 219 | `0x401e4f83` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-sd-cp-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-sd-cp-bits-macro | 24 | `0x401aa140` | 235 207 | `0x401e3807` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-cp-bits-swarm-macro | 24 | `0x401aa140` | 241 402 | `0x401e503a` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-macro | 24 | `0x401aa140` | 230 336 | `0x401e2500` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-cp-swarm-macro | 24 | `0x401aa140` | 241 165 | `0x401e4f4d` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-toy | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-sd-cp-toy-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-sd-cp-toy-bits-macro | 24 | `0x401aa140` | 235 407 | `0x401e38cf` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-toy-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-cp-toy-bits-swarm-macro | 24 | `0x401aa140` | 241 604 | `0x401e5104` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-toy-macro | 24 | `0x401aa140` | 230 546 | `0x401e25d2` | `0x43000000` | 476 128 |  |
| syntakt-sd-cp-toy-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-cp-toy-swarm-macro | 24 | `0x401aa140` | 241 385 | `0x401e5029` | `0x43000000` | 476 128 |  |
| syntakt-sd-macro | 24 | `0x401aa140` | 230 073 | `0x401e23f9` | `0x43000000` | 476 128 |  |
| syntakt-sd-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-swarm-macro | 24 | `0x401aa140` | 240 952 | `0x401e4e78` | `0x43000000` | 476 128 |  |
| syntakt-sd-toy | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-sd-toy-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-sd-toy-bits-macro | 24 | `0x401aa140` | 235 205 | `0x401e3805` | `0x43000000` | 476 128 |  |
| syntakt-sd-toy-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-toy-bits-swarm-macro | 24 | `0x401aa140` | 241 419 | `0x401e504b` | `0x43000000` | 476 128 |  |
| syntakt-sd-toy-macro | 24 | `0x401aa140` | 230 338 | `0x401e2502` | `0x43000000` | 476 128 |  |
| syntakt-sd-toy-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-sd-toy-swarm-macro | 24 | `0x401aa140` | 241 170 | `0x401e4f52` | `0x43000000` | 476 128 |  |
| syntakt-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-swarm-macro | 24 | `0x401aa140` | 240 659 | `0x401e4d53` | `0x43000000` | 476 128 |  |
| syntakt-toy | 24 | `0x401aa140` | 260 352 | `0x401e9a40` | `0x43000000` | 260 352 |  |
| syntakt-toy-bits | 24 | `0x401aa140` | 264 448 | `0x401eaa40` | `0x43000000` | 264 448 |  |
| syntakt-toy-bits-macro | 24 | `0x401aa140` | 234 977 | `0x401e3721` | `0x43000000` | 476 128 |  |
| syntakt-toy-bits-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-toy-bits-swarm-macro | 24 | `0x401aa140` | 241 182 | `0x401e4f5e` | `0x43000000` | 476 128 |  |
| syntakt-toy-macro | 24 | `0x401aa140` | 230 056 | `0x401e23e8` | `0x43000000` | 476 128 |  |
| syntakt-toy-swarm | 24 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-toy-swarm-macro | 24 | `0x401aa140` | 240 926 | `0x401e4e5e` | `0x43000000` | 476 128 |  |
| macro | 25 | `0x401aa140` | 104 728 | `0x401c3a58` | `0x43000000` | 324 576 |  |
| retrosyn | 27 | `0x401aa140` | 10 068 | `0x401ac894` | `0x43000000` | 221 544 |  |
| retrosyn-all-machines | 28 | `0x401aa140` | 254 946 | `0x401e8522` | `0x46700000` | 553 320 |  |
| retrosyn-all-machines-wizard | 29 | `0x401c0d60` | 255 186 | `0x401ff232` | `0x46700000` | 553 320 | sample-wizard |
| model-tg | 30 | `0x401aa140` | 87 936 | `0x401bf8c0` | `0x401aa140` | 87 936 |  |
| model-tg-st | 30 | `0x401aa140` | 87 936 | `0x401bf8c0` | `0x401aa140` | 87 936 |  |
| syntakt-tg-bits | 31 | `0x401bf8c0` | 234 548 | `0x401f8cf4` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-bits-macro | 31 | `0x401bf8c0` | 234 990 | `0x401f8eae` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-bits-swarm | 31 | `0x401bf8c0` | 241 508 | `0x401fa824` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-bits-swarm-macro | 31 | `0x401bf8c0` | 241 224 | `0x401fa708` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp | 31 | `0x401bf8c0` | 227 772 | `0x401f727c` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-cp-bits | 31 | `0x401bf8c0` | 235 184 | `0x401f8f70` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-cp-bits-macro | 31 | `0x401bf8c0` | 235 260 | `0x401f8fbc` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-bits-swarm | 31 | `0x401bf8c0` | 242 020 | `0x401faa24` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-cp-bits-swarm-macro | 31 | `0x401bf8c0` | 241 455 | `0x401fa7ef` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-macro | 31 | `0x401bf8c0` | 230 346 | `0x401f7c8a` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-swarm | 31 | `0x401bf8c0` | 241 508 | `0x401fa824` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-cp-swarm-macro | 31 | `0x401bf8c0` | 241 203 | `0x401fa6f3` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-toy | 31 | `0x401bf8c0` | 228 348 | `0x401f74bc` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-cp-toy-bits | 31 | `0x401bf8c0` | 235 688 | `0x401f9168` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-cp-toy-bits-macro | 31 | `0x401bf8c0` | 235 463 | `0x401f9087` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-toy-bits-swarm | 31 | `0x401bf8c0` | 242 512 | `0x401fac10` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-cp-toy-bits-swarm-macro | 31 | `0x401bf8c0` | 241 657 | `0x401fa8b9` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-toy-macro | 31 | `0x401bf8c0` | 230 598 | `0x401f7d86` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-cp-toy-swarm | 31 | `0x401bf8c0` | 241 980 | `0x401fa9fc` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-cp-toy-swarm-macro | 31 | `0x401bf8c0` | 241 418 | `0x401fa7ca` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd | 31 | `0x401bf8c0` | 227 772 | `0x401f727c` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-sd-bits | 31 | `0x401bf8c0` | 235 196 | `0x401f8f7c` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-sd-bits-macro | 31 | `0x401bf8c0` | 235 284 | `0x401f8fd4` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-bits-swarm | 31 | `0x401bf8c0` | 242 040 | `0x401faa38` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-bits-swarm-macro | 31 | `0x401bf8c0` | 241 485 | `0x401fa80d` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp | 31 | `0x401bf8c0` | 228 360 | `0x401f74c8` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-sd-cp-bits | 31 | `0x401bf8c0` | 235 712 | `0x401f9180` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-sd-cp-bits-macro | 31 | `0x401bf8c0` | 235 474 | `0x401f9092` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-bits-swarm | 31 | `0x401bf8c0` | 242 532 | `0x401fac24` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-cp-bits-swarm-macro | 31 | `0x401bf8c0` | 241 673 | `0x401fa8c9` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-macro | 31 | `0x401bf8c0` | 230 612 | `0x401f7d94` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-swarm | 31 | `0x401bf8c0` | 242 000 | `0x401faa10` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-cp-swarm-macro | 31 | `0x401bf8c0` | 241 426 | `0x401fa7d2` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-toy | 31 | `0x401bf8c0` | 228 856 | `0x401f76b8` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits | 31 | `0x401bf8c0` | 236 200 | `0x401f9368` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-macro | 31 | `0x401bf8c0` | 235 679 | `0x401f915f` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-swarm | 31 | `0x401bf8c0` | 243 024 | `0x401fae10` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-cp-toy-bits-swarm-macro | 31 | `0x401bf8c0` | 241 869 | `0x401fa98d` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-toy-macro | 31 | `0x401bf8c0` | 230 809 | `0x401f7e59` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-cp-toy-swarm | 31 | `0x401bf8c0` | 242 492 | `0x401fabfc` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-cp-toy-swarm-macro | 31 | `0x401bf8c0` | 241 642 | `0x401fa8aa` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-macro | 31 | `0x401bf8c0` | 230 347 | `0x401f7c8b` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-swarm | 31 | `0x401bf8c0` | 241 504 | `0x401fa820` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-swarm-macro | 31 | `0x401bf8c0` | 241 219 | `0x401fa703` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-toy | 31 | `0x401bf8c0` | 228 348 | `0x401f74bc` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-sd-toy-bits | 31 | `0x401bf8c0` | 235 708 | `0x401f917c` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-sd-toy-bits-macro | 31 | `0x401bf8c0` | 235 492 | `0x401f90a4` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-toy-bits-swarm | 31 | `0x401bf8c0` | 242 532 | `0x401fac24` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-toy-bits-swarm-macro | 31 | `0x401bf8c0` | 241 680 | `0x401fa8d0` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-toy-macro | 31 | `0x401bf8c0` | 230 604 | `0x401f7d8c` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-sd-toy-swarm | 31 | `0x401bf8c0` | 241 988 | `0x401faa04` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-sd-toy-swarm-macro | 31 | `0x401bf8c0` | 241 433 | `0x401fa7d9` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-swarm | 31 | `0x401bf8c0` | 240 884 | `0x401fa5b4` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-swarm-macro | 31 | `0x401bf8c0` | 240 931 | `0x401fa5e3` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-toy | 31 | `0x401bf8c0` | 227 760 | `0x401f7270` | `0x46700000` | 260 352 | model-tg-st |
| syntakt-tg-toy-bits | 31 | `0x401bf8c0` | 235 180 | `0x401f8f6c` | `0x46700000` | 264 448 | model-tg-st |
| syntakt-tg-toy-bits-macro | 31 | `0x401bf8c0` | 235 258 | `0x401f8fba` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-toy-bits-swarm | 31 | `0x401bf8c0` | 242 012 | `0x401faa1c` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-toy-bits-swarm-macro | 31 | `0x401bf8c0` | 241 449 | `0x401fa7e9` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-toy-macro | 31 | `0x401bf8c0` | 230 323 | `0x401f7c73` | `0x46700000` | 476 128 | model-tg-st |
| syntakt-tg-toy-swarm | 31 | `0x401bf8c0` | 241 492 | `0x401fa814` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-toy-swarm-macro | 31 | `0x401bf8c0` | 241 190 | `0x401fa6e6` | `0x46700000` | 476 128 | model-tg-st |
| macro-tg | 32 | `0x401bf8c0` | 105 140 | `0x401d9374` | `0x46700000` | 324 576 | model-tg-st |
| retrosyn-wizard | 37 | `0x401c0d60` | 10 480 | `0x401c3650` | `0x46700000` | 221 544 | sample-wizard |
| syntakt-meter | 90 | `0x401aa140` | 269 056 | `0x401ebc40` | `0x43000000` | 269 056 |  |
| syntakt-tg-meter | 91 | `0x401bf8c0` | 243 472 | `0x401fafd0` | `0x46700000` | 269 056 | model-tg-st |
| syntakt-tg-profile | 92 | `0x401bf8c0` | 243 904 | `0x401fb180` | `0x46700000` | 269 056 | model-tg-st |

Fin la plus haute : `0x401ff232`, soit 3 534 o avant la limite (une charge posée sur une autre, comme les moteurs du Syntakt sur Model-TG, est déjà comptée à sa place dans la chaîne).

## 4. Points d'accroche (crochets) sur l'OS

Instructions de l'OS remplacées par un détour (`jsr`, `jmp`, `bsr.l`, `bra.l`) vers le code d'un mod, ou vers une autre fonction de l'OS. Deux mods installables ensemble ne peuvent détourner la même adresse qu'avec les mêmes octets (`check_overlaps.py`) ; sinon ils se déclarent `conflicts`. Les combinaisons de moteurs du Syntakt visent des décalages différents dans leur charge utile : une ligne par adresse et par zone visée, avec le nombre de cibles (moteurs résumés en familles : présents/total). Le rôle de chaque crochet est dans la note du mod.

| adresse | origine (hex) | détour | vers | mods | notes |
|---|---|---|---|---|---|
| `0x400004b2` | `4feffff048d700f0` | jmp | masque `0x4016cae8` +0x0 | macro, retrosyn, retrosyn-all-machines, sdvintage-7th, sdvintage-exact, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-vintage | notes/17, notes/18, notes/36, notes/96 |
| `0x40000530` | `4ebaff8041f9` | jsr | charge utile (image) +0x154d4 | sample-wizard |  |
| `0x4000154a` | `4eb940044df8` | jsr | masque `0x40167c50` +0x60 | midi-bth-three-state |  |
| `0x4000154a` | `4eb940044df8` | jsr | masque `0x40192ba4` +0x70 `midi_gate` | midi-live-both | notes/53 |
| `0x4000156a` | `4eb940044df8` | jsr | masque `0x40167c50` +0x60 | midi-bth-three-state |  |
| `0x4000156a` | `4eb940044df8` | jsr | masque `0x40192ba4` +0x70 `midi_gate` | midi-live-both | notes/53 |
| `0x40001590` | `4eb940044df8` | jsr | masque `0x40167c50` +0x60 | midi-bth-three-state |  |
| `0x40001590` | `4eb940044df8` | jsr | masque `0x40192ba4` +0x70 `midi_gate` | midi-live-both | notes/53 |
| `0x400027e8` | `203c0030008072302540…` | jmp | OS `0x4019b136` | 6ch-multiout |  |
| `0x400027e8` | `203c0030008072302540…` | jmp | masque `0x4015c044` +0xd2 | 6ch-usbup | notes/36 |
| `0x400029e4` | `e7882239404a05e8d280…` | jmp | OS `0x4019b244` | 6ch-multiout |  |
| `0x400029e4` | `e7882239404a05e8d280…` | jmp | masque `0x4015c044` +0x1e0 | 6ch-usbup | notes/36 |
| `0x40002a06` | `206f002422414281d1c5…` | jmp | OS `0x4019b1e0` | 6ch-multiout |  |
| `0x40002a06` | `206f002422414281d1c5…` | jmp | masque `0x4015c044` +0x17c | 6ch-usbup | notes/36 |
| `0x40002a42` | `721320402004e3ace788…` | jmp | OS `0x4019b182` | 6ch-multiout |  |
| `0x40002a42` | `721320402004e3ace788…` | jmp | masque `0x4015c044` +0x11e | 6ch-usbup | notes/36 |
| `0x40005f36` | `b2ac00286730` | jmp | masque `0x4018dba8` +0x0 | trigless-dim | notes/45 |
| `0x40006086` | `4ef94008e77e` | jmp | masque `0x4018dba8` +0x20 | trigless-dim | notes/45 |
| `0x400081ce` | `4eb940006158` | jsr | charge utile (image) +0x6d2a | sample-wizard |  |
| `0x400081f2` | `4eb940090f48` | jsr | masque `0x4018f4b4` +0x0 | level-pan-values | notes/44 |
| `0x4001413e` | `205242a72f0a` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x400169f0` | `4feffff448d7040c` | jmp | charge utile (image) +0x4fb6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4001a1c4` | `4eb940016086` | jsr | masque `0x4018a788` +0x16 | arp | notes/32 |
| `0x4001aa4e` | `4fefffe048d70cfc` | jmp | masque `0x4018f4b4` +0xc | level-pan-values | notes/44 |
| `0x4001b22a` | `4e56ffc048d73cfc` | jmp | masque `0x4018f4b4` +0x78 | level-pan-values | notes/44 |
| `0x4001cb3e` | `4eb94002d138` | jsr | masque `0x40179730` +0x0 `ck_ui_menu_ctor` | chord-keys | notes/42 |
| `0x4001d25e` | `4eb940016086` | jsr | masque `0x4018a788` +0x1a | arp | notes/32 |
| `0x4001e4ca` | `4eb94000b22a` | jsr | masque `0x40183118` +0x13c `ck_shape_name` | chord-keys | notes/42 |
| `0x4001e8da` | `202f0020226a0068` | jsr | charge utile (mémoire), 16 cibles selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/96 |
| `0x40021f56` | `2f034e944879404a8cb8…` | jsr | charge utile (image) +0x4f16 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4002249c` | `4eb940072490` | jsr | masque `0x4015c044` +0x28 `th_press` | trig-hold | notes/33 |
| `0x400224ee` | `2f034eb9400724a0` | jmp | cave `0x401489fa` +0x0 | model-tg, model-tg-st, trig-preview | notes/31, notes/34, notes/36 |
| `0x40022d44` | `4eb940072460` | jsr | masque `0x4015c044` +0x3a `th_hold` | trig-hold | notes/33 |
| `0x40022da6` | `4eb94006b736` | jsr | masque `0x4015c044` +0x6c `th_release` | trig-hold | notes/33 |
| `0x4002351a` | `2f024eb9400740ca` | jmp | cave `0x40148328` +0x0 | latching-mute, model-tg, model-tg-st | notes/31, notes/36 |
| `0x4002d480` | `4cef7c7c0018` | jmp | masque `0x4016cae8` +0xc0 | arp | notes/32 |
| `0x4002f7d8` | `4cef7c7c0018` | jmp | charge utile (image) +0x11350 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x40032aee` | `4cef7c7c0018` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4003560a` | `4eb940044df84a8057c0…` | jmp | masque `0x40167c50` +0x0 | midi-bth-three-state |  |
| `0x4003560a` | `4eb940044df84a8057c0…` | jmp | masque `0x40192ba4` +0x0 `midi_key` | midi-live-both | notes/53 |
| `0x40035fd8` | `4eb940044df84a806708…` | jsr | masque `0x40167c50` +0x30 | midi-bth-three-state |  |
| `0x4003fa52` | `2f2802804eb94007cf72` | jmp | charge utile (mémoire) +0x7aafe | retrosyn-all-machines | notes/96 |
| `0x4004486c` | `4eb94005a274` | jsr | masque `0x40166760` +0xaa `tf_boot` | track-filter | notes/47 |
| `0x4004df40` | `704c222f0004` | jmp | charge utile (mémoire), 4 cibles selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/96 |
| `0x4004df5c` | `7206202f0004` | jmp | charge utile (mémoire), 9 cibles selon la combinaison | macro, retrosyn, retrosyn-all-machines, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-vintage | notes/18, notes/36, notes/96 |
| `0x4004df5c` | `4ef9401ae84e` | jmp | charge utile (mémoire), 6 cibles selon la combinaison | macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/43 |
| `0x4004df5c` | `7206202f0004` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4004df5c` | `4ef9401ae8ba` | jmp | charge utile (mémoire), 2 cibles selon la combinaison | retrosyn-all-machines-wizard, retrosyn-wizard | notes/96 |
| `0x4004df76` | `7205202f0004` | jmp | charge utile (mémoire), 9 cibles selon la combinaison | macro, retrosyn, retrosyn-all-machines, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-vintage | notes/18, notes/36, notes/96 |
| `0x4004df76` | `4ef9401b278a` | jmp | charge utile (mémoire), 6 cibles selon la combinaison | macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/43 |
| `0x4004df76` | `7205202f0004` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4004df76` | `4ef9401b28da` | jmp | charge utile (mémoire), 2 cibles selon la combinaison | retrosyn-all-machines-wizard, retrosyn-wizard | notes/96 |
| `0x4004dfa2` | `704c222f0004` | jmp | charge utile (mémoire), 4 cibles selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/96 |
| `0x40053a6c` | `4fefff8048d77cfc42af…` | jsr | OS `0x4008e6ba` | boot-anim | notes/39 |
| `0x40054c0e` | `254e0048200a` | jmp | masque `0x4016fae8` +0x0 `sc_steps_event` | scramble, scramble-gen, scramble-gen-queued, scramble-st, scramble-st-gen, scramble-st-gen-queued | notes/55 |
| `0x400550da` | `247940a7887c` | jmp | masque `0x40184df8` +0x0 `sg_q_hook` | scale-gen-queued, scale-gen-st-queued | notes/56 |
| `0x400551a6` | `4ebaf7264fef0018` | jsr | charge utile (image) +0x15318 | sample-wizard |  |
| `0x40055bfa` | `4ebaecd24fef0018` | jsr | charge utile (image) +0x15318 | sample-wizard |  |
| `0x40055f14` | `2f024aaf000c` | jmp | masque `0x4014b5b4` +0x0 `sg_q_stop` | scale-gen-queued, scale-gen-st-queued | notes/56 |
| `0x40056610` | `4fefffd848d73cfc` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x40056b38` | `4878000448798000b990` | jsr | charge utile (image) +0xab08 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400587f6` | `4eb940091f20` | jsr | masque `0x4018a788` +0x1b2 | arp | notes/32 |
| `0x40058ca0` | `a93c00000020` | jsr | masque `0x4015c044` +0x1f8 | 6ch-usbup, macro, model-tg, model-tg-st, retrosyn, retrosyn-all-machines, syntakt-* (32/32), syntakt-*-macro (31/31) | notes/31, notes/36, notes/96 |
| `0x40058e28` | `72ff242a0008202a000c` | jsr | masque `0x4018a788` +0x0 | arp | notes/32 |
| `0x4005910e` | `4aaa0030670c2002` | jsr | masque `0x40183118` +0x0 `pv_copy` | sample-preview, sample-preview-st | notes/46 |
| `0x40059382` | `4eb94005979e` | jsr | charge utile (mémoire), 14 cibles selon la combinaison | retrosyn-all-machines, retrosyn-all-machines-wizard, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/96 |
| `0x40059392` | `4eb940002912` | jsr | masque `0x4015c044` +0x292 | 6ch-usbup, macro, model-tg, model-tg-st, retrosyn, retrosyn-all-machines, syntakt-* (32/32), syntakt-*-macro (31/31) | notes/31, notes/36, notes/96 |
| `0x400593ce` | `4eb940002912` | jsr | masque `0x4015c044` +0x292 | 6ch-usbup, macro, model-tg, model-tg-st, retrosyn, retrosyn-all-machines, syntakt-* (32/32), syntakt-*-macro (31/31) | notes/31, notes/36, notes/96 |
| `0x400597c6` | `4eb940091ab2` | jsr | masque `0x40168a84` +0x0 `lf2_dispatch` | lfo-secondary | notes/58 |
| `0x4005981e` | `4eb9401b715c` | jsr | charge utile (mémoire) +0x3350e | syntakt-tg-* (1/33) | notes/31 |
| `0x4005982a` | `4eb940056d9c` | jsr | charge utile (image) +0xdd2c | sample-wizard |  |
| `0x40059852` | `4eb940056f58` | jsr | masque `0x4014ab5c` +0x0 `tf_post` | track-filter | notes/47 |
| `0x40059872` | `4eb9400567ba` | jsr | charge utile (image) +0xdb74 | sample-wizard |  |
| `0x40059872` | `4eb9401b7b54` | jsr | charge utile (mémoire) +0x3353e | syntakt-tg-* (1/33) | notes/31 |
| `0x40059dea` | `76ff781533c38c000000` | jmp | masque `0x40192734` +0x0 `td_led` | trigless-dim | notes/45 |
| `0x4005a31a` | `20065286eb88` | jmp | charge utile (mémoire), 7 cibles selon la combinaison | macro-tg, retrosyn-all-machines-wizard, retrosyn-wizard, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/43, notes/96 |
| `0x4005a340` | `7005b085643e` | jmp | charge utile (mémoire), 15 cibles selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage | notes/31, notes/36, notes/43, notes/96 |
| `0x4005a50a` | `724c202f0004` | jmp | charge utile (mémoire), 15 cibles selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage | notes/31, notes/36, notes/43, notes/96 |
| `0x4005a6a6` | `4ef9401ae8fc` | jmp | charge utile (mémoire), 6 cibles selon la combinaison | macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/43 |
| `0x4005a6a6` | `7205b2826430` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4005a6a6` | `4ef9401ae968` | jmp | charge utile (mémoire), 2 cibles selon la combinaison | retrosyn-all-machines-wizard, retrosyn-wizard | notes/96 |
| `0x4005a6b6` | `4ef9401ae936` | jmp | charge utile (mémoire), 6 cibles selon la combinaison | macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/43 |
| `0x4005a6b6` | `eb8a41f940a7` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4005a6b6` | `4ef9401ae9a2` | jmp | charge utile (mémoire), 2 cibles selon la combinaison | retrosyn-all-machines-wizard, retrosyn-wizard | notes/96 |
| `0x4005a6d0` | `41f940a79394` | jmp | charge utile (image) +0x10f40 | sample-wizard |  |
| `0x4005a8f0` | `7405b4816532` | jmp | charge utile (mémoire), 4 cibles selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/96 |
| `0x4005aa34` | `7417b480640c` | jmp | masque `0x40166760` +0x8a `tf_conv` | track-filter | notes/47 |
| `0x4005aecc` | `4feffff448d7` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4005aecc` | `4feffff448d7` | jmp | masque `0x40166760` +0x0 `tf_load` | track-filter | notes/47 |
| `0x4005afa0` | `4feffff448d7` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4005afa0` | `4feffff448d7` | jmp | masque `0x4016616c` +0x0 `tf_save2` | track-filter | notes/47 |
| `0x4005b054` | `4feffff448d7` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4005b054` | `4feffff448d7` | jmp | masque `0x4016616c` +0x1c `tf_save1` | track-filter | notes/47 |
| `0x4005b4a8` | `7001156b001c001c` | jmp | masque `0x4016b6f8` +0x14e `ck_storage_load_hook` | chord-keys | notes/42 |
| `0x40061564` | `1140001b48780010` | jmp | masque `0x4018d1b8` +0xea `ck_storage_init_hook` | chord-keys | notes/42 |
| `0x4007240c` | `206f00042028` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x4007240c` | `4ef9401ae968` | jmp | masque `0x40171f30` +0x0 `sg_key` | scale-gen, scale-gen-st | notes/56 |
| `0x4007240c` | `4ef9401ae968` | jmp | masque `0x40182b38` +0x0 `sg_key` | scale-gen-queued, scale-gen-st-queued | notes/56 |
| `0x4007240c` | `4ef9401ae968` | jmp | masque `0x40189618` +0x0 `sc_key` | scramble, scramble-st | notes/55 |
| `0x4007240c` | `4ef940171f30` | jmp | masque `0x40189618` +0x0 `sc_key` | scramble-gen, scramble-st-gen | notes/55 |
| `0x4007240c` | `4ef940182b38` | jmp | masque `0x40189618` +0x0 `sc_key` | scramble-gen-queued, scramble-st-gen-queued | notes/55 |
| `0x40081474` | `b08365000178` | jmp | charge utile (image) +0x10ffc | model-tg, model-tg-st | notes/31, notes/36 |
| `0x4008171e` | `4e56ff98707f` | jmp | charge utile (mémoire) +0x7a750 | retrosyn-all-machines | notes/96 |
| `0x4008171e` | `4ef9401b3210` | jmp | masque `0x40185968` +0x0 `pv_note` | sample-preview, sample-preview-st | notes/46 |
| `0x4008171e` | `4e56ff98707f` | jmp | charge utile (image) +0x15338 | sample-wizard |  |
| `0x4008173c` | `b083650001ce` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x40081908` | `4ebaf2ec588f` | jsr | masque `0x40189930` +0x102 | arp | notes/32 |
| `0x40084b8e` | `487800222d48` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x40084b8e` | `487800222d48` | jmp | charge utile (mémoire) +0x7acf0 | retrosyn-all-machines | notes/96 |
| `0x40084c14` | `721b4fef0028` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x40084c14` | `721b4fef0028` | jmp | charge utile (mémoire) +0x7ad76 | retrosyn-all-machines | notes/96 |
| `0x4009249a` | `4eb9400949d8` | jsr | charge utile (image) +0xd6da | sample-wizard |  |
| `0x40094c9a` | `71aa00084fef0020` | jmp | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x40094c9a` | `71aa00084fef0020` | jmp | charge utile (mémoire) +0x7adb6 | retrosyn-all-machines | notes/96 |
| `0x400a2638` | `eb8c48780001` | jmp | charge utile (mémoire), 16 cibles selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/96 |
| `0x400a26a2` | `7850428545f9` | jmp | charge utile (mémoire), 13 cibles selon la combinaison | macro-tg, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, syntakt-* (27/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/43, notes/96 |
| `0x400a40e2` | `42a74eb940081bd6` | jmp | charge utile (mémoire) +0x7aaec | retrosyn-all-machines | notes/96 |
| `0x400a4dc4` | `700541e8000a` | jmp | charge utile (mémoire), 16 cibles selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage | notes/18, notes/31, notes/36, notes/43, notes/96 |
| `0x400a5588` | `2eaa028c4e95` | jmp | masque `0x401904b4` +0x2a `ml_row` | multiline-browser | notes/40 |
| `0x400a55a4` | `4fef001c226e` | jmp | masque `0x401904b4` +0x5e `ml_after` | multiline-browser | notes/40 |
| `0x400a5612` | `20522f0a20680040` | jsr | masque `0x401904b4` +0x10 `ml_bound` | multiline-browser | notes/40 |
| `0x400a576e` | `4eb940071da4` | jsr | masque `0x401904b4` +0x102 `ml_icon` | multiline-browser | notes/40 |
| `0x400a6426` | `4eb9400a3052` | jsr | charge utile (mémoire) +0x7a5c4 | retrosyn-all-machines | notes/96 |
| `0x400a6426` | `4eb9400a3052` | jsr | masque `0x40185c58` +0x0 `pv_parse` | sample-preview, sample-preview-st | notes/46 |
| `0x400a659e` | `4eb94007cdd4` | jsr | charge utile (image) +0x117ca | sample-wizard |  |
| `0x400a6602` | `4eb9400a3052` | jsr | charge utile (mémoire) +0x7a5c4 | retrosyn-all-machines | notes/96 |
| `0x400a6732` | `4ebaeac62f03` | jsr | charge utile (mémoire) +0x7a79a | retrosyn-all-machines | notes/96 |
| `0x400a6732` | `4ebaeac62f03` | jsr | charge utile (image) +0x15340 | sample-wizard |  |
| `0x400a6816` | `206800504e90` | jsr | charge utile (image), 2 cibles selon la combinaison | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x400a6c20` | `4fefffe048d70c0c` | jmp | charge utile (mémoire) +0x7aa4a | retrosyn-all-machines | notes/96 |
| `0x400a6f9c` | `2f2a02804eb94007cf72` | jmp | charge utile (mémoire) +0x7ab22 | retrosyn-all-machines | notes/96 |
| `0x400a70b0` | `4eb94007d2f0` | jsr | charge utile (mémoire) +0x7ab48 | retrosyn-all-machines | notes/96 |
| `0x400a7da8` | `2d41003c4a936730` | jmp | charge utile (image) +0x1f2a | model-tg, model-tg-st, sample-wizard | notes/31, notes/36 |
| `0x400a7dfe` | `b08465224ef9` | jmp | charge utile (mémoire), 9 cibles selon la combinaison | macro-tg, retrosyn-all-machines-wizard, retrosyn-wizard, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/43, notes/96 |
| `0x400a7dfe` | `b08465222046` | jmp | charge utile (mémoire), 7 cibles selon la combinaison | retrosyn-all-machines, syntakt-* (32/32), syntakt-*-macro (31/31) | notes/36, notes/96 |
| `0x400a7e02` | `204622704c002f0a2f0e…` | jmp | charge utile (image) +0x2918 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a7e02` | `204622704c002f0a2f0e…` | jmp | charge utile (image) +0x2954 | sample-wizard |  |
| `0x400a7e24` | `269522434280` | jmp | charge utile (mémoire), 8 cibles selon la combinaison | retrosyn-all-machines-wizard, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) | notes/31, notes/36, notes/96 |
| `0x400a8906` | `287c8000caa8` | jmp | charge utile (image) +0xddf6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a956c` | `2f0a226f00084280` | jmp | charge utile (image) +0xddd6 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a98c4` | `22115c8124730800` | jmp | charge utile (image) +0xdcda | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400a9daa` | `4feffff448d70c04` | jmp | charge utile (image) +0xdcf8 | model-tg, model-tg-st | notes/31, notes/36 |
| `0x400aae88` | `4fefffe448d71c3c` | jmp | masque `0x40185968` +0x0 `chord_audio_update` | chord-keys | notes/42 |
| `0x400ab0e4` | `d1fc4012142c` | jmp | masque `0x4018cd48` +0x0 `chord_audio_ratios` | chord-keys | notes/42 |

## 5. Pointeurs réécrits

Constantes 32 bits de l'OS (tables de fonctions, données) qui pointent maintenant vers le code ou les données d'un mod. Même regroupement qu'au §4.

| adresse | ancien | vers | mods |
|---|---|---|---|
| `0x40000532` | `401bf3d8` | masque `0x4016cae8` +0x0 | macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) |
| `0x40000532` | `401bf614` | masque `0x4016cae8` +0x0 | retrosyn-all-machines-wizard, retrosyn-wizard |
| `0x4000a94e` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4000b214` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4000b236` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4000b3ec` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4000b47e` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4000b522` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4000b662` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4000b6f4` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4000b790` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4001bbe8` | `400ffc7c` | charge utile (image) +0x1e3e | sample-wizard |
| `0x4001d5ee` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4001d902` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4001e032` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4001f32e` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x40022a84` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x40022b06` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x40029e88` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4002b438` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x40046d64` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4004e32e` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a2be` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a2de` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a322` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a390` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a3aa` | `40a7ada4` | charge utile (mémoire), 4 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a4f4` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a516` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a538` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a562` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a59a` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a5d8` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a60a` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a634` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a67a` | `4010dce8` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a6ba` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | macro, retrosyn, retrosyn-all-machines, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-vintage |
| `0x4005a6f0` | `40a79418` | charge utile (mémoire), 4 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a77e` | `4010dd00` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a78a` | `4010dd00` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a7bc` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a7dc` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a804` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a826` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a848` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a86a` | `4010dce0` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005a912` | `40a7ada4` | charge utile (mémoire), 4 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x4005b998` | `4010ee4c` | masque `0x40160e6c` +0x7c | track-filter |
| `0x4005baca` | `4010ee4c` | masque `0x40160e6c` +0x7c | track-filter |
| `0x40084be2` | `401285c9` | charge utile (mémoire) +0x7ae5e | retrosyn-all-machines |
| `0x40084be2` | `401285c9` | charge utile (image) +0xd938 | sample-wizard |
| `0x4009249c` | `400949d8` | charge utile (mémoire) +0x7ad8a | retrosyn-all-machines |
| `0x400a2614` | `401177e4` | charge utile (mémoire) +0x33800 | macro, retrosyn, retrosyn-all-machines, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-vintage |
| `0x400a2614` | `401bf51a` | charge utile (mémoire) +0x33800 | macro-tg, syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) |
| `0x400a2614` | `401bf746` | charge utile (mémoire) +0x33800 | retrosyn-all-machines-wizard, retrosyn-wizard |
| `0x400a2790` | `4001416c` | charge utile (image) +0x11054 | sample-wizard |
| `0x400a2834` | `4001416c` | charge utile (image) +0x11054 | sample-wizard |
| `0x400a6754` | `401302b2` | charge utile (mémoire) +0x7ac6c | retrosyn-all-machines |
| `0x400a6754` | `401302b2` | charge utile (image) +0x150ca | sample-wizard |
| `0x400a7d6c` | `40118628` | charge utile (mémoire), 9 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, sdvintage-7th, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31), syntakt-vintage |
| `0x400a7dc4` | `40118640` | charge utile (mémoire), 9 valeurs selon la combinaison | macro, macro-tg, retrosyn, retrosyn-all-machines, retrosyn-all-machines-wizard, retrosyn-wizard, syntakt-* (32/32), syntakt-*-macro (31/31), syntakt-tg-* (33/33), syntakt-tg-*-macro (31/31) |
| `0x400a7e16` | `40118610` | charge utile (mémoire), 2 valeurs selon la combinaison | macro, retrosyn, sdvintage-7th, syntakt-vintage |
| `0x400fd148` | `4000c264` | charge utile (image) +0x8736 | sample-wizard |
| `0x400fd170` | `4000a70e` | masque `0x40179730` +0xf8 | chord-keys |
| `0x400fd174` | `4000a66a` | masque `0x40185968` +0xba | chord-keys |
| `0x400ff9b8` | `400d7648` | charge utile (mémoire) +0x7a992 | retrosyn-all-machines |
| `0x400ff9b8` | `400d7648` | charge utile (image) +0x11086 | sample-wizard |
| `0x400ff9b8` | `401bb076` | masque `0x4014af84` +0x0 | scale-gen, scale-gen-st |
| `0x400ff9b8` | `401bb076` | masque `0x4016fd60` +0x0 | scale-gen-queued, scale-gen-st-queued |
| `0x400ff9cc` | `4001a0d2` | masque `0x40185018` +0x0 | chord-keys |
| `0x400ff9cc` | `4001a0d2` | charge utile (image) +0x9bec | sample-wizard |
| `0x400ffa78` | `400d7648` | charge utile (mémoire) +0x7a992 | retrosyn-all-machines |
| `0x400ffa78` | `400d7648` | charge utile (image) +0x11086 | sample-wizard |
| `0x400ffa78` | `401bb076` | masque `0x4014af84` +0x0 | scale-gen, scale-gen-st |
| `0x400ffa78` | `401bb076` | masque `0x4016fd60` +0x0 | scale-gen-queued, scale-gen-st-queued |
| `0x401005a8` | `4001e814` | masque `0x401625bc` +0x0 | track-filter |
| `0x401005bc` | `4001d818` | charge utile (image) +0x104ac | sample-wizard |
| `0x401016c8` | `40024e0c` | masque `0x4017a4d4` +0xa | lfo-secondary |
| `0x401016e4` | `40024e86` | masque `0x4017a4d4` +0x0 | lfo-secondary |
| `0x40103070` | `400d7648` | charge utile (mémoire) +0x7a992 | retrosyn-all-machines |
| `0x40103070` | `400d7648` | charge utile (image) +0x11086 | sample-wizard |
| `0x40103070` | `401bb076` | masque `0x4014af84` +0x0 | scale-gen, scale-gen-st |
| `0x40103070` | `401bb076` | masque `0x4016fd60` +0x0 | scale-gen-queued, scale-gen-st-queued |
| `0x401031b4` | `400d7648` | charge utile (mémoire) +0x7a992 | retrosyn-all-machines |
| `0x401031b4` | `400d7648` | charge utile (image) +0x11086 | sample-wizard |
| `0x401031b4` | `401bb076` | masque `0x4014af84` +0x0 | scale-gen, scale-gen-st |
| `0x401031b4` | `401bb076` | masque `0x4016fd60` +0x0 | scale-gen-queued, scale-gen-st-queued |
| `0x40107e18` | `400d7648` | charge utile (mémoire) +0x7a992 | retrosyn-all-machines |
| `0x40107e18` | `400d7648` | charge utile (image) +0x11086 | sample-wizard |
| `0x40107e18` | `401bb076` | masque `0x4014af84` +0x0 | scale-gen, scale-gen-st |
| `0x40107e18` | `401bb076` | masque `0x4016fd60` +0x0 | scale-gen-queued, scale-gen-st-queued |
| `0x40118614` | `400ab6e8` | charge utile (mémoire) +0x31196 | sdvintage-exact |
| `0x40118614` | `400ab6e8` | masque `0x4018a788` +0x0 | sdvintage-snare |
| `0x4011862c` | `400ab3b0` | charge utile (mémoire) +0x31000 | sdvintage-exact |
| `0x4011862c` | `400ab3b0` | masque `0x4016cae8` +0x0 | sdvintage-snare |
| `0x40148d44` | `00000000` | charge utile (mémoire) +0x7ae6e | retrosyn-all-machines |

## 6. Données sauvegardées (déclaré d'après les notes)

Ce que les écritures ne montrent pas : les octets des structures sauvegardées (pattern, projet) qu'un mod s'attribue. Un nouveau mod qui en prend un l'ajoute à `DECLARED` dans `tools/registry.py`, avec sa note. La mémoire où tournent les charges utiles est au §3 ; l'état que les mods gardent dans leurs masques, au §1.

| mod | ce qu'il s'attribue | source |
|---|---|---|
| arp | octet +512 de chaque piste dans le pattern : sens de l'arpège et octaves (inutilisé par l'OS, sauvegardé avec le pattern) | notes/32 §4 |

## 7. Ce que chaque mod touche

Nombre d'écritures de chaque sorte (une plage pour une famille de moteurs).

| mod | écritures | patchs | crochets | pointeurs | masques | redirections | caves | charge utile (image) | note |
|---|---|---|---|---|---|---|---|---|---|
| latching-mute | 8 | 3 | 1 | 0 | 0 | 0 | 4 |  |  |
| trig-preview | 6 | 0 | 1 | 0 | 0 | 0 | 5 |  | notes/34 |
| browser-scroll | 5 | 1 | 0 | 0 | 0 | 0 | 4 |  |  |
| 6ch-multiout | 29 | 25 | 4 | 0 | 0 | 0 | 0 |  |  |
| 6ch-usbup | 25 | 12 | 7 | 0 | 5 | 1 | 0 |  | notes/36 |
| sample-wizard | 61 | 17 | 29 | 13 | 1 | 1 | 0 | 93 216 o |  |
| sdvintage-snare | 10 | 4 | 0 | 2 | 2 | 2 | 0 |  | notes/16 |
| sdvintage-exact | 9 | 4 | 1 | 2 | 1 | 1 | 0 | 205 200 o | notes/17 |
| sdvintage-7th | 116 | 58 | 9 | 47 | 1 | 1 | 0 | 218 208 o | notes/18 |
| syntakt-vintage | 117 | 57 | 11 | 47 | 1 | 1 | 0 | 218 560 o |  |
| syntakt-* (32 tweaks) | 124 | 56–57 | 16–17 | 47 | 2 | 2 | 0 | 260 352–269 056 o | notes/36 |
| syntakt-*-macro (31 tweaks) | 124 | 56 | 17 | 47 | 2 | 2 | 0 | 230 056–241 604 o | notes/36 |
| macro | 122 | 56 | 14 | 48 | 2 | 2 | 0 | 104 728 o | notes/36 |
| retrosyn | 122 | 56 | 14 | 48 | 2 | 2 | 0 | 10 068 o | notes/96 |
| retrosyn-all-machines | 145 | 56 | 29 | 56 | 2 | 2 | 0 | 254 946 o | notes/96 |
| retrosyn-all-machines-wizard | 117 | 51 | 17 | 47 | 1 | 1 | 0 | 255 186 o | notes/96 |
| model-tg | 142 | 94 | 32 | 0 | 1 | 1 | 14 | 87 936 o | notes/36 |
| model-tg-st | 142 | 94 | 32 | 0 | 1 | 1 | 14 | 87 936 o | notes/31 |
| syntakt-tg-* (33 tweaks) | 117–119 | 51 | 17–19 | 47 | 1 | 1 | 0 | 227 760–243 904 o | notes/31, notes/36 |
| syntakt-tg-*-macro (31 tweaks) | 117 | 51 | 17 | 47 | 1 | 1 | 0 | 230 323–241 869 o | notes/36 |
| macro-tg | 114 | 50 | 15 | 47 | 1 | 1 | 0 | 105 140 o | notes/43 |
| sample-preview | 11 | 0 | 3 | 0 | 4 | 4 | 0 |  | notes/46 |
| sample-preview-st | 11 | 0 | 3 | 0 | 4 | 4 | 0 |  | notes/46 |
| retrosyn-wizard | 114 | 50 | 15 | 47 | 1 | 1 | 0 | 10 480 o | notes/96 |
| arp | 14 | 0 | 6 | 0 | 4 | 4 | 0 |  | notes/32 |
| trig-hold | 5 | 0 | 3 | 0 | 1 | 1 | 0 |  | notes/33 |
| tempo-max | 12 | 12 | 0 | 0 | 0 | 0 | 0 |  | notes/38 |
| boot-anim | 1 | 0 | 1 | 0 | 0 | 0 | 0 |  | notes/39 |
| multiline-browser | 16 | 10 | 4 | 0 | 1 | 1 | 0 |  | notes/40 |
| chord-keys | 37 | 0 | 6 | 3 | 14 | 14 | 0 |  | notes/42 |
| midi-bth-three-state | 7 | 0 | 5 | 0 | 1 | 1 | 0 |  |  |
| level-pan-values | 8 | 1 | 3 | 0 | 2 | 2 | 0 |  | notes/44 |
| trigless-dim | 8 | 1 | 3 | 0 | 2 | 2 | 0 |  | notes/45 |
| track-filter | 40 | 1 | 6 | 3 | 15 | 15 | 0 |  | notes/47 |
| invert-track | 1 | 1 | 0 | 0 | 0 | 0 | 0 |  | notes/122 |
| scale-gen | 104 | 0 | 1 | 5 | 49 | 49 | 0 |  | notes/56 |
| scale-gen-queued | 138 | 0 | 3 | 5 | 65 | 65 | 0 |  | notes/56 |
| scale-gen-st | 104 | 0 | 1 | 5 | 49 | 49 | 0 |  | notes/56 |
| scale-gen-st-queued | 138 | 0 | 3 | 5 | 65 | 65 | 0 |  | notes/56 |
| midi-both | 3 | 3 | 0 | 0 | 0 | 0 | 0 |  | notes/53 |
| scramble | 26 | 0 | 2 | 0 | 12 | 12 | 0 |  | notes/55 |
| scramble-gen | 26 | 0 | 2 | 0 | 12 | 12 | 0 |  | notes/55 |
| scramble-gen-queued | 26 | 0 | 2 | 0 | 12 | 12 | 0 |  | notes/55 |
| scramble-st | 26 | 0 | 2 | 0 | 12 | 12 | 0 |  | notes/55 |
| scramble-st-gen | 26 | 0 | 2 | 0 | 12 | 12 | 0 |  | notes/55 |
| scramble-st-gen-queued | 26 | 0 | 2 | 0 | 12 | 12 | 0 |  | notes/55 |
| midi-live-both | 6 | 0 | 4 | 0 | 1 | 1 | 0 |  | notes/53 |
| lfo-secondary | 77 | 0 | 1 | 2 | 37 | 37 | 0 |  | notes/58 |
